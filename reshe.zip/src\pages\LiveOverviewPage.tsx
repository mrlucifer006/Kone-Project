import React from 'react';
import { CameraPanel } from '../components/panels/CameraPanel';
import { MotionPanel } from '../components/panels/MotionPanel';
import { ElevatorSchematic } from '../components/panels/ElevatorSchematic';
import { ComponentCards } from '../components/panels/ComponentCards';
import { AlertsFeed } from '../components/panels/AlertsFeed';
import { StatusChip } from '../components/StatusChip';
import { useElevatorStore } from '../store/useElevatorStore';
import {
  Activity,
  ArrowRight,
  Layers,
  Wrench,
} from 'lucide-react';
import { Link } from 'react-router-dom';

export const LiveOverviewPage: React.FC = () => {
  const getOverallSystemStatus = useElevatorStore((state) => state.getOverallSystemStatus);
  const { status: overallStatus, worstComponent } = getOverallSystemStatus();

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-sans">
      {/* Page Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-2 border-b border-industrial-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 mb-1">
            <Activity className="w-3.5 h-3.5" />
            <span>ELEVATOR CAR #01 // LIVE OVERVIEW</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight text-slate-100 flex items-center gap-3">
            <span>Car Vitals &amp; Camera Feed</span>
            <StatusChip
              status={overallStatus}
              label={
                worstComponent
                  ? `${overallStatus.toUpperCase()} [${worstComponent.id.replace('_', ' ')}]`
                  : overallStatus.toUpperCase()
              }
              size="md"
              showPulse={overallStatus === 'critical' || overallStatus === 'warning'}
            />
          </h2>
          <p className="text-sm text-slate-400 mt-0.5">
            Live video tracking from C3 Cam module, car movement status, and essential parts health.
          </p>
        </div>

        {/* Quick Navigation Links */}
        <div className="flex items-center gap-2 font-mono text-xs">
          <Link
            to="/vibration"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-industrial-800 hover:bg-industrial-750 text-slate-200 border border-industrial-700 transition-colors"
          >
            <Layers className="w-3.5 h-3.5 text-cyan-400" />
            <span>Vibration Sensor</span>
            <ArrowRight className="w-3 h-3 text-slate-400" />
          </Link>
          <Link
            to="/maintenance"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-industrial-800 hover:bg-industrial-750 text-slate-200 border border-industrial-700 transition-colors"
          >
            <Wrench className="w-3.5 h-3.5 text-amber-400" />
            <span>Parts &amp; Service</span>
            <ArrowRight className="w-3 h-3 text-slate-400" />
          </Link>
        </div>
      </div>

      {/* 1. TOP ROW: CAMERA PANEL & MOTION PANEL */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <CameraPanel />
        <MotionPanel />
      </div>

      {/* 2. CENTER ROW: ELEVATOR SCHEMATIC (INTERACTIVE SVG HOISTWAY) */}
      <ElevatorSchematic />

      {/* 3. BOTTOM ROW: COMPONENT CARDS & ALERTS FEED */}
      <div className="space-y-5">
        <div>
          <div className="flex items-center justify-between pb-1.5 mb-2 border-b border-industrial-800">
            <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300">
              Subsystem Health Prognostics & 24h Wear Trend
            </h3>
            <span className="text-[11px] font-mono text-slate-500">
              Click any card to inspect full prognostic details
            </span>
          </div>
          <ComponentCards />
        </div>

        <AlertsFeed />
      </div>
    </div>
  );
};
