import React, { useState } from 'react';
import { useElevatorStore } from '../../store/useElevatorStore';
import type { ComponentId, MaintenanceEntry } from '../../types';
import {
  Calendar,
  CheckCircle2,
  FileText,
  Plus,
  User,
  Wrench,
  X,
} from 'lucide-react';

export interface MaintenanceLogSectionProps {
  isModalOpen: boolean;
  preselectedComponent?: ComponentId;
  onCloseModal: () => void;
  onOpenModal: () => void;
}

export const MaintenanceLogSection: React.FC<MaintenanceLogSectionProps> = ({
  isModalOpen,
  preselectedComponent = 'guide_rails',
  onCloseModal,
  onOpenModal,
}) => {
  const maintenanceEntries = useElevatorStore((state) => state.maintenanceEntries);
  const addMaintenanceEntry = useElevatorStore((state) => state.addMaintenanceEntry);

  const [targetComp, setTargetComp] = useState<ComponentId>(preselectedComponent);
  const [action, setAction] = useState('');
  const [technician, setTechnician] = useState('Senior Field Specialist');
  const [notes, setNotes] = useState('');
  const [justServicedComp, setJustServicedComp] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!action.trim()) return;

    const newEntry: MaintenanceEntry = {
      id: `maint-${Date.now()}`,
      ts: Date.now(),
      component: targetComp,
      action: action.trim(),
      technician: technician.trim(),
      notes: notes.trim() || 'Serviced according to OEM maintenance specification.',
    };

    addMaintenanceEntry(newEntry);
    setJustServicedComp(targetComp.replace('_', ' ').toUpperCase());

    setTimeout(() => {
      setJustServicedComp(null);
    }, 5000);

    setAction('');
    setNotes('');
    onCloseModal();
  };

  return (
    <div className="bg-industrial-900 border border-industrial-800 rounded-lg p-5 flex flex-col justify-between font-sans space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-industrial-800">
        <div className="flex items-center gap-2">
          <Wrench className="w-4 h-4 text-cyan-400" />
          <h3 className="text-sm font-mono font-bold uppercase tracking-wider text-slate-100 flex items-center gap-2">
            <span>Maintenance Records & Work Orders</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-industrial-950 border border-industrial-800 text-slate-400 font-mono">
              {maintenanceEntries.length} Records
            </span>
          </h3>
        </div>

        <button
          onClick={onOpenModal}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold font-mono text-xs transition-colors shadow-sm"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Log Maintenance Entry</span>
        </button>
      </div>

      {/* Success Notification Banner after logging */}
      {justServicedComp && (
        <div className="p-3 rounded-md bg-emerald-950/80 border border-emerald-700 flex items-center gap-2.5 text-xs font-mono text-emerald-200 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <div>
            <strong>Service Registered:</strong> Subsystem <strong>{justServicedComp}</strong> health reset to 98 and next-due date extended!
          </div>
        </div>
      )}

      {/* Maintenance Entries Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left font-mono text-xs">
          <thead>
            <tr className="border-b border-industrial-800 text-slate-400 text-[11px]">
              <th className="py-2.5 px-3">DATE / TIME</th>
              <th className="py-2.5 px-3">SUBSYSTEM</th>
              <th className="py-2.5 px-3">ACTION PERFORMED</th>
              <th className="py-2.5 px-3">TECHNICIAN</th>
              <th className="py-2.5 px-3">MEASUREMENT & NOTES</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-industrial-800/60 text-slate-300">
            {maintenanceEntries.map((m) => (
              <tr key={m.id} className="hover:bg-industrial-850/50 transition-colors">
                <td className="py-2.5 px-3 text-slate-400 whitespace-nowrap">
                  {new Date(m.ts).toLocaleDateString()} {new Date(m.ts).toLocaleTimeString().slice(0, 5)}
                </td>
                <td className="py-2.5 px-3">
                  <span className="px-2 py-0.5 rounded bg-industrial-950 border border-industrial-800 text-cyan-400 font-bold uppercase text-[10px]">
                    {m.component.replace('_', ' ')}
                  </span>
                </td>
                <td className="py-2.5 px-3 font-semibold text-slate-100">
                  {m.action}
                </td>
                <td className="py-2.5 px-3 text-slate-400 whitespace-nowrap">
                  {m.technician}
                </td>
                <td className="py-2.5 px-3 text-slate-400 font-sans text-xs">
                  {m.notes}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add Entry Modal Form */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
          <div className="bg-industrial-900 border border-industrial-700 rounded-lg p-6 w-full max-w-lg space-y-4 shadow-2xl font-mono text-xs">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-industrial-800 pb-3">
              <div className="flex items-center gap-2 text-slate-100 font-bold uppercase text-sm">
                <Wrench className="w-4 h-4 text-cyan-400" />
                <span>Log Maintenance Action & Reset Health</span>
              </div>
              <button
                onClick={onCloseModal}
                className="text-slate-400 hover:text-white p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="font-sans text-xs text-slate-400">
              Submitting this record will update the maintenance ledger, reset the component's health score to 98, and push back its next due date.
            </p>

            <form onSubmit={handleSubmit} className="space-y-3.5">
              <div>
                <label className="block text-slate-400 mb-1">Target Component:</label>
                <select
                  value={targetComp}
                  onChange={(e) => setTargetComp(e.target.value as ComponentId)}
                  className="w-full bg-industrial-950 border border-industrial-800 rounded p-2 text-slate-100 text-xs font-mono"
                >
                  <option value="guide_shoes">Guide Shoes (Rollers & Bushings)</option>
                  <option value="guide_rails">Guide Rails (Track Alignment & Profile)</option>
                  <option value="rail_joints">Rail Joints (Fishplate Torque & Step)</option>
                  <option value="car_frame">Car Frame (Chassis Structural Isolation)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Action Performed:</label>
                <input
                  type="text"
                  placeholder="e.g. Fishplate retorquing, Guide shoe replacement"
                  value={action}
                  onChange={(e) => setAction(e.target.value)}
                  required
                  className="w-full bg-industrial-950 border border-industrial-800 rounded p-2 text-slate-100 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Lead Field Technician:</label>
                <input
                  type="text"
                  value={technician}
                  onChange={(e) => setTechnician(e.target.value)}
                  required
                  className="w-full bg-industrial-950 border border-industrial-800 rounded p-2 text-slate-100 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Detailed Notes / Caliper Measurements:</label>
                <textarea
                  rows={3}
                  placeholder="Clearance before and after, torque measurements, lubricant type..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full bg-industrial-950 border border-industrial-800 rounded p-2 text-slate-100 text-xs font-mono"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-industrial-800">
                <button
                  type="button"
                  onClick={onCloseModal}
                  className="px-3 py-1.5 rounded bg-industrial-800 hover:bg-industrial-750 text-slate-300 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold transition-colors shadow-md"
                >
                  Save & Reset Health
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
