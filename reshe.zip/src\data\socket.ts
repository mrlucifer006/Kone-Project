import { APP_CONFIG } from '../config';
import { MockDataGenerator } from '../mock/generator';
import type {
  ConnectionStatus,
  SimulationScenario,
  SocketMessage,
  SocketMessageMap,
  SocketMessageType,
} from '../types';

type MessageHandler<T extends SocketMessageType> = (payload: SocketMessageMap[T]) => void;
type StatusHandler = (status: ConnectionStatus) => void;

export class ElevatorSocketClient {
  private status: ConnectionStatus = 'offline';
  private currentScenario: SimulationScenario = 'healthy';

  private realSocket: WebSocket | null = null;
  private mockGenerator: MockDataGenerator | null = null;

  private reconnectAttempts = 0;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private shouldStayConnected = false;

  private messageHandlers = new Map<SocketMessageType, Set<MessageHandler<any>>>();
  private statusHandlers = new Set<StatusHandler>();

  constructor() {
    // Initialize handler sets
    const types: SocketMessageType[] = ['vibration', 'motion', 'vision', 'health', 'alert', 'maintenance', 'scenario_change'];
    for (const t of types) {
      this.messageHandlers.set(t, new Set());
    }
  }

  // --------------------------------------------------------------------------
  // Public Interface
  // --------------------------------------------------------------------------
  public getStatus(): ConnectionStatus {
    return this.status;
  }

  public getScenario(): SimulationScenario {
    return this.currentScenario;
  }

  public subscribe<T extends SocketMessageType>(
    type: T,
    handler: MessageHandler<T>
  ): () => void {
    const handlers = this.messageHandlers.get(type);
    if (handlers) {
      handlers.add(handler);
    }
    return () => {
      handlers?.delete(handler);
    };
  }

  public onStatusChange(handler: StatusHandler): () => void {
    this.statusHandlers.add(handler);
    handler(this.status);
    return () => {
      this.statusHandlers.delete(handler);
    };
  }

  public connect(): void {
    this.shouldStayConnected = true;
    this.clearReconnectTimer();

    if (APP_CONFIG.USE_MOCK_SOCKET) {
      this.connectMock();
    } else {
      this.connectReal();
    }
  }

  public disconnect(): void {
    this.shouldStayConnected = false;
    this.clearReconnectTimer();

    if (this.realSocket) {
      this.realSocket.close();
      this.realSocket = null;
    }

    if (this.mockGenerator) {
      this.mockGenerator.stop();
      this.mockGenerator = null;
    }

    this.setStatus('offline');
  }

  public setScenario(scenario: SimulationScenario): void {
    this.currentScenario = scenario;
    if (this.mockGenerator) {
      this.mockGenerator.setScenario(scenario);
    }
    this.emit('scenario_change', { scenario });

    // If using real backend, send control command
    if (this.realSocket && this.realSocket.readyState === WebSocket.OPEN) {
      this.send({ action: 'set_scenario', scenario });
    }
  }

  public pauseStream(): void {
    if (this.mockGenerator) {
      this.mockGenerator.pause();
    }
  }

  public resumeStream(): void {
    if (this.mockGenerator) {
      this.mockGenerator.resume();
    }
  }

  public isStreamPaused(): boolean {
    return this.mockGenerator ? this.mockGenerator.getIsPaused() : false;
  }

  public send(data: unknown): void {
    if (this.realSocket && this.realSocket.readyState === WebSocket.OPEN) {
      this.realSocket.send(JSON.stringify(data));
    }
  }

  // --------------------------------------------------------------------------
  // Mock Generator Implementation
  // --------------------------------------------------------------------------
  private connectMock(): void {
    this.setStatus('reconnecting');

    // Simulate short network latency before connecting
    setTimeout(() => {
      if (!this.shouldStayConnected) return;

      this.mockGenerator = new MockDataGenerator({
        onVibration: (batch) => this.emit('vibration', batch),
        onMotion: (state) => this.emit('motion', state),
        onVision: (result) => this.emit('vision', result),
        onHealth: (health) => this.emit('health', health),
        onAlert: (alert) => this.emit('alert', alert),
      });

      this.mockGenerator.setScenario(this.currentScenario);
      this.mockGenerator.start();
      this.reconnectAttempts = 0;
      this.setStatus('connected');
    }, 250);
  }

  // --------------------------------------------------------------------------
  // Real WebSocket Implementation (Clean Drop-in)
  // --------------------------------------------------------------------------
  private connectReal(): void {
    if (this.realSocket) {
      this.realSocket.close();
    }

    this.setStatus('reconnecting');

    try {
      this.realSocket = new WebSocket(APP_CONFIG.REAL_WEBSOCKET_URL);

      this.realSocket.onopen = () => {
        this.reconnectAttempts = 0;
        this.setStatus('connected');
      };

      this.realSocket.onmessage = (event) => {
        try {
          const parsed = JSON.parse(event.data) as SocketMessage;
          if (parsed && parsed.type && parsed.payload) {
            this.emit(parsed.type, parsed.payload);
          }
        } catch (err) {
          console.error('[ElevatorSocket] Failed to parse incoming WebSocket message', err);
        }
      };

      this.realSocket.onclose = () => {
        this.handleDisconnect();
      };

      this.realSocket.onerror = () => {
        this.handleDisconnect();
      };
    } catch {
      this.handleDisconnect();
    }
  }

  private handleDisconnect(): void {
    if (!this.shouldStayConnected) {
      this.setStatus('offline');
      return;
    }

    this.setStatus('reconnecting');
    this.scheduleReconnect();
  }

  private scheduleReconnect(): void {
    this.clearReconnectTimer();

    if (this.reconnectAttempts >= APP_CONFIG.RECONNECT.MAX_ATTEMPTS) {
      this.setStatus('offline');
      return;
    }

    const { INITIAL_DELAY_MS, MAX_DELAY_MS, BACKOFF_FACTOR } = APP_CONFIG.RECONNECT;
    const delay = Math.min(
      INITIAL_DELAY_MS * Math.pow(BACKOFF_FACTOR, this.reconnectAttempts),
      MAX_DELAY_MS
    );

    this.reconnectAttempts++;

    this.reconnectTimer = setTimeout(() => {
      if (this.shouldStayConnected) {
        if (APP_CONFIG.USE_MOCK_SOCKET) {
          this.connectMock();
        } else {
          this.connectReal();
        }
      }
    }, delay);
  }

  private clearReconnectTimer(): void {
    if (this.reconnectTimer !== null) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
  }

  private setStatus(status: ConnectionStatus): void {
    if (this.status !== status) {
      this.status = status;
      for (const handler of this.statusHandlers) {
        handler(status);
      }
    }
  }

  private emit<T extends SocketMessageType>(type: T, payload: SocketMessageMap[T]): void {
    const handlers = this.messageHandlers.get(type);
    if (handlers) {
      for (const handler of handlers) {
        handler(payload);
      }
    }
  }
}

// Singleton socket client instance for app-wide lifecycle
export const socketClient = new ElevatorSocketClient();
