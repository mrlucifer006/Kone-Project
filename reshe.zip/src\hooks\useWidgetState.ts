import { useEffect, useState } from 'react';
import { APP_CONFIG } from '../config';
import type { WidgetState } from '../types';

export interface UseWidgetStateOptions {
  state?: WidgetState;
  lastUpdated?: number | null;
  isLoading?: boolean;
  hasData?: boolean;
}

export function useWidgetState({
  state: explicitState,
  lastUpdated,
  isLoading,
  hasData,
}: UseWidgetStateOptions = {}): {
  state: WidgetState;
  ageSeconds: number | null;
  isStale: boolean;
} {
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    // Tick every 500ms to detect staleness (>5s) reactively
    const interval = setInterval(() => {
      setNow(Date.now());
    }, 500);
    return () => clearInterval(interval);
  }, []);

  if (explicitState) {
    const age = lastUpdated ? Math.max(0, Number(((now - lastUpdated) / 1000).toFixed(1))) : null;
    return {
      state: explicitState,
      ageSeconds: age,
      isStale: explicitState === 'stale',
    };
  }

  if (isLoading) {
    return { state: 'loading', ageSeconds: null, isStale: false };
  }

  if (hasData === false || lastUpdated === null || lastUpdated === undefined) {
    return { state: 'no-data', ageSeconds: null, isStale: false };
  }

  const age = Math.max(0, Number(((now - lastUpdated) / 1000).toFixed(1)));
  const stale = now - lastUpdated > APP_CONFIG.STALE_DATA_THRESHOLD_MS;

  return {
    state: stale ? 'stale' : 'normal',
    ageSeconds: age,
    isStale: stale,
  };
}
