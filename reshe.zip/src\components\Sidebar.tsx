import React from 'react';
import { NavLink } from 'react-router-dom';
import { APP_CONFIG } from '../config';
import { useElevatorStore } from '../store/useElevatorStore';
import {
  Activity,
  ArrowDown,
  ArrowUp,
  Camera,
  Layers,
  PauseCircle,
  Sliders,
  Terminal,
  Waves,
  Wrench,
} from 'lucide-react';

export const Sidebar: React.FC = () => {
  const latestMotion = useElevatorStore((state) => state.latestMotion);
  const latestVibrationRms = useElevatorStore((state) => state.latestVibrationRms);
  const alerts = useElevatorStore((state) => state.alerts);
  const unackAlerts = alerts.filter((a) => !a.acknowledged);

  const navItems = [
    {
      to: '/',
      label: 'Live Car & Camera',
      icon: <Camera className="w-4 h-4 text-cyan-400" />,
      badge: unackAlerts.length > 0 ? `${unackAlerts.length}` : undefined,
      badgeColor: 'bg-red-500 text-white',
    },
    {
      to: '/vibration',
      label: 'Vibration Monitor',
      icon: <Waves className="w-4 h-4 text-emerald-400" />,
    },
    {
      to: '/maintenance',
      label: 'Parts & Service',
      icon: <Wrench className="w-4 h-4 text-amber-400" />,
    },
  ];

  const toolItems = [
    {
      to: '/components',
      label: 'Widget Test States',
      icon: <Sliders className="w-4 h-4 text-slate-400" />,
    },
    {
      to: '/debug',
      label: 'Raw Stream Values',
      icon: <Terminal className="w-4 h-4 text-slate-400" />,
    },
  ];

  const tripState = latestMotion?.tripState ?? 'stopped';
  const getSimpleMotionText = () => {
    switch (tripState) {
      case 'accelerating':
        return 'Starting Up';
      case 'cruising':
        return 'Moving Full Speed';
      case 'decelerating':
        return 'Slowing Down';
      case 'stopped':
      default:
        return 'Stationary (Doors Open)';
    }
  };

  const getTripIcon = () => {
    switch (tripState) {
      case 'accelerating':
      case 'cruising':
        return <ArrowUp className="w-3.5 h-3.5 text-cyan-400 animate-bounce" />;
      case 'decelerating':
        return <ArrowDown className="w-3.5 h-3.5 text-amber-400" />;
      case 'stopped':
      default:
        return <PauseCircle className="w-3.5 h-3.5 text-slate-500" />;
    }
  };

  // Ride smoothness
  const zRms = latestVibrationRms.z;
  const rideQuality =
    zRms < APP_CONFIG.THRESHOLDS.RIDE_COMFORT.COMFORTABLE_MAX_G
      ? { label: 'Smooth', color: 'text-emerald-400' }
      : zRms < APP_CONFIG.THRESHOLDS.RIDE_COMFORT.ACCEPTABLE_MAX_G
      ? { label: 'Normal', color: 'text-amber-400' }
      : { label: 'Rough', color: 'text-red-400 font-bold' };

  return (
    <aside className="w-60 bg-industrial-900 border-r border-industrial-800 flex flex-col justify-between shrink-0 select-none">
      {/* Top Links */}
      <div className="p-3 space-y-5">
        {/* Brand */}
        <div className="px-3 py-2 flex items-center gap-2.5">
          <div className="w-3 h-6 bg-cyan-500 rounded-xs" />
          <div>
            <div className="font-mono font-bold text-sm tracking-wide uppercase text-slate-100">
              KONE Car #01
            </div>
            <div className="text-[10px] text-slate-400">
              Rail &amp; Ride Health
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div className="space-y-1">
          <div className="px-3 text-[10px] font-mono font-bold uppercase tracking-wider text-slate-500 mb-1">
            Dashboard
          </div>
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              className={({ isActive }) =>
                `flex items-center justify-between px-3 py-2 rounded-md text-xs font-mono font-medium transition-all ${
                  isActive
                    ? 'bg-industrial-800 text-cyan-300 border-l-2 border-cyan-400 shadow-xs font-bold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-industrial-850'
                }`
              }
            >
              <div className="flex items-center gap-2.5">
                {item.icon}
                <span>{item.label}</span>
              </div>
              {item.badge && (
                <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${item.badgeColor}`}>
                  {item.badge}
                </span>
              )}
            </NavLink>
          ))}
        </div>

        {/* Verification Tools */}
        <div className="space-y-1 pt-2 border-t border-industrial-800/80">
          <div className="px-3 text-[10px] font-mono font-bold uppercase tracking-wider text-slate-500 mb-1">
            Tools
          </div>
          {toolItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `flex items-center justify-between px-3 py-2 rounded-md text-xs font-mono font-medium transition-all ${
                  isActive
                    ? 'bg-industrial-800 text-cyan-300 border-l-2 border-cyan-400 shadow-xs'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-industrial-850'
                }`
              }
            >
              <div className="flex items-center gap-2.5">
                {item.icon}
                <span>{item.label}</span>
              </div>
            </NavLink>
          ))}
        </div>
      </div>

      {/* Simplified Vital Signs Box at bottom */}
      <div className="p-3 m-3 rounded-lg bg-industrial-950/80 border border-industrial-800/90 space-y-2 font-mono">
        <div className="flex items-center justify-between text-[11px] text-slate-400 pb-1.5 border-b border-industrial-800">
          <span className="flex items-center gap-1 text-slate-200 font-bold">
            Car Vital Signs
          </span>
          <span className="flex items-center gap-1 text-[10px] uppercase font-bold text-slate-300">
            {getTripIcon()}
            {tripState}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2 text-xs">
          <div>
            <span className="text-[10px] text-slate-500 block">CURRENT FLOOR:</span>
            <span className="text-base font-bold text-slate-100">
              Floor {latestMotion?.floor ?? 1}
            </span>
          </div>
          <div>
            <span className="text-[10px] text-slate-500 block">RIDE QUALITY:</span>
            <span className={`text-base font-bold ${rideQuality.color}`}>
              {rideQuality.label}
            </span>
          </div>
        </div>

        <div className="text-[10px] text-slate-400 pt-1 border-t border-industrial-850 flex justify-between">
          <span>Speed: <strong className="text-slate-200">{(latestMotion?.speedMs ?? 0).toFixed(1)} m/s</strong></span>
          <span>Position: <strong className="text-slate-200">{(latestMotion?.position_m ?? 0).toFixed(1)} m</strong></span>
        </div>
      </div>
    </aside>
  );
};
