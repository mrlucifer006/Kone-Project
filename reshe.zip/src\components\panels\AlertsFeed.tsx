import React, { useState } from 'react';
import { useElevatorStore } from '../../store/useElevatorStore';
import type { AlertSeverity } from '../../types';
import { AlertItem } from '../AlertItem';
import {
  AlertTriangle,
  Bell,
  CheckCheck,
  Filter,
} from 'lucide-react';

export const AlertsFeed: React.FC = () => {
  const alerts = useElevatorStore((state) => state.alerts);
  const acknowledgeAlert = useElevatorStore((state) => state.acknowledgeAlert);

  const [filter, setFilter] = useState<'all' | 'unack' | 'critical'>('all');

  const unackCount = alerts.filter((a) => !a.acknowledged).length;

  const filteredAlerts = alerts.filter((a) => {
    if (filter === 'unack') return !a.acknowledged;
    if (filter === 'critical') return a.severity === 'critical';
    return true;
  });

  const handleAcknowledgeAll = () => {
    alerts.forEach((a) => {
      if (!a.acknowledged) {
        acknowledgeAlert(a.id);
      }
    });
  };

  return (
    <div className="bg-industrial-900 border border-industrial-800 rounded-lg p-4 space-y-3 font-sans">
      {/* Header & Filter Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-2 border-b border-industrial-800">
        <div className="flex items-center gap-2">
          <Bell className="w-4 h-4 text-amber-400" />
          <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-100 flex items-center gap-2">
            <span>System Warnings & Alerts</span>
            {unackCount > 0 && (
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-red-950 text-red-400 border border-red-800 animate-pulse">
                {unackCount} ACTIVE
              </span>
            )}
          </h3>
        </div>

        {/* Filter Pills & Bulk Acknowledge */}
        <div className="flex items-center gap-2 font-mono text-xs">
          <div className="flex items-center bg-industrial-950 p-0.5 rounded border border-industrial-800">
            <button
              onClick={() => setFilter('all')}
              className={`px-2 py-1 rounded text-xs transition-colors ${
                filter === 'all'
                  ? 'bg-industrial-800 text-slate-100 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All ({alerts.length})
            </button>
            <button
              onClick={() => setFilter('unack')}
              className={`px-2 py-1 rounded text-xs transition-colors ${
                filter === 'unack'
                  ? 'bg-industrial-800 text-slate-100 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Unacknowledged ({unackCount})
            </button>
            <button
              onClick={() => setFilter('critical')}
              className={`px-2 py-1 rounded text-xs transition-colors ${
                filter === 'critical'
                  ? 'bg-industrial-800 text-red-400 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Critical ({alerts.filter((a) => a.severity === 'critical').length})
            </button>
          </div>

          {unackCount > 0 && (
            <button
              onClick={handleAcknowledgeAll}
              className="flex items-center gap-1 px-2.5 py-1 rounded bg-industrial-800 hover:bg-industrial-750 text-slate-300 border border-industrial-700 transition-colors"
            >
              <CheckCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Ack All</span>
            </button>
          )}
        </div>
      </div>

      {/* Alerts List */}
      <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
        {filteredAlerts.length === 0 ? (
          <div className="p-8 text-center text-xs font-mono text-slate-500 bg-industrial-950/40 rounded border border-industrial-800">
            No incident alerts matching current filter criteria.
          </div>
        ) : (
          filteredAlerts.map((alert) => (
            <AlertItem
              key={alert.id}
              alert={alert}
              onAcknowledge={acknowledgeAlert}
            />
          ))
        )}
      </div>
    </div>
  );
};
