import React from 'react';
import { ComponentHealth } from '../../types';
import { StatusChip } from '../StatusChip';
import { AlertTriangle, Clock, HelpCircle, Info, ShieldAlert } from 'lucide-react';

export interface TtlConfidenceBandProps {
  component: ComponentHealth;
}

export const TtlConfidenceBand: React.FC<TtlConfidenceBandProps> = ({ component }) => {
  const { ttlDays, ttlLowDays, ttlHighDays, risk, id } = component;

  // Generate SVG confidence envelope polygon (Width: 380, Height: 120)
  // Left: Today (x=20, y=60).
  // Right: Predicted TTL Horizon (x=360).
  // Upper boundary goes from y=60 to y=20 (Low TTL - earlier failure).
  // Lower boundary goes from y=60 to y=100 (High TTL - later failure).
  // Median goes from y=60 to y=60.
  const chartWidth = 380;
  const chartHeight = 110;

  const todayX = 30;
  const todayY = 55;
  const horizonX = 340;

  // Upper CI curve (pessimistic / low days)
  const upperY = 22;
  // Lower CI curve (optimistic / high days)
  const lowerY = 88;

  const isCritical = risk === 'high';
  const isWarning = risk === 'medium';
  const bandFill = isCritical
    ? 'rgba(239, 68, 68, 0.18)'
    : isWarning
    ? 'rgba(245, 158, 11, 0.15)'
    : 'rgba(16, 185, 129, 0.15)';
  const medianStroke = isCritical ? '#ef4444' : isWarning ? '#f59e0b' : '#10b981';

  return (
    <div className="bg-industrial-900 border border-industrial-800 rounded-lg p-5 flex flex-col justify-between font-sans space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-industrial-800">
        <div>
          <span className="text-[10px] font-mono text-cyan-400 font-bold uppercase tracking-wider block">
            ESTIMATED TIME BEFORE REPLACEMENT
          </span>
          <h3 className="text-base font-bold text-slate-100 uppercase tracking-wide flex items-center gap-2">
            <span>{id.replace('_', ' ')} Estimated Life</span>
            <StatusChip status={risk} size="sm" showPulse={isCritical} />
          </h3>
        </div>

        <div className="text-right">
          {/* MANDATORY EXACT FORMAT: "N days (range LOW to HIGH)" */}
          <div className="font-mono text-lg sm:text-xl font-extrabold text-slate-100">
            {ttlDays} days{' '}
            <span className="text-xs text-slate-400 font-normal">
              (range {ttlLowDays} to {ttlHighDays})
            </span>
          </div>
          {/* MANDATORY SIMULATED DATA NOTE */}
          <span className="text-[10px] font-mono text-amber-400/90 italic block">
            Estimate from simulated data.
          </span>
        </div>
      </div>

      {/* Confidence Band SVG Chart */}
      <div className="relative w-full h-28 bg-industrial-950/80 rounded border border-industrial-800 p-2 flex items-center justify-center">
        <svg viewBox="0 0 380 110" className="w-full h-full select-none">
          {/* Background Grid Lines */}
          <line x1={todayX} y1="15" x2={todayX} y2="95" stroke="#334155" strokeWidth="1.5" strokeDasharray="3 3" />
          <line x1={horizonX} y1="15" x2={horizonX} y2="95" stroke="#334155" strokeWidth="1.5" strokeDasharray="3 3" />
          <line x1="20" y1={todayY} x2="360" y2={todayY} stroke="rgba(51, 65, 85, 0.4)" strokeWidth="1" />

          {/* Shaded 95% Confidence Band Polygon */}
          <path
            d={`M ${todayX} ${todayY} Q 180 35, ${horizonX} ${upperY} L ${horizonX} ${lowerY} Q 180 75, ${todayX} ${todayY} Z`}
            fill={bandFill}
          />

          {/* Upper Bound Line (Low Days) */}
          <path
            d={`M ${todayX} ${todayY} Q 180 35, ${horizonX} ${upperY}`}
            fill="none"
            stroke="rgba(148, 163, 184, 0.6)"
            strokeWidth="1.5"
            strokeDasharray="4 3"
          />

          {/* Lower Bound Line (High Days) */}
          <path
            d={`M ${todayX} ${todayY} Q 180 75, ${horizonX} ${lowerY}`}
            fill="none"
            stroke="rgba(148, 163, 184, 0.6)"
            strokeWidth="1.5"
            strokeDasharray="4 3"
          />

          {/* Median Projection Line */}
          <line
            x1={todayX}
            y1={todayY}
            x2={horizonX}
            y2={todayY}
            stroke={medianStroke}
            strokeWidth="2.5"
          />

          {/* Marker Labels */}
          <text x={todayX} y="105" fill="#64748b" fontSize="9" fontFamily="JetBrains Mono, monospace" textAnchor="middle">
            Today
          </text>
          <text x={horizonX} y="105" fill="#64748b" fontSize="9" fontFamily="JetBrains Mono, monospace" textAnchor="middle">
            +{ttlDays}d Median
          </text>

          {/* Low Bound Callout */}
          <circle cx={horizonX} cy={upperY} r="3.5" fill="#f59e0b" />
          <text x={horizonX + 6} y={upperY + 3} fill="#f59e0b" fontSize="8.5" fontFamily="JetBrains Mono, monospace">
            Low: {ttlLowDays}d
          </text>

          {/* High Bound Callout */}
          <circle cx={horizonX} cy={lowerY} r="3.5" fill="#10b981" />
          <text x={horizonX + 6} y={lowerY + 3} fill="#10b981" fontSize="8.5" fontFamily="JetBrains Mono, monospace">
            High: {ttlHighDays}d
          </text>
        </svg>
      </div>

      {/* Footer Info */}
      <div className="pt-2 border-t border-industrial-800/80 flex items-center justify-between text-[11px] font-mono text-slate-400">
        <span className="flex items-center gap-1.5">
          <Clock className="w-3.5 h-3.5 text-cyan-400" />
          <span>Estimated Lifespan Range (Based on Wear Speed)</span>
        </span>
        <span className={isCritical ? 'text-red-400 font-bold' : isWarning ? 'text-amber-400' : 'text-emerald-400'}>
          {isCritical ? 'SERVICE IMMEDIATELY REQUIRED' : isWarning ? 'SCHEDULE NEXT WINDOW' : 'NORMAL STATUS'}
        </span>
      </div>
    </div>
  );
};
