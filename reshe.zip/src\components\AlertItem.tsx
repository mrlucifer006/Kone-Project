import React from 'react';
import type { Alert, WidgetState } from '../types';
import {
  AlertOctagon,
  AlertTriangle,
  Zap,
  Check,
  Clock,
  Loader2,
  HelpCircle,
} from 'lucide-react';

export interface AlertItemProps {
  alert?: Alert;
  onAcknowledge?: (id: string) => void;
  state?: WidgetState;
  className?: string;
}

export const AlertItem: React.FC<AlertItemProps> = ({
  alert,
  onAcknowledge,
  state = 'normal',
  className = '',
}) => {
  if (state === 'loading') {
    return (
      <div className={`p-3 rounded-lg border border-industrial-800 bg-industrial-950/40 flex items-center gap-3 font-mono text-xs text-slate-500 animate-pulse ${className}`}>
        <Loader2 className="w-4 h-4 animate-spin text-cyan-500" />
        <span>Loading incident logs...</span>
      </div>
    );
  }

  if (state === 'no-data' || !alert) {
    return (
      <div className={`p-3 rounded-lg border border-dashed border-industrial-800 bg-industrial-950/20 flex items-center gap-2 font-mono text-xs text-slate-500 ${className}`}>
        <HelpCircle className="w-4 h-4 text-slate-600" />
        <span>No active threshold violations recorded.</span>
      </div>
    );
  }

  const isStale = state === 'stale';

  const getSeverityStyle = () => {
    switch (alert.severity) {
      case 'critical':
        return {
          icon: <AlertOctagon className="w-4 h-4 text-red-400 shrink-0" />,
          label: 'CRITICAL',
          badgeClass: 'bg-red-950 text-red-400 border-red-800',
          containerClass: isStale
            ? 'bg-red-950/15 border-red-900/40 opacity-70'
            : 'bg-red-950/25 border-red-800/80 hover:border-red-700 shadow-[0_0_12px_rgba(239,68,68,0.12)]',
        };
      case 'warning':
        return {
          icon: <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />,
          label: 'WARNING',
          badgeClass: 'bg-amber-950 text-amber-400 border-amber-800',
          containerClass: isStale
            ? 'bg-amber-950/15 border-amber-900/40 opacity-70'
            : 'bg-amber-950/25 border-amber-800/80 hover:border-amber-700 shadow-[0_0_12px_rgba(245,158,11,0.1)]',
        };
      case 'info':
      default:
        return {
          icon: <Zap className="w-4 h-4 text-cyan-400 shrink-0" />,
          label: 'INFO',
          badgeClass: 'bg-cyan-950 text-cyan-400 border-cyan-800',
          containerClass: isStale
            ? 'bg-industrial-950 border-industrial-800 opacity-70'
            : 'bg-industrial-900 border-industrial-800 hover:border-industrial-700',
        };
    }
  };

  const { icon, label, badgeClass, containerClass } = getSeverityStyle();

  return (
    <div
      className={`p-3 rounded-lg border transition-all flex flex-wrap items-center justify-between gap-3 text-xs font-mono ${containerClass} ${className}`}
    >
      {/* Left Details */}
      <div className="flex items-start gap-2.5 flex-1 min-w-[280px]">
        <div className="mt-0.5">{icon}</div>
        <div className="space-y-1 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className={`px-2 py-0.5 rounded font-mono font-bold text-[10px] tracking-wider border ${badgeClass}`}>
              {label}
            </span>
            <span className="px-1.5 py-0.5 rounded bg-industrial-800 text-slate-300 font-semibold uppercase text-[10px] border border-industrial-700">
              {alert.component.replace('_', ' ')}
            </span>
            <span className="text-[11px] text-slate-400">
              {new Date(alert.ts).toLocaleTimeString()}
            </span>
            {isStale && (
              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] bg-amber-950 text-amber-300 border border-amber-700">
                <Clock className="w-2.5 h-2.5" />
                STALE
              </span>
            )}
          </div>
          <p className="text-slate-200 font-sans text-xs leading-relaxed">
            {alert.message}
          </p>
        </div>
      </div>

      {/* Right Action */}
      <div className="shrink-0 flex items-center">
        {alert.acknowledged ? (
          <span className="inline-flex items-center gap-1 text-[11px] text-slate-400 font-mono font-semibold px-2 py-1 rounded bg-industrial-950 border border-industrial-800">
            <Check className="w-3.5 h-3.5 text-emerald-400" />
            <span>ACKNOWLEDGED</span>
          </span>
        ) : (
          <button
            onClick={() => onAcknowledge?.(alert.id)}
            className="px-2.5 py-1 rounded text-xs font-mono font-semibold bg-industrial-800 text-slate-200 hover:bg-cyan-950 hover:text-cyan-300 hover:border-cyan-800 border border-industrial-700 transition-colors shadow-sm"
          >
            Acknowledge
          </button>
        )}
      </div>
    </div>
  );
};
