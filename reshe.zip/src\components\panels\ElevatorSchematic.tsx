import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { APP_CONFIG } from '../../config';
import { useElevatorStore } from '../../store/useElevatorStore';
import type { ComponentHealth, ComponentId } from '../../types';
import { StatusChip } from '../StatusChip';
import {
  Activity,
  ArrowRight,
  ChevronRight,
  Clock,
  Layers,
  ShieldAlert,
  Sparkles,
  Wrench,
  X,
} from 'lucide-react';

export const ElevatorSchematic: React.FC = () => {
  const navigate = useNavigate();
  const latestMotion = useElevatorStore((state) => state.latestMotion);
  const healthMap = useElevatorStore((state) => state.healthMap);

  const [selectedComponentId, setSelectedComponentId] = useState<ComponentId | null>(null);

  const selectedComponent: ComponentHealth | null = selectedComponentId
    ? healthMap[selectedComponentId]
    : null;

  // Map floor position to vertical SVG coordinate (bottom = floor 1, top = floor 20)
  const totalHeightM = APP_CONFIG.ELEVATOR_PHYSICS.TOTAL_HEIGHT_M;
  const currentPosM = latestMotion?.position_m ?? 0;
  const normalizedY = Math.max(0, Math.min(1, currentPosM / totalHeightM));

  // In SVG coordinates (viewBox 0 0 400 480):
  // Shaft runs from y=30 to y=440 (height = 410).
  // Bottom floor (L1) is at y=410, top floor (L20) is at y=40.
  const shaftTopY = 40;
  const shaftBottomY = 420;
  const shaftHeight = shaftBottomY - shaftTopY;
  const carY = shaftBottomY - normalizedY * shaftHeight - 25; // 50px tall car

  const getComponentColor = (id: ComponentId) => {
    const comp = healthMap[id];
    if (!comp) return '#64748b'; // nodata grey
    switch (comp.risk) {
      case 'low':
        return '#10b981'; // green
      case 'medium':
        return '#f59e0b'; // amber
      case 'high':
        return '#ef4444'; // red
      default:
        return '#64748b';
    }
  };

  const getComponentGlow = (id: ComponentId) => {
    const comp = healthMap[id];
    if (comp?.risk === 'high') return 'drop-shadow(0 0 8px rgba(239, 68, 68, 0.8))';
    if (comp?.risk === 'medium') return 'drop-shadow(0 0 6px rgba(245, 158, 11, 0.6))';
    return 'drop-shadow(0 0 4px rgba(16, 185, 129, 0.3))';
  };

  const handleHotspotClick = (id: ComponentId) => {
    setSelectedComponentId(id);
  };

  return (
    <div className="relative bg-industrial-900 rounded-lg border border-industrial-800 p-4 flex flex-col justify-between">
      {/* Schematic Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-industrial-800">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-cyan-400" />
          <h3 className="text-sm font-mono font-bold uppercase tracking-wider text-slate-100 flex items-center gap-2">
            <span>Shaft & Hoistway Schematic</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-industrial-950 border border-industrial-800 text-slate-400 font-mono">
              Interactive Hotspots
            </span>
          </h3>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-2 font-mono text-[11px] text-slate-400">
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500" /> Healthy
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-amber-500" /> Warning
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" /> Critical
          </span>
        </div>
      </div>

      {/* Main SVG Visualization */}
      <div className="relative w-full h-[360px] my-2 flex items-center justify-center overflow-hidden bg-industrial-950/80 rounded border border-industrial-800/80">
        <svg
          viewBox="0 0 400 460"
          className="w-full h-full max-h-[350px] select-none"
        >
          {/* Shaft Framework Outline */}
          <rect
            x="60"
            y="25"
            width="280"
            height="410"
            fill="#0f1522"
            stroke="#1e293b"
            strokeWidth="2"
            rx="4"
          />

          {/* Floor Ticks & Labels on Left Side */}
          {Array.from({ length: 10 }).map((_, i) => {
            const fl = (i + 1) * 2;
            const y = shaftBottomY - ((fl - 1) / 19) * shaftHeight;
            return (
              <g key={fl}>
                <line
                  x1="60"
                  y1={y}
                  x2="340"
                  y2={y}
                  stroke="rgba(51, 65, 85, 0.3)"
                  strokeWidth="1"
                  strokeDasharray="4 4"
                />
                <text
                  x="48"
                  y={y + 3}
                  fill="#64748b"
                  fontSize="9"
                  fontFamily="JetBrains Mono, monospace"
                  textAnchor="end"
                >
                  L{fl}
                </text>
              </g>
            );
          })}

          {/* GUIDE RAILS (LEFT & RIGHT VERTICAL COLUMNS) - HOTSPOT */}
          <g
            onClick={() => handleHotspotClick('guide_rails')}
            className="cursor-pointer group"
            style={{ filter: getComponentGlow('guide_rails') }}
          >
            {/* Left Rail */}
            <rect
              x="100"
              y="30"
              width="10"
              height="400"
              fill={getComponentColor('guide_rails')}
              className="transition-all group-hover:opacity-80"
            />
            {/* Right Rail */}
            <rect
              x="290"
              y="30"
              width="10"
              height="400"
              fill={getComponentColor('guide_rails')}
              className="transition-all group-hover:opacity-80"
            />
            {/* Rail Callout Label */}
            <text
              x="295"
              y="22"
              fill={getComponentColor('guide_rails')}
              fontSize="9"
              fontFamily="JetBrains Mono, monospace"
              fontWeight="bold"
              textAnchor="middle"
            >
              RAILS
            </text>
          </g>

          {/* RAIL JOINTS (PERIODIC FISHPLATES) - HOTSPOT */}
          <g
            onClick={() => handleHotspotClick('rail_joints')}
            className="cursor-pointer group"
            style={{ filter: getComponentGlow('rail_joints') }}
          >
            {[105, 185, 265, 345].map((yJoint, idx) => (
              <g key={idx}>
                {/* Left joint bracket */}
                <rect
                  x="96"
                  y={yJoint}
                  width="18"
                  height="12"
                  rx="1"
                  fill={getComponentColor('rail_joints')}
                  stroke="#0a0d14"
                  strokeWidth="1"
                  className="transition-all group-hover:scale-110"
                />
                {/* Right joint bracket */}
                <rect
                  x="286"
                  y={yJoint}
                  width="18"
                  height="12"
                  rx="1"
                  fill={getComponentColor('rail_joints')}
                  stroke="#0a0d14"
                  strokeWidth="1"
                  className="transition-all group-hover:scale-110"
                />
              </g>
            ))}
            <text
              x="105"
              y="22"
              fill={getComponentColor('rail_joints')}
              fontSize="9"
              fontFamily="JetBrains Mono, monospace"
              fontWeight="bold"
              textAnchor="middle"
            >
              JOINTS
            </text>
          </g>

          {/* SUSPENSION CABLES */}
          <line
            x1="185"
            y1="25"
            x2="185"
            y2={carY}
            stroke="#475569"
            strokeWidth="1.5"
          />
          <line
            x1="215"
            y1="25"
            x2="215"
            y2={carY}
            stroke="#475569"
            strokeWidth="1.5"
          />

          {/* ELEVATOR CAR ASSEMBLY (DYNAMIC POSITION) */}
          <g transform={`translate(0, ${carY})`} className="transition-all duration-300">
            {/* CAR FRAME (CHASSIS BOX) - HOTSPOT */}
            <g
              onClick={() => handleHotspotClick('car_frame')}
              className="cursor-pointer group"
              style={{ filter: getComponentGlow('car_frame') }}
            >
              <rect
                x="120"
                y="0"
                width="160"
                height="50"
                rx="4"
                fill="#161e2e"
                stroke={getComponentColor('car_frame')}
                strokeWidth="2.5"
                className="transition-all group-hover:fill-industrial-800"
              />
              {/* Internal Cabin Graphic & Cross-Bracing */}
              <line x1="120" y1="0" x2="280" y2="50" stroke="rgba(71, 85, 105, 0.3)" strokeWidth="1" />
              <line x1="120" y1="50" x2="280" y2="0" stroke="rgba(71, 85, 105, 0.3)" strokeWidth="1" />
              <rect x="155" y="10" width="90" height="30" fill="#0f172a" rx="2" stroke="#334155" />
              <text
                x="200"
                y="28"
                fill="#38bdf8"
                fontSize="10"
                fontFamily="JetBrains Mono, monospace"
                fontWeight="bold"
                textAnchor="middle"
              >
                CAR #{latestMotion?.floor ?? 1}
              </text>
            </g>

            {/* GUIDE SHOES (MOUNTED ON CORNERS OF CAR) - HOTSPOT */}
            <g
              onClick={() => handleHotspotClick('guide_shoes')}
              className="cursor-pointer group"
              style={{ filter: getComponentGlow('guide_shoes') }}
            >
              {/* Top-Left Guide Shoe */}
              <rect
                x="106"
                y="2"
                width="16"
                height="10"
                rx="2"
                fill={getComponentColor('guide_shoes')}
                stroke="#0f172a"
                strokeWidth="1"
              />
              {/* Bottom-Left Guide Shoe */}
              <rect
                x="106"
                y="38"
                width="16"
                height="10"
                rx="2"
                fill={getComponentColor('guide_shoes')}
                stroke="#0f172a"
                strokeWidth="1"
              />
              {/* Top-Right Guide Shoe */}
              <rect
                x="278"
                y="2"
                width="16"
                height="10"
                rx="2"
                fill={getComponentColor('guide_shoes')}
                stroke="#0f172a"
                strokeWidth="1"
              />
              {/* Bottom-Right Guide Shoe */}
              <rect
                x="278"
                y="38"
                width="16"
                height="10"
                rx="2"
                fill={getComponentColor('guide_shoes')}
                stroke="#0f172a"
                strokeWidth="1"
              />
            </g>
          </g>
        </svg>

        {/* Floating Instruction Overlay */}
        <div className="absolute top-2 left-2 pointer-events-none font-mono text-[10px] text-slate-400 bg-industrial-950/70 px-2 py-1 rounded border border-industrial-800">
          Click any component to inspect prognostic drill-down
        </div>
      </div>

      {/* Footer Info */}
      <div className="pt-2 border-t border-industrial-800/80 flex items-center justify-between text-xs font-mono text-slate-400">
        <span>Current Floor: <strong>L{latestMotion?.floor ?? 1}</strong></span>
        <span>Shaft Position: <strong>{(latestMotion?.position_m ?? 0).toFixed(1)} m</strong></span>
      </div>

      {/* SIDE DRAWER MODAL (OPENS ON HOTSPOT CLICK) */}
      {selectedComponent && (
        <div className="fixed inset-0 z-50 flex items-center justify-end bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-md h-full bg-industrial-900 border-l border-industrial-700 p-6 shadow-2xl flex flex-col justify-between overflow-y-auto font-sans animate-in slide-in-from-right duration-200">
            {/* Drawer Header */}
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-industrial-800">
                <div className="flex items-center gap-2">
                  <Wrench className="w-5 h-5 text-cyan-400" />
                  <div>
                    <span className="text-[10px] font-mono uppercase text-cyan-400 font-bold block">
                      Subsystem Telemetry Inspection
                    </span>
                    <h3 className="text-lg font-bold text-slate-100 uppercase tracking-wide">
                      {selectedComponent.id.replace('_', ' ')}
                    </h3>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedComponentId(null)}
                  className="p-1 rounded bg-industrial-800 text-slate-400 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Health Score & Risk Tier */}
              <div className="bg-industrial-950 p-4 rounded-lg border border-industrial-800 space-y-3 font-mono">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400 font-bold uppercase">Health Score:</span>
                  <StatusChip status={selectedComponent.risk} size="md" />
                </div>

                <div className="flex items-baseline gap-2">
                  <span
                    className={`text-4xl font-extrabold ${
                      selectedComponent.score >= 75
                        ? 'text-emerald-400'
                        : selectedComponent.score >= 45
                        ? 'text-amber-400'
                        : 'text-red-400'
                    }`}
                  >
                    {selectedComponent.score}
                  </span>
                  <span className="text-slate-400 text-sm">/ 100</span>
                </div>

                <div className="w-full bg-industrial-900 rounded-full h-2 overflow-hidden">
                  <div
                    className={`h-full ${
                      selectedComponent.score >= 75
                        ? 'bg-emerald-500'
                        : selectedComponent.score >= 45
                        ? 'bg-amber-500'
                        : 'bg-red-500'
                    }`}
                    style={{ width: `${selectedComponent.score}%` }}
                  />
                </div>
              </div>

              {/* Predicted TTL Remaining Useful Life */}
              <div className="bg-industrial-950 p-4 rounded-lg border border-industrial-800 space-y-1 font-mono text-xs">
                <span className="text-slate-400 uppercase font-bold text-[10px] block">
                  Estimated Days Before Replacement
                </span>
                <div className="flex items-baseline justify-between">
                  <span className="text-2xl font-bold text-slate-100">
                    {selectedComponent.ttlDays} Days
                  </span>
                  <span className="text-slate-400 text-[11px]">
                    Expected Range: [{selectedComponent.ttlLowDays} - {selectedComponent.ttlHighDays}]
                  </span>
                </div>
              </div>

              {/* Top Contributing Degradation Factors */}
              <div className="bg-industrial-950 p-4 rounded-lg border border-industrial-800 space-y-3 font-mono text-xs">
                <h4 className="text-slate-300 font-bold uppercase tracking-wider text-[11px]">
                  What is Causing Wear
                </h4>

                <div className="space-y-2">
                  {selectedComponent.topFactors.map((f, idx) => (
                    <div key={idx} className="space-y-1">
                      <div className="flex justify-between text-slate-300 text-[11px]">
                        <span>{f.name}</span>
                        <span className="text-cyan-400 font-bold">{f.contribution}%</span>
                      </div>
                      <div className="w-full bg-industrial-900 rounded-full h-1.5 overflow-hidden">
                        <div
                          className="h-full bg-cyan-500"
                          style={{ width: `${f.contribution}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Bottom Navigation Button linking to Vibration Analysis */}
            <div className="pt-4 border-t border-industrial-800 space-y-2">
              <button
                onClick={() => {
                  setSelectedComponentId(null);
                  navigate('/vibration');
                }}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-mono font-bold text-xs transition-colors shadow-lg"
              >
                <span>Drill-Down: Vibration Analysis</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => setSelectedComponentId(null)}
                className="w-full py-2 px-4 rounded bg-industrial-800 hover:bg-industrial-700 text-slate-300 font-mono text-xs transition-colors"
              >
                Close Drawer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
