import React, { useState } from 'react';
import { exportCsv } from '../lib/dsp';
import { useElevatorStore } from '../store/useElevatorStore';
import { LiveVibrationChart } from '../components/vibration/LiveVibrationChart';
import { FftSpectrumChart } from '../components/vibration/FftSpectrumChart';
import { TrendChart } from '../components/vibration/TrendChart';
import {
  Activity,
  CheckCircle2,
  Download,
  FileSpreadsheet,
  Info,
  Layers,
  Sparkles,
  ToggleLeft,
  ToggleRight,
  TrendingUp,
  Waves,
  Zap,
} from 'lucide-react';

export const VibrationAnalysisPage: React.FC = () => {
  const vibrationBatches = useElevatorStore((state) => state.vibrationBatches);
  const latestVibrationRms = useElevatorStore((state) => state.latestVibrationRms);
  const scenario = useElevatorStore((state) => state.scenario);

  const [selectedAxis, setSelectedAxis] = useState<'x' | 'y' | 'z' | 'all'>('all');
  const [compareBaseline, setCompareBaseline] = useState<boolean>(true);
  const [timeWindowSec, setTimeWindowSec] = useState<number>(20);

  const zRms = latestVibrationRms.z;
  const isElevated = scenario === 'degrading' || zRms > 0.09;
  const hasShocks = scenario === 'fault_spike';

  // CSV Export handler
  const handleExportCsv = () => {
    const headers = ['Timestamp_ms', 'ISO_Time', 'Axis_X_g', 'Axis_Y_g', 'Axis_Z_g', 'Calculated_RMS_g'];
    const rows: (string | number)[][] = [];

    for (const b of vibrationBatches) {
      const dt = 1000 / b.sampleRateHz;
      for (let i = 0; i < b.x.length; i++) {
        const t = Math.round(b.ts + i * dt);
        const x = b.x[i];
        const y = b.y[i];
        const z = b.z[i];
        const rms = Number(Math.sqrt((x * x + y * y + z * z) / 3).toFixed(4));
        rows.push([t, new Date(t).toISOString(), x, y, z, rms]);
      }
    }

    exportCsv(`elevator-vibration-${Date.now()}`, headers, rows);
  };

  const handleExportPng = () => {
    window.print();
  };

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-sans">
      {/* Page Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-2 border-b border-industrial-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 mb-1">
            <Layers className="w-3.5 h-3.5" />
            <span>TRI-AXIAL TELEMETRY (1000 HZ)</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight text-slate-100 flex items-center gap-3">
            <span>Vibration Analysis &amp; Mechanical Insights</span>
          </h2>
          <p className="text-sm text-slate-400 mt-0.5">
            Real-time multi-axis vibration decomposition, harmonic frequency tracking, and ride comfort assessment.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 font-mono text-xs">
          <button
            onClick={() => setCompareBaseline(!compareBaseline)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded transition-all border ${
              compareBaseline
                ? 'bg-cyan-950 text-cyan-300 border-cyan-800'
                : 'bg-industrial-950 text-slate-400 border-industrial-800 hover:text-slate-200'
            }`}
          >
            {compareBaseline ? <ToggleRight className="w-4 h-4 text-cyan-400" /> : <ToggleLeft className="w-4 h-4 text-slate-500" />}
            <span>Compare Normal Baseline</span>
          </button>

          <button
            onClick={handleExportCsv}
            title="Download CSV of vibration buffer"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-industrial-800 hover:bg-industrial-700 text-slate-200 border border-industrial-700 transition-colors"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={handleExportPng}
            title="Print or save as PDF"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-industrial-800 hover:bg-industrial-700 text-slate-200 border border-industrial-700 transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>Print Report</span>
          </button>
        </div>
      </div>

      {/* 1. MECHANICAL INSIGHTS BANNER CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
        {/* Insight 1: Vibration Level & Ride Comfort */}
        <div className="bg-industrial-900 border border-industrial-800 rounded-lg p-4 space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="flex items-center gap-1.5 font-bold text-slate-200 text-xs">
              <Waves className="w-4 h-4 text-cyan-400" /> 1. VIBRATION ENERGY
            </span>
            <span className="text-[10px] text-cyan-400">Z-Axis</span>
          </div>
          <div className="text-xl font-extrabold text-slate-100">
            {zRms.toFixed(3)} g RMS
          </div>
          <p className="text-slate-400 text-[11px] leading-relaxed">
            {isElevated
              ? 'Vibration levels are rising above normal baseline. Guide shoes are experiencing moderate surface friction.'
              : 'Shaking levels stay under 0.08 g. Passenger ride is rated Smooth and within normal operating standards.'}
          </p>
        </div>

        {/* Insight 2: Guide Shoe Roller Wear Frequency */}
        <div className="bg-industrial-900 border border-industrial-800 rounded-lg p-4 space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="flex items-center gap-1.5 font-bold text-slate-200 text-xs">
              <Sparkles className="w-4 h-4 text-emerald-400" /> 2. ROLLER RESONANCE
            </span>
            <span className="text-[10px] text-emerald-400">45 Hz Peak</span>
          </div>
          <div className="text-xl font-extrabold text-emerald-400">
            {isElevated ? 'Elevated Roller Wear' : 'Healthy Contact'}
          </div>
          <p className="text-slate-400 text-[11px] leading-relaxed">
            {isElevated
              ? 'Energy at 45 Hz has climbed to ~2.8x baseline. This frequency corresponds to guide roller lining wear.'
              : 'The 45 Hz guide shoe roller frequency aligns with normal factory baseline (under 1.2x envelope).'}
          </p>
        </div>

        {/* Insight 3: Track Shocks & Joint Impacts */}
        <div className="bg-industrial-900 border border-industrial-800 rounded-lg p-4 space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="flex items-center gap-1.5 font-bold text-slate-200 text-xs">
              <Zap className="w-4 h-4 text-amber-400" /> 3. RAIL JOINT IMPACTS
            </span>
            <span className="text-[10px] text-amber-400">Shock Spikes</span>
          </div>
          <div className={`text-xl font-extrabold ${hasShocks ? 'text-red-400' : 'text-slate-100'}`}>
            {hasShocks ? 'Shock Spikes Active' : 'Smooth Rail Travel'}
          </div>
          <p className="text-slate-400 text-[11px] leading-relaxed">
            {hasShocks
              ? 'Intermittent shock spikes detected (>0.25 g). The car is hitting uneven rail fishplates or joint gaps.'
              : 'No mechanical joint shocks detected. Track connections are flush with uniform blade transitions.'}
          </p>
        </div>
      </div>

      {/* 2. LIVE WAVEFORM CHART */}
      <LiveVibrationChart timeWindowSec={timeWindowSec} />

      {/* 3. FREQUENCY SPECTRUM & HISTORICAL 30-DAY TREND */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <FftSpectrumChart
          selectedAxis={selectedAxis}
          compareBaseline={compareBaseline}
        />

        <TrendChart />
      </div>
    </div>
  );
};
