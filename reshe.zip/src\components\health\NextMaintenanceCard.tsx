import React from 'react';
import { APP_CONFIG } from '../../config';
import { useElevatorStore } from '../../store/useElevatorStore';
import type { ComponentId } from '../../types';
import { StatusChip } from '../StatusChip';
import { Calendar, Clock, Plus, ShieldCheck, Wrench } from 'lucide-react';

export interface NextMaintenanceCardProps {
  onOpenLogModal: (preselectedComp?: ComponentId) => void;
}

export const NextMaintenanceCard: React.FC<NextMaintenanceCardProps> = ({ onOpenLogModal }) => {
  const getNextDueDate = useElevatorStore((state) => state.getNextDueDate);
  const { dueDate, daysRemaining, component } = getNextDueDate();

  const isUrgent = daysRemaining <= 14;
  const isCritical = daysRemaining <= 7;

  return (
    <div
      className={`bg-industrial-900 rounded-lg p-5 border transition-all flex flex-col justify-between font-sans ${
        isCritical
          ? 'border-red-600/80 shadow-[0_0_15px_rgba(239,68,68,0.15)] ring-1 ring-red-500/40'
          : isUrgent
          ? 'border-amber-600/80 shadow-[0_0_12px_rgba(245,158,11,0.12)]'
          : 'border-industrial-800'
      }`}
    >
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-industrial-800">
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-cyan-400" />
          <h3 className="text-sm font-mono font-bold uppercase tracking-wider text-slate-100">
            Next Recommended Service Date
          </h3>
        </div>
        <StatusChip
          status={isCritical ? 'critical' : isUrgent ? 'warning' : 'healthy'}
          size="sm"
          showPulse={isCritical}
        />
      </div>

      {/* Main Content */}
      <div className="my-3 space-y-3">
        <div>
          <span className="text-[10px] font-mono text-slate-400 uppercase font-semibold block">
            Recommended Date (Includes {APP_CONFIG.MAINTENANCE.SAFETY_MARGIN_DAYS}-day Safety Buffer)
          </span>
          <div className="flex flex-wrap items-baseline gap-2 mt-0.5">
            <span className="text-2xl sm:text-3xl font-mono font-extrabold text-slate-100">
              {dueDate.toLocaleDateString(undefined, {
                weekday: 'short',
                year: 'numeric',
                month: 'short',
                day: 'numeric',
              })}
            </span>
            <span
              className={`text-xs font-mono font-bold px-2 py-0.5 rounded border ${
                isCritical
                  ? 'bg-red-950 text-red-300 border-red-700 animate-pulse'
                  : isUrgent
                  ? 'bg-amber-950 text-amber-300 border-amber-700'
                  : 'bg-emerald-950 text-emerald-300 border-emerald-800'
              }`}
            >
              in {daysRemaining} days
            </span>
          </div>
        </div>

        {/* Driving Component Box */}
        <div className="bg-industrial-950/80 p-3 rounded border border-industrial-800/80 font-mono text-xs flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-500 block">Needs Service First:</span>
            <span className="font-bold text-slate-200 uppercase text-sm">
              {component.id.replace('_', ' ')}
            </span>
          </div>
          <div className="text-right">
            <span className="text-[10px] text-slate-500 block">Estimated Remaining Days:</span>
            <span className="text-slate-300 font-bold">{component.ttlDays} Days</span>
          </div>
        </div>
      </div>

      {/* Action / Schedule Button */}
      <div className="pt-2 border-t border-industrial-800/80 flex flex-wrap items-center justify-between gap-2">
        <span className="text-[11px] font-mono text-slate-500">
          Safety Buffer: {APP_CONFIG.MAINTENANCE.SAFETY_MARGIN_DAYS} days before lower CI limit
        </span>
        <button
          onClick={() => onOpenLogModal(component.id)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold font-mono text-xs transition-colors shadow-sm"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Log Service for {component.id.replace('_', ' ')}</span>
        </button>
      </div>
    </div>
  );
};
