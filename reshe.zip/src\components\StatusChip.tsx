import React from 'react';
import type { RiskLevel, SystemStatus, WidgetState } from '../types';
import {
  CheckCircle2,
  AlertTriangle,
  AlertOctagon,
  HelpCircle,
  Clock,
  Loader2,
} from 'lucide-react';

export type StatusChipType = SystemStatus | RiskLevel | 'stale' | 'loading' | 'no-data';

export interface StatusChipProps {
  status?: StatusChipType;
  label?: string;
  size?: 'sm' | 'md' | 'lg';
  showPulse?: boolean;
  className?: string;
  state?: WidgetState; // State handling: loading / no-data / stale / normal
}

export const StatusChip: React.FC<StatusChipProps> = ({
  status = 'nodata',
  label,
  size = 'md',
  showPulse = false,
  className = '',
  state = 'normal',
}) => {
  // If outer widget state is loading or no-data or stale, reflect that
  let effectiveStatus: StatusChipType = status;
  let effectiveLabel = label;

  if (state === 'loading') {
    effectiveStatus = 'loading';
    effectiveLabel = label || 'LOADING';
  } else if (state === 'no-data') {
    effectiveStatus = 'no-data';
    effectiveLabel = label || 'NO DATA';
  } else if (state === 'stale') {
    effectiveStatus = 'stale';
    effectiveLabel = label ? `${label} (STALE)` : 'STALE';
  }

  const getConfig = () => {
    switch (effectiveStatus) {
      case 'healthy':
      case 'low':
        return {
          icon: <CheckCircle2 className="shrink-0" />,
          defaultLabel: 'HEALTHY',
          classes: 'bg-emerald-950/80 text-emerald-400 border-emerald-800/80 shadow-[0_0_8px_rgba(16,185,129,0.15)]',
          pulseColor: 'bg-emerald-400',
        };
      case 'warning':
      case 'medium':
        return {
          icon: <AlertTriangle className="shrink-0" />,
          defaultLabel: 'WARNING',
          classes: 'bg-amber-950/80 text-amber-400 border-amber-800/80 shadow-[0_0_8px_rgba(245,158,11,0.15)]',
          pulseColor: 'bg-amber-400',
        };
      case 'critical':
      case 'high':
        return {
          icon: <AlertOctagon className="shrink-0" />,
          defaultLabel: 'CRITICAL',
          classes: 'bg-red-950/80 text-red-400 border-red-800/80 shadow-[0_0_8px_rgba(239,68,68,0.2)]',
          pulseColor: 'bg-red-400',
        };
      case 'stale':
        return {
          icon: <Clock className="shrink-0" />,
          defaultLabel: 'STALE DATA',
          classes: 'bg-amber-950/60 text-amber-300 border-amber-700/60 shadow-[0_0_6px_rgba(245,158,11,0.2)]',
          pulseColor: 'bg-amber-400',
        };
      case 'loading':
        return {
          icon: <Loader2 className="shrink-0 animate-spin" />,
          defaultLabel: 'LOADING',
          classes: 'bg-cyan-950/50 text-cyan-300 border-cyan-800/60',
          pulseColor: 'bg-cyan-400',
        };
      case 'nodata':
      case 'no-data':
      default:
        return {
          icon: <HelpCircle className="shrink-0" />,
          defaultLabel: 'NO DATA',
          classes: 'bg-slate-900/80 text-slate-400 border-slate-700/80',
          pulseColor: 'bg-slate-400',
        };
    }
  };

  const { icon, defaultLabel, classes, pulseColor } = getConfig();

  const sizeClasses = {
    sm: 'px-2 py-0.5 text-[10px] gap-1 [&>svg]:w-3 [&>svg]:h-3',
    md: 'px-2.5 py-1 text-xs gap-1.5 [&>svg]:w-3.5 [&>svg]:h-3.5',
    lg: 'px-3 py-1.5 text-sm gap-2 [&>svg]:w-4 [&>svg]:h-4',
  }[size];

  return (
    <span
      className={`inline-flex items-center font-mono font-semibold uppercase tracking-wider rounded border transition-all select-none ${classes} ${sizeClasses} ${className}`}
    >
      {showPulse && (
        <span className={`w-1.5 h-1.5 rounded-full ${pulseColor} animate-ping mr-0.5`} />
      )}
      {icon}
      <span>{effectiveLabel || defaultLabel}</span>
    </span>
  );
};
