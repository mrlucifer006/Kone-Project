import React from 'react';
import { useElevatorStore } from '../../store/useElevatorStore';
import type { ComponentId } from '../../types';
import { StatusChip } from '../StatusChip';
import {
  Activity,
  ArrowRight,
  Clock,
  Layers,
  Wrench,
  Zap,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export const ComponentCards: React.FC = () => {
  const navigate = useNavigate();
  const healthMap = useElevatorStore((state) => state.healthMap);
  const latestVibrationRms = useElevatorStore((state) => state.latestVibrationRms);

  const componentOrder: { id: ComponentId; title: string; subtitle: string; icon: React.ReactNode }[] = [
    {
      id: 'guide_shoes',
      title: 'Guide Shoes',
      subtitle: 'Rollers & guide liners',
      icon: <Layers className="w-4 h-4 text-cyan-400" />,
    },
    {
      id: 'guide_rails',
      title: 'Guide Rails',
      subtitle: 'Steel rail track alignment',
      icon: <Activity className="w-4 h-4 text-emerald-400" />,
    },
    {
      id: 'rail_joints',
      title: 'Rail Joints',
      subtitle: 'Joint plates & gap connections',
      icon: <Zap className="w-4 h-4 text-amber-400" />,
    },
    {
      id: 'car_frame',
      title: 'Car Frame',
      subtitle: 'Car chassis & rubber dampers',
      icon: <Wrench className="w-4 h-4 text-purple-400" />,
    },
  ];

  // Helper to generate SVG sparkline path
  const generateSparklinePath = (id: ComponentId, score: number) => {
    // 12 points across width 120, height 28
    const points: [number, number][] = [];
    const width = 120;
    const height = 28;
    const count = 12;

    for (let i = 0; i < count; i++) {
      const x = (i / (count - 1)) * width;
      // Synthesize smooth wave correlated with health score & RMS
      const wave = Math.sin(i * 0.8 + (score / 20)) * 6;
      const noise = (Math.sin(i * 2.3) * 3);
      // Higher score -> higher up (lower Y in SVG)
      const normalizedScoreY = height - ((score / 100) * (height - 10) + 5);
      const y = Math.max(3, Math.min(height - 3, normalizedScoreY + wave + noise));
      points.push([x, y]);
    }

    return points.reduce((acc, [px, py], idx) => {
      return idx === 0 ? `M ${px} ${py}` : `${acc} L ${px} ${py}`;
    }, '');
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {componentOrder.map(({ id, title, subtitle, icon }) => {
        const comp = healthMap[id];
        if (!comp) return null;

        const isCritical = comp.risk === 'high';
        const isWarning = comp.risk === 'medium';

        const strokeColor = isCritical ? '#ef4444' : isWarning ? '#f59e0b' : '#10b981';

        return (
          <div
            key={id}
            onClick={() => navigate('/maintenance')}
            className={`cursor-pointer bg-industrial-900 rounded-lg p-4 border transition-all duration-200 flex flex-col justify-between hover:border-industrial-700 hover:shadow-lg ${
              isCritical
                ? 'border-red-600/70 shadow-[0_0_12px_rgba(239,68,68,0.15)] ring-1 ring-red-500/40'
                : isWarning
                ? 'border-amber-600/60 shadow-[0_0_12px_rgba(245,158,11,0.1)]'
                : 'border-industrial-800'
            }`}
          >
            {/* Top Subsystem Label & Status Chip */}
            <div className="flex items-start justify-between gap-2 mb-2">
              <div className="space-y-0.5">
                <div className="flex items-center gap-1.5">
                  {icon}
                  <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-100">
                    {title}
                  </h4>
                </div>
                <p className="text-[11px] text-slate-500 font-sans line-clamp-1">
                  {subtitle}
                </p>
              </div>
              <StatusChip status={comp.risk} size="sm" showPulse={isCritical} />
            </div>

            {/* Score & Sparkline Row */}
            <div className="my-2 flex items-center justify-between gap-2">
              <div>
                <span className="text-[10px] font-mono text-slate-400 uppercase block">
                  Health Score
                </span>
                <div className="flex items-baseline gap-1.5">
                  <span
                    className={`text-3xl font-mono font-bold tracking-tight ${
                      comp.score >= 75
                        ? 'text-emerald-400'
                        : comp.score >= 45
                        ? 'text-amber-400'
                        : 'text-red-400'
                    }`}
                  >
                    {comp.score}
                  </span>
                  <span className="text-xs font-mono text-slate-500">/ 100</span>
                </div>
              </div>

              {/* Sparkline Graphic */}
              <div className="flex flex-col items-end">
                <span className="text-[9px] font-mono text-slate-500 uppercase block mb-0.5">
                  24h Wear Trend
                </span>
                <svg width="110" height="28" className="overflow-visible">
                  <path
                    d={generateSparklinePath(id, comp.score)}
                    fill="none"
                    stroke={strokeColor}
                    strokeWidth="2"
                    strokeLinecap="round"
                  />
                </svg>
              </div>
            </div>

            {/* Bottom TTL & Action Link */}
            <div className="pt-2 border-t border-industrial-800/80 flex items-center justify-between text-[11px] font-mono text-slate-400">
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3 text-cyan-400" />
                <span>Est. Life: <strong className="text-slate-200">{comp.ttlDays} Days</strong></span>
              </span>
              <span className="text-cyan-400 hover:text-cyan-300 flex items-center gap-0.5 font-bold">
                Details <ArrowRight className="w-3 h-3" />
              </span>
            </div>
          </div>
        );
      })}
    </div>
  );
};
