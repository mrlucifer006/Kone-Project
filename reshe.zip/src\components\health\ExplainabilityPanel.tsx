import React from 'react';
import type { ComponentHealth } from '../../types';
import { Activity, HelpCircle, Layers, Sparkles } from 'lucide-react';

export interface ExplainabilityPanelProps {
  component: ComponentHealth;
}

export const ExplainabilityPanel: React.FC<ExplainabilityPanelProps> = ({ component }) => {
  const { id, score, topFactors, risk } = component;

  return (
    <div className="bg-industrial-900 border border-industrial-800 rounded-lg p-5 flex flex-col justify-between font-sans space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-industrial-800">
        <div>
          <span className="text-[10px] font-mono text-cyan-400 font-bold uppercase tracking-wider block">
            PART WEAR BREAKDOWN
          </span>
          <h3 className="text-base font-bold text-slate-100 uppercase tracking-wide flex items-center gap-2">
            <span>{id.replace('_', ' ')}: What is Causing Wear?</span>
          </h3>
        </div>

        <span className="text-xs font-mono text-slate-400">
          Current Health:{' '}
          <strong
            className={
              score >= 75 ? 'text-emerald-400' : score >= 45 ? 'text-amber-400' : 'text-red-400'
            }
          >
            {score}/100
          </strong>
        </span>
      </div>

      {/* Horizontal Bar Chart of topFactors */}
      <div className="space-y-3 font-mono text-xs">
        {topFactors.length === 0 ? (
          <div className="p-4 text-center text-slate-500 text-xs">
            No dominant degradation factors identified; operating within baseline envelope.
          </div>
        ) : (
          topFactors.map((factor, idx) => {
            const isHigh = factor.contribution > 35;
            const isMedium = factor.contribution > 15;

            const barColor = isHigh
              ? 'bg-red-500'
              : isMedium
              ? 'bg-amber-500'
              : 'bg-cyan-500';

            return (
              <div key={idx} className="space-y-1">
                <div className="flex justify-between text-slate-300 text-xs">
                  <span className="font-semibold">{factor.name}</span>
                  <span className="font-bold text-cyan-400">
                    {factor.contribution}% contribution
                  </span>
                </div>
                <div className="w-full bg-industrial-950 rounded-full h-2.5 overflow-hidden border border-industrial-800 p-0.5">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${barColor}`}
                    style={{ width: `${Math.min(100, factor.contribution)}%` }}
                  />
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Footer */}
      <div className="pt-2 border-t border-industrial-800/80 flex items-center justify-between text-[11px] font-mono text-slate-400">
        <span>Attributed relative impact on degradation rate</span>
        <span className="text-slate-500 italic">Total normalized: 100%</span>
      </div>
    </div>
  );
};
