import { APP_CONFIG } from '../config';
import type {
  Alert,
  ComponentHealth,
  MotionState,
  SimulationScenario,
  TripState,
  VibrationBatch,
  VisionResult,
} from '../types';

export interface MockGeneratorCallbacks {
  onVibration: (batch: VibrationBatch) => void;
  onMotion: (state: MotionState) => void;
  onVision: (result: VisionResult) => void;
  onHealth: (health: ComponentHealth[]) => void;
  onAlert: (alert: Alert) => void;
}

export class MockDataGenerator {
  private scenario: SimulationScenario = 'healthy';
  private scenarioStartTime: number = Date.now();
  private isRunning: boolean = false;
  private isPaused: boolean = false;

  private vibrationTimer: ReturnType<typeof setInterval> | null = null;
  private telemetryTimer: ReturnType<typeof setInterval> | null = null;

  // Track absolute time for continuous wave phases
  private continuousSampleIndex: number = 0;
  private frameCounter: number = 0;

  // Elevator kinematics simulation state
  private elevatorPosition: number = 0; // meters from ground
  private elevatorSpeed: number = 0; // m/s
  private currentFloor: number = 1;
  private targetFloor: number = 10;
  private tripState: TripState = 'stopped';
  private floorDwellRemainingSec: number = 2.0;

  // Alert tracking for threshold transitions to prevent flooding
  private lastAlertState = {
    deviationWarning: false,
    deviationCritical: false,
    rmsWarning: false,
    rmsCritical: false,
    lastShockAlertTime: 0,
  };

  private callbacks: Partial<MockGeneratorCallbacks> = {};

  constructor(callbacks?: Partial<MockGeneratorCallbacks>) {
    if (callbacks) {
      this.callbacks = callbacks;
    }
  }

  public setCallbacks(callbacks: Partial<MockGeneratorCallbacks>) {
    this.callbacks = { ...this.callbacks, ...callbacks };
  }

  public setScenario(scenario: SimulationScenario) {
    if (this.scenario !== scenario) {
      this.scenario = scenario;
      this.scenarioStartTime = Date.now();
      // Reset alert debounce states when scenario changes
      this.lastAlertState = {
        deviationWarning: false,
        deviationCritical: false,
        rmsWarning: false,
        rmsCritical: false,
        lastShockAlertTime: 0,
      };
    }
  }

  public getScenario(): SimulationScenario {
    return this.scenario;
  }

  public pause() {
    this.isPaused = true;
  }

  public resume() {
    this.isPaused = false;
  }

  public getIsPaused(): boolean {
    return this.isPaused;
  }

  public start() {
    if (this.isRunning) return;
    this.isRunning = true;
    this.scenarioStartTime = Date.now();

    // 1. Vibration Batch Timer (every 250ms = 4 Hz delivering 250 samples @ 1000 Hz)
    this.vibrationTimer = setInterval(() => {
      this.generateVibrationBatch();
    }, APP_CONFIG.VIBRATION.BATCH_INTERVAL_MS);

    // 2. Slow Telemetry Timer (every 600ms = ~1.67 Hz within 1-2 Hz)
    this.telemetryTimer = setInterval(() => {
      this.generateTelemetryUpdates();
    }, APP_CONFIG.TELEMETRY.INTERVAL_MS);
  }

  public stop() {
    this.isRunning = false;
    if (this.vibrationTimer !== null) {
      clearInterval(this.vibrationTimer);
      this.vibrationTimer = null;
    }
    if (this.telemetryTimer !== null) {
      clearInterval(this.telemetryTimer);
      this.telemetryTimer = null;
    }
  }

  // --------------------------------------------------------------------------
  // Vibration Waveform Synthesis (1000 Hz)
  // --------------------------------------------------------------------------
  private generateVibrationBatch() {
    if (this.isPaused) return;
    const now = Date.now();
    const count = APP_CONFIG.VIBRATION.SAMPLES_PER_BATCH;
    const sampleRate = APP_CONFIG.VIBRATION.SAMPLE_RATE_HZ;
    const dt = 1 / sampleRate;

    const x = new Array<number>(count);
    const y = new Array<number>(count);
    const z = new Array<number>(count);

    const elapsedScenarioSec = (now - this.scenarioStartTime) / 1000;

    // Degrade progression: over 300s (5 minutes), progress from 0.0 to 1.0
    const degradeFactor = this.scenario === 'degrading'
      ? Math.min(1.0, elapsedScenarioSec / 300)
      : 0;

    for (let i = 0; i < count; i++) {
      const t = (this.continuousSampleIndex + i) * dt;

      // Base Gaussian-like random noise (Box-Muller or uniform sum approximation)
      const u1 = Math.random() || 0.0001;
      const u2 = Math.random() || 0.0001;
      const gaussNoise = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);

      let xVal = 0;
      let yVal = 0;
      let zVal = 0;

      if (this.scenario === 'healthy') {
        // "healthy": z-axis noise around 0.05 g with small periodic components near 12 Hz and 45 Hz
        const comp12Hz = 0.018 * Math.sin(2 * Math.PI * 12.2 * t);
        const comp45Hz = 0.012 * Math.sin(2 * Math.PI * 44.8 * t);
        const noise = gaussNoise * 0.015;

        zVal = 0.05 + comp12Hz + comp45Hz + noise;
        xVal = 0.015 * Math.sin(2 * Math.PI * 6.5 * t) + gaussNoise * 0.008;
        yVal = 0.02 * Math.sin(2 * Math.PI * 8.1 * t) + gaussNoise * 0.009;
      } else if (this.scenario === 'degrading') {
        // "degrading": over ~5 minutes, energy at 45 Hz and overall RMS slowly rise
        const amp45 = 0.048 + degradeFactor * 0.16; // 45 Hz climbs from 0.048g (~4x baseline) to ~0.208g
        const comp45Hz = amp45 * Math.sin(2 * Math.PI * 44.8 * t);
        const comp12Hz = (0.018 + degradeFactor * 0.04) * Math.sin(2 * Math.PI * 12.2 * t);
        const baseOffset = 0.05 + degradeFactor * 0.10;
        const noise = gaussNoise * (0.015 + degradeFactor * 0.05);

        zVal = baseOffset + comp12Hz + comp45Hz + noise;
        xVal = (0.015 + degradeFactor * 0.07) * Math.sin(2 * Math.PI * 6.5 * t) + gaussNoise * 0.02;
        yVal = (0.020 + degradeFactor * 0.09) * Math.sin(2 * Math.PI * 8.1 * t) + gaussNoise * 0.025;
      } else if (this.scenario === 'fault_spike') {
        // "fault_spike": healthy baseline plus periodic shock events (every ~8 s)
        const comp12Hz = 0.018 * Math.sin(2 * Math.PI * 12.2 * t);
        const comp45Hz = 0.012 * Math.sin(2 * Math.PI * 44.8 * t);
        const noise = gaussNoise * 0.015;

        zVal = 0.05 + comp12Hz + comp45Hz + noise;
        xVal = 0.015 * Math.sin(2 * Math.PI * 6.5 * t) + gaussNoise * 0.008;
        yVal = 0.020 * Math.sin(2 * Math.PI * 8.1 * t) + gaussNoise * 0.009;

        // Shock impulse every ~8 seconds (lasts ~0.20s)
        const shockCycleSec = 8.0;
        const timeInCycle = t % shockCycleSec;
        if (timeInCycle < 0.22) {
          // Damped transient shock wave
          const shockT = timeInCycle;
          const decay = Math.exp(-shockT * 22);
          const shockWave = Math.sin(2 * Math.PI * 85 * shockT) * decay * 0.65;
          zVal += shockWave;
          xVal += shockWave * 0.6;
          yVal += shockWave * 0.8;
        }
      }

      x[i] = Number(xVal.toFixed(5));
      y[i] = Number(yVal.toFixed(5));
      z[i] = Number(zVal.toFixed(5));
    }

    this.continuousSampleIndex += count;

    if (this.callbacks.onVibration) {
      this.callbacks.onVibration({
        ts: now,
        sampleRateHz: sampleRate,
        x,
        y,
        z,
      });
    }
  }

  // --------------------------------------------------------------------------
  // Telemetry: Motion, Vision, Component Health, & Threshold Alerts
  // --------------------------------------------------------------------------
  private generateTelemetryUpdates() {
    if (this.isPaused) return;
    const now = Date.now();
    const dtSec = APP_CONFIG.TELEMETRY.INTERVAL_MS / 1000;
    const elapsedSec = (now - this.scenarioStartTime) / 1000;
    const degradeFactor = this.scenario === 'degrading'
      ? Math.min(1.0, elapsedSec / 300)
      : 0;

    // 1. Elevator Kinematics Simulation
    this.updateElevatorKinematics(dtSec);

    const motionState: MotionState = {
      ts: now,
      accelMs2: this.calculateInstantaneousAccel(),
      speedMs: Number(this.elevatorSpeed.toFixed(2)),
      floor: this.currentFloor,
      position_m: Number(this.elevatorPosition.toFixed(2)),
      tripState: this.tripState,
    };

    if (this.callbacks.onMotion) {
      this.callbacks.onMotion(motionState);
    }

    // 2. Vision Result Generation
    this.frameCounter++;
    let deviationMm = 0.35 + (Math.random() - 0.5) * 0.06;
    let angleDeg = 0.02 + (Math.random() - 0.5) * 0.02;
    let confidence = 0.98 - Math.random() * 0.02;

    if (this.scenario === 'degrading') {
      // Rail deviation drifts from 0.3 mm to 2.5 mm
      deviationMm = 0.3 + degradeFactor * 2.2 + (Math.random() - 0.5) * 0.08;
      angleDeg = 0.02 + degradeFactor * 0.45 + (Math.random() - 0.5) * 0.04;
      confidence = Math.max(0.75, 0.98 - degradeFactor * 0.15 - Math.random() * 0.04);
    } else if (this.scenario === 'fault_spike') {
      // Baseline elevated deviation with shock impulses every ~8s
      deviationMm = 1.4 + (Math.random() - 0.5) * 0.15;
      angleDeg = 0.25 + (Math.random() - 0.5) * 0.05;
      confidence = 0.92;

      // Periodic sudden shock event (every ~8s, including immediately at t=0)
      const timeInCycle = (elapsedSec) % 8.0;
      if (timeInCycle < 1.2) {
        // Severe sudden deviation jump
        deviationMm = 2.55 + Math.random() * 0.45;
        angleDeg = 1.15 + Math.random() * 0.4;
        confidence = 0.81 - Math.random() * 0.05;

        // Trigger shock alert
        if (now - this.lastAlertState.lastShockAlertTime > 5000) {
          this.lastAlertState.lastShockAlertTime = now;
          this.dispatchAlert({
            id: `alert-shock-${now}`,
            ts: now,
            severity: 'critical',
            component: 'rail_joints',
            message: `Transient shock impulse detected at floor ${this.currentFloor}: lateral deviation ${deviationMm.toFixed(2)} mm!`,
            acknowledged: false,
          });
        }
      }
    }

    const visionResult: VisionResult = {
      ts: now,
      frameId: this.frameCounter,
      deviationMm: Number(deviationMm.toFixed(3)),
      angleDeg: Number(angleDeg.toFixed(3)),
      confidence: Number(confidence.toFixed(3)),
    };

    if (this.callbacks.onVision) {
      this.callbacks.onVision(visionResult);
    }

    // 3. Component Health Evaluation
    const healthList = this.calculateComponentHealth(degradeFactor);
    if (this.callbacks.onHealth) {
      this.callbacks.onHealth(healthList);
    }

    // 4. Threshold Alert Checks
    this.evaluateThresholds(visionResult.deviationMm, degradeFactor, now);
  }

  // --------------------------------------------------------------------------
  // Health Calculations & Factors
  // --------------------------------------------------------------------------
  private calculateComponentHealth(degradeFactor: number): ComponentHealth[] {
    if (this.scenario === 'healthy') {
      return [
        {
          id: 'guide_shoes',
          score: 96,
          risk: 'low',
          ttlDays: 240,
          ttlLowDays: 210,
          ttlHighDays: 270,
          topFactors: [
            { name: 'Linear Bushing Wear', contribution: 12 },
            { name: 'Lubricant Film Thickness', contribution: 8 },
          ],
        },
        {
          id: 'guide_rails',
          score: 94,
          risk: 'low',
          ttlDays: 210,
          ttlLowDays: 185,
          ttlHighDays: 235,
          topFactors: [
            { name: 'Profile Alignment Error', contribution: 10 },
            { name: 'Surface Roughness Ra', contribution: 9 },
          ],
        },
        {
          id: 'rail_joints',
          score: 97,
          risk: 'low',
          ttlDays: 280,
          ttlLowDays: 250,
          ttlHighDays: 310,
          topFactors: [
            { name: 'Fishplate Gap Tolerances', contribution: 11 },
            { name: 'Step-offset Vibration', contribution: 7 },
          ],
        },
        {
          id: 'car_frame',
          score: 99,
          risk: 'low',
          ttlDays: 360,
          ttlLowDays: 330,
          ttlHighDays: 390,
          topFactors: [
            { name: 'Structural Torsion', contribution: 6 },
            { name: 'Isolation Pad Stiffness', contribution: 5 },
          ],
        },
      ];
    }

    if (this.scenario === 'degrading') {
      // Over ~5 minutes: health scores decline, TTL shrinks
      const shoesScore = Math.max(22, Math.round(96 - degradeFactor * 68));
      const railsScore = Math.max(18, Math.round(94 - degradeFactor * 74));
      const jointsScore = Math.max(28, Math.round(97 - degradeFactor * 62));
      const frameScore = Math.max(52, Math.round(99 - degradeFactor * 42));

      const calcRisk = (score: number) => {
        if (score >= APP_CONFIG.THRESHOLDS.HEALTH_SCORE.HEALTHY_MIN) return 'low';
        if (score >= APP_CONFIG.THRESHOLDS.HEALTH_SCORE.WARNING_MIN) return 'medium';
        return 'high';
      };

      const railsTTL = Math.max(6, Math.round(210 - degradeFactor * 201));
      const shoesTTL = Math.max(9, Math.round(240 - degradeFactor * 228));
      const jointsTTL = Math.max(14, Math.round(280 - degradeFactor * 261));
      const frameTTL = Math.max(48, Math.round(360 - degradeFactor * 300));

      return [
        {
          id: 'guide_rails',
          score: railsScore,
          risk: calcRisk(railsScore),
          ttlDays: railsTTL,
          ttlLowDays: Math.max(3, railsTTL - 4),
          ttlHighDays: railsTTL + 6,
          topFactors: [
            { name: '45Hz Rail Resonant Wear', contribution: Math.round(25 + degradeFactor * 55) },
            { name: 'Lateral Profile Deviation', contribution: Math.round(20 + degradeFactor * 45) },
            { name: 'Surface Micro-pitting', contribution: Math.round(15 + degradeFactor * 25) },
          ],
        },
        {
          id: 'guide_shoes',
          score: shoesScore,
          risk: calcRisk(shoesScore),
          ttlDays: shoesTTL,
          ttlLowDays: Math.max(4, shoesTTL - 5),
          ttlHighDays: shoesTTL + 8,
          topFactors: [
            { name: 'Roller Lining Thinning', contribution: Math.round(30 + degradeFactor * 40) },
            { name: 'Bushing Mechanical Backlash', contribution: Math.round(18 + degradeFactor * 35) },
          ],
        },
        {
          id: 'rail_joints',
          score: jointsScore,
          risk: calcRisk(jointsScore),
          ttlDays: jointsTTL,
          ttlLowDays: Math.max(5, jointsTTL - 6),
          ttlHighDays: jointsTTL + 10,
          topFactors: [
            { name: 'Fishplate Bolt Loosening', contribution: Math.round(22 + degradeFactor * 48) },
            { name: 'Joint Gap Widening', contribution: Math.round(15 + degradeFactor * 35) },
          ],
        },
        {
          id: 'car_frame',
          score: frameScore,
          risk: calcRisk(frameScore),
          ttlDays: frameTTL,
          ttlLowDays: Math.max(20, frameTTL - 15),
          ttlHighDays: frameTTL + 25,
          topFactors: [
            { name: 'Transferred Chassis Vibration', contribution: Math.round(12 + degradeFactor * 38) },
            { name: 'Isolation Damper Fatigue', contribution: Math.round(10 + degradeFactor * 25) },
          ],
        },
      ];
    }

    // 'fault_spike' scenario: rail_joints severely impacted by shock impulses (turns RED)
    return [
      {
        id: 'rail_joints',
        score: 34,
        risk: 'high',
        ttlDays: 9,
        ttlLowDays: 5,
        ttlHighDays: 14,
        topFactors: [
          { name: 'Step-offset Shock Impact', contribution: 78 },
          { name: 'Fishplate Structural Stress', contribution: 21 },
        ],
      },
      {
        id: 'guide_shoes',
        score: 65,
        risk: 'medium',
        ttlDays: 45,
        ttlLowDays: 32,
        ttlHighDays: 60,
        topFactors: [
          { name: 'Impulse Rebound Chatter', contribution: 55 },
          { name: 'Guide Spring Compression', contribution: 30 },
        ],
      },
      {
        id: 'guide_rails',
        score: 82,
        risk: 'low',
        ttlDays: 140,
        ttlLowDays: 120,
        ttlHighDays: 160,
        topFactors: [
          { name: 'Localized Rail Scuffing', contribution: 40 },
          { name: 'Surface Roughness Ra', contribution: 22 },
        ],
      },
      {
        id: 'car_frame',
        score: 91,
        risk: 'low',
        ttlDays: 290,
        ttlLowDays: 260,
        ttlHighDays: 320,
        topFactors: [
          { name: 'Transient Frame Shock', contribution: 35 },
          { name: 'Isolation Pad Stiffness', contribution: 12 },
        ],
      },
    ];
  }

  // --------------------------------------------------------------------------
  // Threshold Evaluation & Alert Generation
  // --------------------------------------------------------------------------
  private evaluateThresholds(deviationMm: number, degradeFactor: number, now: number) {
    const thresholds = APP_CONFIG.THRESHOLDS.RAIL_DEVIATION_MM;

    // Critical deviation check
    if (deviationMm >= thresholds.CRITICAL) {
      if (!this.lastAlertState.deviationCritical) {
        this.lastAlertState.deviationCritical = true;
        this.dispatchAlert({
          id: `alert-dev-crit-${now}`,
          ts: now,
          severity: 'critical',
          component: 'guide_rails',
          message: `Critical rail alignment deviation: ${deviationMm.toFixed(2)} mm exceeds ${thresholds.CRITICAL} mm threshold!`,
          acknowledged: false,
        });
      }
    } else {
      this.lastAlertState.deviationCritical = false;
    }

    // Warning deviation check
    if (deviationMm >= thresholds.WARNING && deviationMm < thresholds.CRITICAL) {
      if (!this.lastAlertState.deviationWarning) {
        this.lastAlertState.deviationWarning = true;
        this.dispatchAlert({
          id: `alert-dev-warn-${now}`,
          ts: now,
          severity: 'warning',
          component: 'guide_rails',
          message: `Elevated rail deviation: ${deviationMm.toFixed(2)} mm approaching critical tolerance limit.`,
          acknowledged: false,
        });
      }
    } else if (deviationMm < thresholds.WARNING) {
      this.lastAlertState.deviationWarning = false;
    }

    // Degrading scenario alerts for 45Hz energy and health
    if (this.scenario === 'degrading' && degradeFactor > 0.6 && !this.lastAlertState.rmsWarning) {
      this.lastAlertState.rmsWarning = true;
      this.dispatchAlert({
        id: `alert-degrade-rms-${now}`,
        ts: now,
        severity: 'warning',
        component: 'guide_shoes',
        message: 'High 45 Hz spectral resonance detected; guide shoe roller lining deterioration in progress.',
        acknowledged: false,
      });
    }
  }

  private dispatchAlert(alert: Alert) {
    if (this.callbacks.onAlert) {
      this.callbacks.onAlert(alert);
    }
  }

  // --------------------------------------------------------------------------
  // Elevator Kinematic Motion Engine
  // --------------------------------------------------------------------------
  private updateElevatorKinematics(dtSec: number) {
    const physics = APP_CONFIG.ELEVATOR_PHYSICS;
    const targetPos = (this.targetFloor - 1) * physics.FLOOR_HEIGHT_M;
    const distanceToTarget = targetPos - this.elevatorPosition;
    const direction = distanceToTarget > 0 ? 1 : -1;
    const absDistance = Math.abs(distanceToTarget);

    if (this.tripState === 'stopped') {
      this.elevatorSpeed = 0;
      this.floorDwellRemainingSec -= dtSec;

      if (this.floorDwellRemainingSec <= 0) {
        // Pick new random floor distinct from current
        let nextFloor = Math.floor(Math.random() * physics.TOTAL_FLOORS) + 1;
        while (nextFloor === this.currentFloor) {
          nextFloor = Math.floor(Math.random() * physics.TOTAL_FLOORS) + 1;
        }
        this.targetFloor = nextFloor;
        this.tripState = 'accelerating';
      }
    } else {
      // Stopping distance required at current speed: s = v^2 / (2 * decel)
      const stoppingDistance = (this.elevatorSpeed * this.elevatorSpeed) / (2 * physics.DECEL_MS2);

      if (absDistance <= 0.05) {
        // Arrived at floor
        this.elevatorPosition = targetPos;
        this.elevatorSpeed = 0;
        this.currentFloor = this.targetFloor;
        this.tripState = 'stopped';
        this.floorDwellRemainingSec = physics.FLOOR_DWELL_SECONDS;
      } else if (absDistance <= stoppingDistance) {
        // Decelerating phase
        this.tripState = 'decelerating';
        this.elevatorSpeed = Math.max(0.1, this.elevatorSpeed - physics.DECEL_MS2 * dtSec);
        this.elevatorPosition += direction * this.elevatorSpeed * dtSec;
      } else if (this.elevatorSpeed < physics.MAX_SPEED_MS && this.tripState === 'accelerating') {
        // Accelerating phase
        this.elevatorSpeed = Math.min(physics.MAX_SPEED_MS, this.elevatorSpeed + physics.ACCEL_MS2 * dtSec);
        this.elevatorPosition += direction * this.elevatorSpeed * dtSec;
        if (this.elevatorSpeed >= physics.MAX_SPEED_MS) {
          this.tripState = 'cruising';
        }
      } else {
        // Cruising phase
        this.tripState = 'cruising';
        this.elevatorPosition += direction * this.elevatorSpeed * dtSec;
      }

      this.currentFloor = Math.max(
        1,
        Math.min(physics.TOTAL_FLOORS, Math.round(this.elevatorPosition / physics.FLOOR_HEIGHT_M) + 1)
      );
    }
  }

  private calculateInstantaneousAccel(): number {
    if (this.tripState === 'accelerating') return APP_CONFIG.ELEVATOR_PHYSICS.ACCEL_MS2;
    if (this.tripState === 'decelerating') return -APP_CONFIG.ELEVATOR_PHYSICS.DECEL_MS2;
    return 0.0;
  }
}
