import React from 'react';
import { useWidgetState } from '../hooks/useWidgetState';
import type { WidgetState } from '../types';
import {
  Clock,
  HelpCircle,
  Info,
  Loader2,
} from 'lucide-react';

export interface ChartCardProps {
  title: string;
  caption: string; // One-line plain-language explanation of what it shows
  units?: string;
  toolbar?: React.ReactNode;
  children: React.ReactNode;
  lastUpdated?: number | null;
  state?: WidgetState;
  isLoading?: boolean;
  hasData?: boolean;
  className?: string;
  minHeight?: string;
}

export const ChartCard: React.FC<ChartCardProps> = ({
  title,
  caption,
  units,
  toolbar,
  children,
  lastUpdated,
  state: explicitState,
  isLoading,
  hasData = true,
  className = '',
  minHeight = 'min-h-[280px]',
}) => {
  const { state: resolvedState, ageSeconds } = useWidgetState({
    state: explicitState,
    lastUpdated,
    isLoading,
    hasData,
  });

  return (
    <div
      className={`relative bg-industrial-900 rounded-lg border border-industrial-800 p-4 transition-all duration-200 flex flex-col justify-between ${
        resolvedState === 'stale'
          ? 'opacity-65 ring-1 ring-amber-500/30 bg-industrial-950/85'
          : 'hover:border-industrial-700/80'
      } ${className}`}
    >
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-industrial-800">
        <div className="space-y-0.5">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-mono font-bold tracking-wider uppercase text-slate-100 flex items-center gap-2">
              <span>{title}</span>
              {units && (
                <span className="text-xs px-1.5 py-0.5 rounded bg-industrial-950 border border-industrial-800 text-cyan-400 font-mono">
                  {units}
                </span>
              )}
            </h3>

            {/* State Badges */}
            {resolvedState === 'stale' && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-950/90 text-amber-300 border border-amber-600/70 shadow-sm animate-pulse">
                <Clock className="w-3 h-3" />
                <span>STALE ({ageSeconds ?? '>5'}s)</span>
              </span>
            )}

            {resolvedState === 'loading' && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-950/80 text-cyan-300 border border-cyan-800">
                <Loader2 className="w-3 h-3 animate-spin" />
                <span>BUFFERING</span>
              </span>
            )}

            {resolvedState === 'no-data' && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-900 text-slate-400 border border-slate-700">
                <HelpCircle className="w-3 h-3" />
                <span>NO DATA</span>
              </span>
            )}
          </div>

          {/* Plain-Language Caption Requirement */}
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <Info className="w-3 h-3 text-cyan-500 shrink-0" />
            <p className="line-clamp-1 italic">{caption}</p>
          </div>
        </div>

        {/* Toolbar Slot */}
        {toolbar && (
          <div className="flex items-center gap-2 shrink-0">
            {toolbar}
          </div>
        )}
      </div>

      {/* Chart Canvas / Body Container */}
      <div className={`relative flex-1 w-full my-3 ${minHeight} flex flex-col justify-center`}>
        {resolvedState === 'loading' && (
          <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-industrial-950/70 backdrop-blur-xs rounded space-y-2 font-mono text-xs text-cyan-300">
            <Loader2 className="w-6 h-6 animate-spin text-cyan-400" />
            <span>Streaming high-frequency waveform samples...</span>
          </div>
        )}

        {resolvedState === 'no-data' && (
          <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-industrial-950/80 rounded space-y-2 font-mono text-xs text-slate-500 border border-dashed border-industrial-800">
            <HelpCircle className="w-6 h-6 text-slate-600" />
            <span>No telemetry series data received from elevator sensor gateway.</span>
          </div>
        )}

        {/* Chart Content */}
        <div className={`w-full h-full ${resolvedState === 'loading' || resolvedState === 'no-data' ? 'filter blur-[1px]' : ''}`}>
          {children}
        </div>
      </div>

      {/* Footer Info */}
      <div className="pt-2 border-t border-industrial-800/80 flex items-center justify-between text-[11px] font-mono text-slate-500">
        <span>
          {resolvedState === 'stale'
            ? 'STREAM PAUSED / STALE'
            : resolvedState === 'loading'
            ? 'AWAITING BATCHES'
            : resolvedState === 'no-data'
            ? 'OFFLINE SENSOR'
            : 'LIVE TIME-SERIES'}
        </span>
        {ageSeconds !== null && (
          <span className={resolvedState === 'stale' ? 'text-amber-400 font-semibold' : ''}>
            Last batch: {ageSeconds}s ago
          </span>
        )}
      </div>
    </div>
  );
};
