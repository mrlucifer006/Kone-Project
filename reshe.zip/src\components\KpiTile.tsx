import React from 'react';
import { useWidgetState } from '../hooks/useWidgetState';
import type { SystemStatus, WidgetState } from '../types';
import { StatusChip } from './StatusChip';
import {
  TrendingUp,
  TrendingDown,
  Minus,
  Loader2,
  Clock,
  HelpCircle,
} from 'lucide-react';

export interface KpiTileProps {
  title: string;
  value?: string | number | null;
  unit?: string;
  status?: SystemStatus;
  trend?: {
    direction: 'up' | 'down' | 'flat';
    value?: string;
    isGood?: boolean; // whether "up" is desirable or harmful
  };
  subtitle?: string;
  lastUpdated?: number | null;
  state?: WidgetState; // explicit state override
  isLoading?: boolean;
  className?: string;
  icon?: React.ReactNode;
}

export const KpiTile: React.FC<KpiTileProps> = ({
  title,
  value,
  unit,
  status = 'healthy',
  trend,
  subtitle,
  lastUpdated,
  state: explicitState,
  isLoading,
  className = '',
  icon,
}) => {
  const { state: resolvedState, ageSeconds } = useWidgetState({
    state: explicitState,
    lastUpdated,
    isLoading,
    hasData: value !== null && value !== undefined && value !== '',
  });

  const getBorderColor = () => {
    if (resolvedState === 'stale') return 'border-amber-600/40 ring-1 ring-amber-500/20';
    if (resolvedState === 'loading' || resolvedState === 'no-data') return 'border-industrial-800';

    switch (status) {
      case 'healthy':
        return 'border-emerald-500/40 hover:border-emerald-500/70 shadow-[0_0_12px_rgba(16,185,129,0.06)]';
      case 'warning':
        return 'border-amber-500/50 hover:border-amber-500/80 shadow-[0_0_12px_rgba(245,158,11,0.08)]';
      case 'critical':
        return 'border-red-500/50 hover:border-red-500/80 shadow-[0_0_12px_rgba(239,68,68,0.12)]';
      case 'nodata':
      default:
        return 'border-industrial-800';
    }
  };

  const getStatusTextColor = () => {
    if (resolvedState === 'stale' || resolvedState === 'no-data' || resolvedState === 'loading') {
      return 'text-slate-300';
    }
    switch (status) {
      case 'healthy':
        return 'text-emerald-400';
      case 'warning':
        return 'text-amber-400';
      case 'critical':
        return 'text-red-400';
      case 'nodata':
      default:
        return 'text-slate-300';
    }
  };

  const renderTrend = () => {
    if (!trend) return null;
    const isNeutral = trend.direction === 'flat';
    const isPositiveDirection = trend.direction === 'up';

    let colorClass = 'text-slate-400';
    if (!isNeutral) {
      if (trend.isGood !== undefined) {
        colorClass = (isPositiveDirection && trend.isGood) || (!isPositiveDirection && !trend.isGood)
          ? 'text-emerald-400'
          : 'text-red-400';
      } else {
        colorClass = isPositiveDirection ? 'text-amber-400' : 'text-emerald-400';
      }
    }

    return (
      <div className={`flex items-center gap-1 text-xs font-mono font-medium ${colorClass}`}>
        {trend.direction === 'up' && <TrendingUp className="w-3.5 h-3.5" />}
        {trend.direction === 'down' && <TrendingDown className="w-3.5 h-3.5" />}
        {trend.direction === 'flat' && <Minus className="w-3.5 h-3.5" />}
        {trend.value && <span>{trend.value}</span>}
      </div>
    );
  };

  return (
    <div
      className={`relative bg-industrial-900 rounded-lg p-4 border transition-all duration-200 flex flex-col justify-between ${getBorderColor()} ${
        resolvedState === 'stale' ? 'opacity-60 bg-industrial-950/90' : ''
      } ${className}`}
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-2 mb-2">
        <div className="space-y-0.5">
          <div className="flex items-center gap-2">
            {icon && <span className="text-slate-400">{icon}</span>}
            <span className="text-xs font-mono font-bold tracking-wider uppercase text-slate-400">
              {title}
            </span>
          </div>
          {subtitle && (
            <p className="text-[11px] text-slate-500 font-sans tracking-tight">
              {subtitle}
            </p>
          )}
        </div>

        {/* State Badges */}
        <div>
          {resolvedState === 'stale' && (
            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-950/80 text-amber-300 border border-amber-600/60 shadow-sm animate-pulse">
              <Clock className="w-3 h-3" />
              <span>STALE ({ageSeconds ?? '>5'}s)</span>
            </span>
          )}
          {resolvedState === 'loading' && (
            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-950/60 text-cyan-300 border border-cyan-800">
              <Loader2 className="w-3 h-3 animate-spin" />
              <span>SYNCING</span>
            </span>
          )}
          {resolvedState === 'no-data' && (
            <StatusChip status="nodata" size="sm" state="no-data" />
          )}
          {resolvedState === 'normal' && (
            <StatusChip status={status} size="sm" />
          )}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="my-2 min-h-[44px] flex items-baseline justify-between gap-3">
        {resolvedState === 'loading' ? (
          <div className="flex items-center gap-2 text-slate-500 font-mono text-sm py-1">
            <Loader2 className="w-4 h-4 animate-spin text-cyan-400" />
            <span>Awaiting telemetry stream...</span>
          </div>
        ) : resolvedState === 'no-data' ? (
          <div className="flex items-center gap-1.5 text-slate-500 font-mono text-sm py-1">
            <HelpCircle className="w-4 h-4 text-slate-600" />
            <span>--- (No measurement available)</span>
          </div>
        ) : (
          <div className="flex items-baseline gap-2">
            <span className={`text-2xl lg:text-3xl font-mono font-bold tracking-tight ${getStatusTextColor()}`}>
              {value}
            </span>
            {unit && (
              <span className="text-xs font-mono font-medium text-slate-400">
                {unit}
              </span>
            )}
          </div>
        )}

        {/* Trend (if normal or stale) */}
        {resolvedState !== 'loading' && resolvedState !== 'no-data' && renderTrend()}
      </div>

      {/* Footer / Telemetry Age info */}
      <div className="pt-2 border-t border-industrial-800/80 flex items-center justify-between text-[11px] font-mono text-slate-500">
        <span>
          {resolvedState === 'stale'
            ? 'STREAM PAUSED / DISCONNECTED'
            : resolvedState === 'loading'
            ? 'INITIALIZING'
            : resolvedState === 'no-data'
            ? 'SENSOR DISCONNECTED'
            : 'LIVE STREAM ACTIVE'}
        </span>
        {ageSeconds !== null && (
          <span className={resolvedState === 'stale' ? 'text-amber-400 font-bold' : ''}>
            {ageSeconds}s ago
          </span>
        )}
      </div>
    </div>
  );
};
