import React, { useEffect, useRef } from 'react';
import uPlot from 'uplot';
import { APP_CONFIG } from '../../config';
import { useWidgetState } from '../../hooks/useWidgetState';
import { useElevatorStore } from '../../store/useElevatorStore';
import {
  ArrowDown,
  ArrowUp,
  Gauge,
  PauseCircle,
  Activity,
} from 'lucide-react';

export const MotionPanel: React.FC = () => {
  const latestMotion = useElevatorStore((state) => state.latestMotion);
  const motionHistory = useElevatorStore((state) => state.motionHistory);
  const latestVibrationRms = useElevatorStore((state) => state.latestVibrationRms);
  const lastUpdate = useElevatorStore((state) => state.lastUpdate);

  const chartContainerRef = useRef<HTMLDivElement>(null);
  const uplotRef = useRef<uPlot | null>(null);

  const { state: widgetState } = useWidgetState({
    lastUpdated: lastUpdate.motion,
    hasData: latestMotion !== null,
  });

  const accel = latestMotion?.accelMs2 ?? 0.0;
  const speed = latestMotion?.speedMs ?? 0.0;
  const floor = latestMotion?.floor ?? 1;
  const position = latestMotion?.position_m ?? 0.0;
  const tripState = latestMotion?.tripState ?? 'stopped';

  // Plain language ride smoothness
  const zRms = latestVibrationRms.z;
  const rideQuality =
    zRms < APP_CONFIG.THRESHOLDS.RIDE_COMFORT.COMFORTABLE_MAX_G
      ? { label: 'SMOOTH RIDE', color: 'bg-emerald-950 text-emerald-400 border-emerald-800' }
      : zRms < APP_CONFIG.THRESHOLDS.RIDE_COMFORT.ACCEPTABLE_MAX_G
      ? { label: 'NORMAL RIDE', color: 'bg-amber-950 text-amber-400 border-amber-800' }
      : { label: 'ROUGH / SHAKY', color: 'bg-red-950 text-red-400 border-red-800 animate-pulse' };

  // Setup uPlot time-series chart for car acceleration (30s history)
  useEffect(() => {
    if (!chartContainerRef.current) return;

    const nowSec = Date.now() / 1000;
    let times: number[] = [];
    let accels: number[] = [];

    if (motionHistory.length > 0) {
      times = motionHistory.map((m) => m.ts / 1000);
      accels = motionHistory.map((m) => m.accelMs2);
    } else {
      times = [nowSec - 1, nowSec];
      accels = [0, 0];
    }

    const data: uPlot.AlignedData = [times, accels];

    const opts: uPlot.Options = {
      width: chartContainerRef.current.clientWidth || 340,
      height: 135,
      cursor: { show: true },
      scales: {
        x: { time: true },
        y: { auto: false, range: [-1.2, 1.2] },
      },
      axes: [
        {
          stroke: '#64748b',
          grid: { stroke: 'rgba(51, 65, 85, 0.3)', width: 1 },
          ticks: { stroke: '#475569', width: 1 },
          values: (_, ticks) => ticks.map((t) => new Date(t * 1000).toLocaleTimeString().slice(3, 8)),
          font: '10px JetBrains Mono, monospace',
        },
        {
          stroke: '#38bdf8',
          grid: { stroke: 'rgba(51, 65, 85, 0.3)', width: 1 },
          ticks: { stroke: '#475569', width: 1 },
          values: (_, vals) => vals.map((v) => `${v >= 0 ? '+' : ''}${v.toFixed(1)}`),
          font: '10px JetBrains Mono, monospace',
        },
      ],
      series: [
        { label: 'Time' },
        {
          label: 'Car Acceleration',
          stroke: '#38bdf8',
          width: 2,
          fill: 'rgba(56, 189, 248, 0.12)',
          points: { show: false },
        },
      ],
    };

    if (!uplotRef.current) {
      uplotRef.current = new uPlot(opts, data, chartContainerRef.current);
    } else {
      uplotRef.current.setData(data);
      uplotRef.current.setSize({
        width: chartContainerRef.current.clientWidth || 340,
        height: 135,
      });
    }

    const handleResize = () => {
      if (chartContainerRef.current && uplotRef.current) {
        uplotRef.current.setSize({
          width: chartContainerRef.current.clientWidth || 340,
          height: 135,
        });
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [motionHistory]);

  const getTripLabel = () => {
    switch (tripState) {
      case 'accelerating':
        return { text: 'MOVING UP / STARTING', icon: <ArrowUp className="w-3.5 h-3.5 text-cyan-400 animate-bounce" /> };
      case 'cruising':
        return { text: 'CRUISING AT SPEED', icon: <ArrowUp className="w-3.5 h-3.5 text-emerald-400" /> };
      case 'decelerating':
        return { text: 'APPROACHING FLOOR', icon: <ArrowDown className="w-3.5 h-3.5 text-amber-400" /> };
      case 'stopped':
      default:
        return { text: 'STOPPED AT FLOOR', icon: <PauseCircle className="w-3.5 h-3.5 text-slate-400" /> };
    }
  };

  const { text: tripText, icon: tripIcon } = getTripLabel();

  return (
    <div
      className={`bg-industrial-900 rounded-lg border border-industrial-800 p-4 flex flex-col justify-between font-sans ${
        widgetState === 'stale' ? 'opacity-70 ring-1 ring-amber-500/40 bg-industrial-950/90' : ''
      }`}
    >
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-industrial-800">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-cyan-400" />
          <h3 className="text-sm font-bold uppercase tracking-wide text-slate-100 font-mono">
            Car Vital Signs &amp; Movement
          </h3>
        </div>

        {/* Ride Quality Chip */}
        <span className={`px-2 py-0.5 rounded text-[11px] font-mono font-bold border ${rideQuality.color}`}>
          {rideQuality.label}
        </span>
      </div>

      {/* Primary Movement & Floor Status */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 my-2.5">
        {/* Floor Card */}
        <div className="bg-industrial-950/80 rounded-md p-3 border border-industrial-800/80 font-mono text-xs">
          <span className="text-[10px] text-slate-400 uppercase font-bold block">
            Current Floor
          </span>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-2xl font-extrabold text-slate-100">
              Floor {floor}
            </span>
            <span className="text-xs text-slate-400">/ 20</span>
          </div>
          <div className="w-full bg-industrial-900 rounded-full h-1.5 overflow-hidden mt-1.5">
            <div
              className="h-full bg-cyan-500 transition-all duration-300"
              style={{
                width: `${Math.min(100, (position / APP_CONFIG.ELEVATOR_PHYSICS.TOTAL_HEIGHT_M) * 100)}%`,
              }}
            />
          </div>
        </div>

        {/* Movement State Card */}
        <div className="bg-industrial-950/80 rounded-md p-3 border border-industrial-800/80 font-mono text-xs">
          <span className="text-[10px] text-slate-400 uppercase font-bold block">
            Movement State
          </span>
          <div className="flex items-center gap-1.5 mt-1 font-bold text-slate-100 text-xs">
            {tripIcon}
            <span>{tripText}</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Height: {position.toFixed(1)} meters
          </div>
        </div>

        {/* Speed Card */}
        <div className="bg-industrial-950/80 rounded-md p-3 border border-industrial-800/80 font-mono text-xs">
          <span className="text-[10px] text-slate-400 uppercase font-bold block">
            Car Speed
          </span>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-2xl font-extrabold text-slate-100">
              {speed.toFixed(2)}
            </span>
            <span className="text-xs text-slate-400 font-bold">m/s</span>
          </div>
          <div className="text-[10px] text-slate-400">
            Comfort Limit: 2.5 m/s
          </div>
        </div>
      </div>

      {/* Simple Acceleration Waveform */}
      <div className="bg-industrial-950/80 rounded-md p-2 border border-industrial-800/80 space-y-1">
        <div className="flex justify-between items-center px-1 font-mono text-[11px] text-slate-400">
          <span>Start / Stop Acceleration Profile (Last 30s)</span>
          <span className="text-cyan-400">Current: {accel >= 0 ? `+${accel.toFixed(2)}` : accel.toFixed(2)} m/s²</span>
        </div>
        <div ref={chartContainerRef} className="w-full flex justify-center py-1 overflow-hidden" />
      </div>

      {/* Footer */}
      <div className="pt-2 border-t border-industrial-800/80 flex items-center justify-between text-xs font-mono text-slate-400">
        <span>Movement: {tripState === 'stopped' ? 'Stationary at Landing' : 'In Transit'}</span>
        <span>Vertical Accel: {Math.abs(accel) > 0.8 ? 'Hard Transition' : 'Gentle / Smooth'}</span>
      </div>
    </div>
  );
};
