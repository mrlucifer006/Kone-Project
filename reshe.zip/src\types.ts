// ============================================================================
// DATA CONTRACT (Strict Elevator Guide Rail Monitoring Specification)
// ============================================================================

export interface VibrationBatch {
  ts: number;
  sampleRateHz: number;
  x: number[];
  y: number[];
  z: number[];
}

export type TripState = 'stopped' | 'accelerating' | 'cruising' | 'decelerating';

export interface MotionState {
  ts: number;
  accelMs2: number;
  speedMs: number;
  floor: number;
  position_m: number;
  tripState: TripState;
}

export interface VisionResult {
  ts: number;
  frameId: number;
  deviationMm: number;
  angleDeg: number;
  confidence: number;
}

export type ComponentId = 'guide_shoes' | 'guide_rails' | 'rail_joints' | 'car_frame';
export type RiskLevel = 'low' | 'medium' | 'high';

export interface HealthFactor {
  name: string;
  contribution: number; // percentage or normalized contribution (0 - 100)
}

export interface ComponentHealth {
  id: ComponentId;
  score: number; // 0-100 (100 = optimal, 0 = failed)
  risk: RiskLevel;
  ttlDays: number; // predicted Time-To-Limit / Remaining Useful Life in days
  ttlLowDays: number;
  ttlHighDays: number;
  topFactors: HealthFactor[];
}

export type AlertSeverity = 'info' | 'warning' | 'critical';

export interface Alert {
  id: string;
  ts: number;
  severity: AlertSeverity;
  component: string;
  message: string;
  acknowledged: boolean;
}

export interface MaintenanceEntry {
  id: string;
  ts: number;
  component: string;
  action: string;
  technician: string;
  notes: string;
}

// ----------------------------------------------------------------------------
// System & Simulation Types
// ----------------------------------------------------------------------------

export type SimulationScenario = 'healthy' | 'degrading' | 'fault_spike';
export type ConnectionStatus = 'connected' | 'reconnecting' | 'offline';
export type SystemStatus = 'healthy' | 'warning' | 'critical' | 'nodata';
export type WidgetState = 'normal' | 'stale' | 'loading' | 'no-data';

export type SocketMessageType =
  | 'vibration'
  | 'motion'
  | 'vision'
  | 'health'
  | 'alert'
  | 'maintenance'
  | 'scenario_change';

export interface SocketMessageMap {
  vibration: VibrationBatch;
  motion: MotionState;
  vision: VisionResult;
  health: ComponentHealth[];
  alert: Alert;
  maintenance: MaintenanceEntry;
  scenario_change: { scenario: SimulationScenario };
}

export type SocketMessage<T extends SocketMessageType = SocketMessageType> = {
  type: T;
  payload: SocketMessageMap[T];
};
