import React, { useEffect, useMemo, useRef } from 'react';
import uPlot from 'uplot';
import { computeFftSpectrum } from '../../lib/dsp';
import { useElevatorStore } from '../../store/useElevatorStore';
import { ChartCard } from '../ChartCard';
import { HelpPopover } from '../HelpPopover';

export interface FftSpectrumChartProps {
  selectedAxis: 'x' | 'y' | 'z' | 'all';
  compareBaseline: boolean;
}

export const FftSpectrumChart: React.FC<FftSpectrumChartProps> = ({
  selectedAxis,
  compareBaseline,
}) => {
  const vibrationBatches = useElevatorStore((state) => state.vibrationBatches);
  const lastUpdate = useElevatorStore((state) => state.lastUpdate);

  const containerRef = useRef<HTMLDivElement>(null);
  const uplotRef = useRef<uPlot | null>(null);

  // Extract raw samples from recent batches (last 1024 points for FFT window)
  const targetSamples = useMemo(() => {
    const raw: number[] = [];
    for (const b of vibrationBatches) {
      if (selectedAxis === 'x') raw.push(...b.x);
      else if (selectedAxis === 'y') raw.push(...b.y);
      else raw.push(...b.z); // default to z
    }
    return raw.slice(-1024);
  }, [vibrationBatches, selectedAxis]);

  // Compute client-side FFT with Hann window
  const fftData = useMemo(() => {
    return computeFftSpectrum(targetSamples, 1000, 100);
  }, [targetSamples]);

  // 1. Initialize uPlot ONCE on mount
  useEffect(() => {
    if (!containerRef.current) return;

    const seriesList: uPlot.Series[] = [
      { label: 'Frequency (Hz)' },
      {
        label: 'Live Spectrum',
        stroke: '#06b6d4', // Cyan
        width: 2,
        fill: 'rgba(6, 182, 212, 0.12)',
        points: { show: false },
      },
      {
        label: 'Baseline Ref',
        stroke: 'rgba(148, 163, 184, 0.45)',
        dash: [4, 4],
        width: 1.5,
        points: { show: false },
        show: compareBaseline,
      },
    ];

    const initialData: uPlot.AlignedData = [
      fftData.frequencies.length ? fftData.frequencies : [0, 100],
      fftData.magnitudes.length ? fftData.magnitudes : [0, 0],
      fftData.baselineMagnitudes.length ? fftData.baselineMagnitudes : [0, 0],
    ];

    const opts: uPlot.Options = {
      width: containerRef.current.clientWidth || 600,
      height: 230,
      cursor: { show: true },
      scales: {
        x: {
          time: false,
          auto: false,
          range: [0, 100],
        },
        y: {
          auto: true,
          range: [0, 0.12],
        },
      },
      axes: [
        {
          stroke: '#64748b',
          grid: { stroke: 'rgba(51, 65, 85, 0.3)', width: 1 },
          ticks: { stroke: '#475569', width: 1 },
          values: (_, vals) => vals.map((v) => `${v.toFixed(0)} Hz`),
          font: '10px JetBrains Mono, monospace',
        },
        {
          stroke: '#06b6d4',
          grid: { stroke: 'rgba(51, 65, 85, 0.3)', width: 1 },
          ticks: { stroke: '#475569', width: 1 },
          values: (_, vals) => vals.map((v) => `${v.toFixed(3)}g`),
          font: '10px JetBrains Mono, monospace',
        },
      ],
      series: seriesList,
    };

    const plot = new uPlot(opts, initialData, containerRef.current);
    uplotRef.current = plot;

    const handleResize = () => {
      if (containerRef.current && uplotRef.current) {
        uplotRef.current.setSize({
          width: containerRef.current.clientWidth || 600,
          height: 230,
        });
      }
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      plot.destroy();
      uplotRef.current = null;
    };
  }, []);

  // 2. Toggle baseline series visibility cleanly without destroying uPlot
  useEffect(() => {
    if (uplotRef.current && uplotRef.current.series[2]) {
      uplotRef.current.setSeries(2, { show: compareBaseline });
    }
  }, [compareBaseline]);

  // 3. FLICKER-FREE Data Feed: In-place setData (NEVER destroys uPlot)
  useEffect(() => {
    const plot = uplotRef.current;
    if (!plot || fftData.frequencies.length === 0) return;

    plot.setData(
      [fftData.frequencies, fftData.magnitudes, fftData.baselineMagnitudes],
      false
    );
  }, [fftData]);

  const dynamicCaption =
    fftData.energyAt45HzRatio > 2.0
      ? `45 Hz Roller Vibration is ${fftData.energyAt45HzRatio}x normal (Elevated guide shoe roller wear detected).`
      : `Guide shoe vibration (45 Hz) is ${fftData.energyAt45HzRatio}x baseline; frequencies are within normal healthy range.`;

  return (
    <ChartCard
      title="2. Vibration Frequency (Where is Shaking Coming From?)"
      units="[g amplitude]"
      caption={dynamicCaption}
      lastUpdated={lastUpdate.vibration}
      hasData={fftData.frequencies.length > 0}
      toolbar={
        <div className="flex items-center gap-2">
          {/* Top 3 Auto-Labeled Peaks */}
          <div className="hidden sm:flex items-center gap-1.5 font-mono text-[11px]">
            {fftData.topPeaks.map((peak, idx) => {
              const isRoller = Math.abs(peak.freq - 45) < 3;
              const isSway = Math.abs(peak.freq - 12) < 3;
              const label = isRoller ? 'Rollers' : isSway ? 'Car Sway' : `Freq`;
              return (
                <span
                  key={idx}
                  className={`px-1.5 py-0.5 rounded border ${
                    isRoller && fftData.energyAt45HzRatio > 2.0
                      ? 'bg-amber-950 text-amber-300 border-amber-700 font-bold'
                      : 'bg-industrial-950 text-slate-300 border-industrial-800'
                  }`}
                >
                  {label}: {peak.freq.toFixed(1)}Hz ({peak.mag.toFixed(3)}g)
                </span>
              );
            })}
          </div>

          <HelpPopover
            title="Vibration Frequency Breakdown"
            whatIsIt="Breaks down overall elevator shaking into individual frequencies. Different parts vibrate at specific speeds: ~12 Hz is car body sway; ~45 Hz is guide roller friction."
            nominalBaseline="A healthy shaft shows low vibration across all frequencies with small normal bumps at 12 Hz and 45 Hz."
            anomalyIndications="If the 45 Hz peak grows higher than baseline, the guide shoe rollers or liners are wearing out and need inspection."
          />
        </div>
      }
    >
      <div className="w-full h-full flex flex-col justify-between">
        <div ref={containerRef} className="w-full flex justify-center overflow-hidden py-1" />

        {/* Dynamic Peak Readout and Baseline Legend */}
        <div className="flex flex-wrap items-center justify-between text-[11px] font-mono text-slate-400 pt-1 border-t border-industrial-800/60 mt-1 px-1">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1 text-cyan-400 font-bold">
              <span className="w-2.5 h-1 bg-cyan-400" /> Current Shaking
            </span>
            {compareBaseline && (
              <span className="flex items-center gap-1 text-slate-400">
                <span className="w-2.5 h-0.5 border-t border-dashed border-slate-400" /> Normal Baseline
              </span>
            )}
          </div>

          <div className="text-slate-400">
            Guide Rollers:{' '}
            <strong className={fftData.energyAt45HzRatio > 2.0 ? 'text-amber-400' : 'text-slate-200'}>
              45 Hz = {fftData.energyAt45HzRatio}x Normal
            </strong>
          </div>
        </div>
      </div>
    </ChartCard>
  );
};
