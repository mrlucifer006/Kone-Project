import React, { useEffect, useRef, useState } from 'react';
import { APP_CONFIG } from '../../config';
import { useWidgetState } from '../../hooks/useWidgetState';
import { useElevatorStore } from '../../store/useElevatorStore';
import {
  Camera,
  Download,
  Maximize2,
  Minimize2,
  Pause,
  Play,
  RefreshCw,
  VideoOff,
  Settings2,
} from 'lucide-react';

export const CameraPanel: React.FC = () => {
  const latestVision = useElevatorStore((state) => state.latestVision);
  const lastUpdate = useElevatorStore((state) => state.lastUpdate);

  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const backgroundCanvasRef = useRef<HTMLCanvasElement>(null);

  const [isPaused, setIsPaused] = useState(false);
  const [feedLost, setFeedLost] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [c3CamUrl, setC3CamUrl] = useState<string>(APP_CONFIG.HARDWARE.CAMERA_FEED_URL);
  const [showUrlConfig, setShowUrlConfig] = useState(false);

  const { state: widgetState, ageSeconds } = useWidgetState({
    lastUpdated: lastUpdate.vision,
    hasData: !feedLost && latestVision !== null,
  });

  const deviation = latestVision?.deviationMm ?? 0.35;
  const angle = latestVision?.angleDeg ?? 0.02;

  // Simple status
  const isCritical = deviation >= APP_CONFIG.THRESHOLDS.RAIL_DEVIATION_MM.CRITICAL;
  const isWarning = deviation >= APP_CONFIG.THRESHOLDS.RAIL_DEVIATION_MM.WARNING;

  const strokeColor = isCritical ? '#ef4444' : isWarning ? '#f59e0b' : '#10b981';

  // 1. Draw animated guide rail pattern when no physical C3 Cam IP is connected
  useEffect(() => {
    if (c3CamUrl) return; // If physical stream URL is given, use the <img> tag directly
    const bgCanvas = backgroundCanvasRef.current;
    if (!bgCanvas || feedLost) return;
    const ctx = bgCanvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let offset = 0;

    const renderBackground = () => {
      const w = bgCanvas.width;
      const h = bgCanvas.height;

      // Dark elevator shaft
      ctx.fillStyle = '#0a0d14';
      ctx.fillRect(0, 0, w, h);

      // Steel guide rail column running down center
      const railWidth = 64;
      const centerX = w / 2;

      const railGrad = ctx.createLinearGradient(centerX - railWidth / 2, 0, centerX + railWidth / 2, 0);
      railGrad.addColorStop(0, '#1e293b');
      railGrad.addColorStop(0.3, '#475569');
      railGrad.addColorStop(0.5, '#64748b');
      railGrad.addColorStop(0.7, '#475569');
      railGrad.addColorStop(1, '#1e293b');

      ctx.fillStyle = railGrad;
      ctx.fillRect(centerX - railWidth / 2, 0, railWidth, h);

      // Steel rail texture marks moving with car motion
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
      ctx.lineWidth = 1;
      offset = (offset + 1.0) % 36;

      for (let y = -36 + offset; y < h; y += 36) {
        ctx.beginPath();
        ctx.moveTo(centerX - railWidth / 2, y);
        ctx.lineTo(centerX + railWidth / 2, y);
        ctx.stroke();
      }

      // Red alignment laser stripe across the rail
      const laserY = h * 0.52;
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.7)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(centerX - railWidth / 2 - 20, laserY);
      ctx.lineTo(centerX + railWidth / 2 + 20, laserY);
      ctx.stroke();

      if (!isPaused) {
        animId = requestAnimationFrame(renderBackground);
      }
    };

    renderBackground();

    return () => cancelAnimationFrame(animId);
  }, [c3CamUrl, feedLost, isPaused]);

  // 2. Draw simplified transparent overlay: Center datum line + Detected rail line + shift arrow
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || feedLost || isPaused) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    const centerX = w / 2;

    // Center Reference Line (Dashed cyan)
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.5)';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([6, 6]);
    ctx.beginPath();
    ctx.moveTo(centerX, 20);
    ctx.lineTo(centerX, h - 20);
    ctx.stroke();
    ctx.setLineDash([]);

    // Detected Rail Line
    const pxScale = 36;
    const devPx = deviation * pxScale;
    const tiltRad = (angle * Math.PI) / 180;

    const topX = centerX + devPx - Math.tan(tiltRad) * (h / 2);
    const bottomX = centerX + devPx + Math.tan(tiltRad) * (h / 2);

    ctx.strokeStyle = strokeColor;
    ctx.lineWidth = 2.5;
    ctx.shadowColor = strokeColor;
    ctx.shadowBlur = isCritical ? 10 : 4;

    ctx.beginPath();
    ctx.moveTo(topX, 20);
    ctx.lineTo(bottomX, h - 20);
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Shift arrow
    const midY = h / 2;
    const targetX = centerX + devPx;
    ctx.strokeStyle = strokeColor;
    ctx.fillStyle = strokeColor;
    ctx.lineWidth = 2;

    ctx.beginPath();
    ctx.moveTo(centerX, midY);
    ctx.lineTo(targetX, midY);
    ctx.stroke();

    const dir = devPx >= 0 ? 1 : -1;
    ctx.beginPath();
    ctx.moveTo(targetX, midY);
    ctx.lineTo(targetX - dir * 8, midY - 4);
    ctx.lineTo(targetX - dir * 8, midY + 4);
    ctx.closePath();
    ctx.fill();
  }, [deviation, angle, strokeColor, feedLost, isPaused]);

  const handleSnapshot = () => {
    const bg = backgroundCanvasRef.current;
    const overlay = canvasRef.current;
    if (!bg || !overlay) return;

    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = bg.width;
    tempCanvas.height = bg.height;
    const tCtx = tempCanvas.getContext('2d');
    if (!tCtx) return;

    tCtx.drawImage(bg, 0, 0);
    tCtx.drawImage(overlay, 0, 0);

    const link = document.createElement('a');
    link.download = `c3-camera-rail-snapshot-${Date.now()}.png`;
    link.href = tempCanvas.toDataURL('image/png');
    link.click();
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen?.();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.();
      setIsFullscreen(false);
    }
  };

  return (
    <div
      ref={containerRef}
      className={`bg-industrial-900 rounded-lg border border-industrial-800 p-4 flex flex-col justify-between font-sans ${
        widgetState === 'stale' ? 'opacity-70 ring-1 ring-amber-500/40 bg-industrial-950/90' : ''
      }`}
    >
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-industrial-800">
        <div className="flex items-center gap-2">
          <Camera className="w-4 h-4 text-cyan-400" />
          <div>
            <h3 className="text-sm font-bold uppercase tracking-wide text-slate-100 flex items-center gap-2 font-mono">
              <span>C3 Camera: Rail Alignment</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-industrial-950 border border-industrial-800 text-cyan-400">
                ESP32-C3
              </span>
            </h3>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 font-mono text-xs">
          {/* C3 Camera IP Settings */}
          <button
            onClick={() => setShowUrlConfig(!showUrlConfig)}
            title="Configure ESP32-C3 IP Stream URL"
            className="p-1.5 rounded bg-industrial-800 text-slate-300 hover:text-white border border-industrial-700 transition-colors"
          >
            <Settings2 className="w-3.5 h-3.5 text-slate-400" />
          </button>

          {/* Pause */}
          <button
            onClick={() => setIsPaused((p) => !p)}
            title={isPaused ? 'Resume Camera' : 'Pause Camera'}
            className={`p-1.5 rounded border transition-colors ${
              isPaused
                ? 'bg-amber-950 text-amber-300 border-amber-600'
                : 'bg-industrial-800 text-slate-300 border-industrial-700 hover:bg-industrial-750'
            }`}
          >
            {isPaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
          </button>

          {/* Snapshot */}
          <button
            onClick={handleSnapshot}
            title="Save Photo"
            className="p-1.5 rounded bg-industrial-800 text-slate-300 border border-industrial-700 hover:text-white transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
          </button>

          {/* Fullscreen */}
          <button
            onClick={toggleFullscreen}
            title="Fullscreen"
            className="p-1.5 rounded bg-industrial-800 text-slate-300 border border-industrial-700 hover:text-white transition-colors"
          >
            {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>

          {/* Feed loss test */}
          <button
            onClick={() => setFeedLost((f) => !f)}
            title="Simulate signal loss"
            className={`px-2 py-0.5 rounded text-[10px] font-bold border transition-colors ${
              feedLost
                ? 'bg-red-950 text-red-300 border-red-700'
                : 'bg-industrial-800 text-slate-400 border-industrial-700 hover:text-slate-300'
            }`}
          >
            {feedLost ? 'Feed Lost' : 'Test Loss'}
          </button>
        </div>
      </div>

      {/* Optional C3 Stream URL Input Bar */}
      {showUrlConfig && (
        <div className="my-2 p-2.5 rounded bg-industrial-950 border border-industrial-800 flex items-center gap-2 font-mono text-xs">
          <span className="text-slate-400 text-[11px] shrink-0">C3 Stream URL:</span>
          <input
            type="text"
            placeholder="e.g. http://192.168.4.1/stream (leave blank for optical test pattern)"
            value={c3CamUrl}
            onChange={(e) => setC3CamUrl(e.target.value)}
            className="flex-1 bg-industrial-900 border border-industrial-700 rounded px-2 py-1 text-slate-200 text-xs"
          />
          <button
            onClick={() => setShowUrlConfig(false)}
            className="px-2 py-1 rounded bg-cyan-600 text-slate-950 font-bold text-xs"
          >
            Apply
          </button>
        </div>
      )}

      {/* Main Camera Viewport */}
      <div className="relative w-full aspect-video sm:h-64 my-2.5 bg-industrial-950 rounded-lg overflow-hidden border border-industrial-800 flex items-center justify-center">
        {feedLost ? (
          <div className="flex flex-col items-center justify-center p-6 text-center space-y-2 font-mono">
            <VideoOff className="w-8 h-8 text-red-400 animate-pulse" />
            <div className="text-sm font-bold text-red-400 uppercase">
              Camera Signal Disconnected
            </div>
            <p className="text-xs text-slate-400">
              Check C3 Cam Wi-Fi connection or power cable.
            </p>
            <button
              onClick={() => setFeedLost(false)}
              className="mt-2 flex items-center gap-1.5 px-3 py-1 rounded bg-red-900/60 text-red-200 border border-red-700 hover:bg-red-800 text-xs font-bold"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Retry Connection</span>
            </button>
          </div>
        ) : (
          <>
            {/* If user provided a real C3 stream URL, show <img> tag directly */}
            {c3CamUrl ? (
              <img
                src={c3CamUrl}
                alt="Live C3 Cam Feed"
                className="absolute inset-0 w-full h-full object-cover"
                onError={() => setFeedLost(true)}
              />
            ) : (
              /* Simulated Optical Track Canvas */
              <canvas
                ref={backgroundCanvasRef}
                width={640}
                height={360}
                className="absolute inset-0 w-full h-full object-cover"
              />
            )}

            {/* Transparent Alignment Overlay */}
            <canvas
              ref={canvasRef}
              width={640}
              height={360}
              className="absolute inset-0 w-full h-full object-cover pointer-events-none"
            />

            {/* Plain-Language Deviation Badge */}
            <div className="absolute top-3 left-3 z-20 pointer-events-none font-mono">
              <div
                className={`px-3 py-1.5 rounded bg-industrial-950/90 backdrop-blur-xs border text-xs font-bold flex items-center gap-2 shadow-lg ${
                  isCritical
                    ? 'border-red-600 text-red-300 ring-2 ring-red-500/50 animate-pulse'
                    : isWarning
                    ? 'border-amber-600 text-amber-300'
                    : 'border-industrial-700 text-slate-100'
                }`}
              >
                <span>Rail Shift: <strong>{deviation.toFixed(2)} mm</strong></span>
                <span className="text-slate-500">|</span>
                <span>
                  {isCritical
                    ? 'CRITICAL MISALIGNMENT'
                    : isWarning
                    ? 'CHECK RAIL ALIGNMENT'
                    : 'ALIGNMENT OK'}
                </span>
              </div>
            </div>

            {/* Bottom-right Camera Note */}
            <div className="absolute bottom-2 right-2 text-[10px] font-mono text-slate-400 bg-industrial-950/80 px-2 py-0.5 rounded border border-industrial-800 pointer-events-none">
              Source: {c3CamUrl ? 'ESP32-C3 Live' : 'C3 Cam (Optical Simulator)'}
            </div>

            {/* Stale State Overlay */}
            {widgetState === 'stale' && (
              <div className="absolute inset-0 bg-industrial-950/70 backdrop-blur-xs flex items-center justify-center z-30 font-mono">
                <span className="px-3 py-1.5 rounded text-xs font-bold bg-amber-950 text-amber-300 border border-amber-600 shadow-lg animate-pulse">
                  CAMERA STREAM PAUSED ({ageSeconds ?? '>5'}s)
                </span>
              </div>
            )}
          </>
        )}
      </div>

      {/* Plain Language Footer */}
      <div className="pt-2 border-t border-industrial-800/80 flex items-center justify-between text-xs font-mono text-slate-400">
        <span>Standard Guide Limit: 1.50 mm</span>
        <span className={isCritical ? 'text-red-400 font-bold' : isWarning ? 'text-amber-400' : 'text-emerald-400'}>
          {isCritical ? 'Attention Required: Re-align Rail' : isWarning ? 'Slight Rail Wear' : 'Operating Normally'}
        </span>
      </div>
    </div>
  );
};
