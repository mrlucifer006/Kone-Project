import React, { useEffect, useRef, useState } from 'react';
import { APP_CONFIG } from '../../config';
import { useElevatorStore } from '../../store/useElevatorStore';
import {
  Camera,
  Download,
  Maximize2,
  Minimize2,
  Pause,
  Play,
  RefreshCw,
  VideoOff,
  Wifi,
} from 'lucide-react';

export const LiveCameraFeed: React.FC = () => {
  const latestVision = useElevatorStore((state) => state.latestVision);
  const isStreamPaused = useElevatorStore((state) => state.isStreamPaused);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number | null>(null);

  const [feedLost, setFeedLost] = useState(false);
  const [isLocalPaused, setIsLocalPaused] = useState(false);
  const [c3CamUrl, setC3CamUrl] = useState<string>(APP_CONFIG.HARDWARE.CAMERA_FEED_URL);
  const [showUrlInput, setShowUrlInput] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const deviation = latestVision?.deviationMm ?? 0.35;
  const angle = latestVision?.angleDeg ?? 0.02;

  const isCritical = deviation >= APP_CONFIG.THRESHOLDS.RAIL_DEVIATION_MM.CRITICAL;
  const isWarning = deviation >= APP_CONFIG.THRESHOLDS.RAIL_DEVIATION_MM.WARNING;
  const statusColor = isCritical ? '#ef4444' : isWarning ? '#f59e0b' : '#10b981';

  // Single unified render loop on ONE canvas to eliminate any multi-layer flicker
  useEffect(() => {
    if (c3CamUrl) return; // Physical MJPEG feed uses <img> directly

    const canvas = canvasRef.current;
    if (!canvas || feedLost) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let offset = 0;

    const render = () => {
      const w = canvas.width;
      const h = canvas.height;
      const centerX = w / 2;

      // 1. Dark elevator shaft background
      ctx.fillStyle = '#0a0d14';
      ctx.fillRect(0, 0, w, h);

      // 2. Guide rail column running down the center
      const railWidth = 72;
      const railGrad = ctx.createLinearGradient(centerX - railWidth / 2, 0, centerX + railWidth / 2, 0);
      railGrad.addColorStop(0, '#111827');
      railGrad.addColorStop(0.2, '#374151');
      railGrad.addColorStop(0.5, '#6b7280');
      railGrad.addColorStop(0.8, '#374151');
      railGrad.addColorStop(1, '#111827');

      ctx.fillStyle = railGrad;
      ctx.fillRect(centerX - railWidth / 2, 0, railWidth, h);

      // 3. Moving track texture marks to show car motion
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.07)';
      ctx.lineWidth = 1;
      if (!isLocalPaused && !isStreamPaused) {
        offset = (offset + 1.2) % 40;
      }

      for (let y = -40 + offset; y < h; y += 40) {
        ctx.beginPath();
        ctx.moveTo(centerX - railWidth / 2, y);
        ctx.lineTo(centerX + railWidth / 2, y);
        ctx.stroke();
      }

      // 4. Center reference datum line (Dashed cyan)
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.45)';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([6, 6]);
      ctx.beginPath();
      ctx.moveTo(centerX, 15);
      ctx.lineTo(centerX, h - 15);
      ctx.stroke();
      ctx.setLineDash([]);

      // 5. Detected rail edge line & tilt angle
      const pxScale = 34;
      const devPx = deviation * pxScale;
      const tiltRad = (angle * Math.PI) / 180;

      const topX = centerX + devPx - Math.tan(tiltRad) * (h / 2);
      const bottomX = centerX + devPx + Math.tan(tiltRad) * (h / 2);

      ctx.strokeStyle = statusColor;
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(topX, 15);
      ctx.lineTo(bottomX, h - 15);
      ctx.stroke();

      // 6. Horizontal shift indicator arrow
      const midY = h / 2;
      const targetX = centerX + devPx;

      ctx.strokeStyle = statusColor;
      ctx.fillStyle = statusColor;
      ctx.lineWidth = 2;

      ctx.beginPath();
      ctx.moveTo(centerX, midY);
      ctx.lineTo(targetX, midY);
      ctx.stroke();

      const dir = devPx >= 0 ? 1 : -1;
      ctx.beginPath();
      ctx.moveTo(targetX, midY);
      ctx.lineTo(targetX - dir * 8, midY - 4);
      ctx.lineTo(targetX - dir * 8, midY + 4);
      ctx.closePath();
      ctx.fill();

      // 7. Red horizontal laser scan line across the rail
      const laserY = h * 0.54;
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.65)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(centerX - railWidth / 2 - 25, laserY);
      ctx.lineTo(centerX + railWidth / 2 + 25, laserY);
      ctx.stroke();

      animRef.current = requestAnimationFrame(render);
    };

    animRef.current = requestAnimationFrame(render);

    return () => {
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [c3CamUrl, feedLost, isLocalPaused, isStreamPaused, deviation, angle, statusColor]);

  const handleSnapshot = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = `c3-cam-capture-${Date.now()}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  return (
    <div
      ref={containerRef}
      className="bg-industrial-900 border border-industrial-800 rounded-lg p-4 flex flex-col justify-between font-sans shadow-md"
    >
      {/* Header & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-industrial-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 mb-0.5">
            <Camera className="w-3.5 h-3.5" />
            <span>ESP32-C3 CAM MODULE (OPTICAL RAIL TRACKER)</span>
          </div>
          <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <span>Guide Rail Camera View</span>
          </h3>
          <p className="text-xs text-slate-400">
            Laser triangulation tracking the vertical guide rail line.
          </p>
        </div>

        {/* Toolbar */}
        <div className="flex items-center gap-2 font-mono text-xs">
          {/* C3 Stream IP Toggle */}
          <button
            onClick={() => setShowUrlInput(!showUrlInput)}
            title="Configure ESP32-C3 IP Camera URL"
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-industrial-950 hover:bg-industrial-800 text-slate-300 border border-industrial-800 text-[11px]"
          >
            <Wifi className="w-3 h-3 text-cyan-400" />
            <span>{c3CamUrl ? 'C3 IP Active' : 'Set C3 Stream URL'}</span>
          </button>

          {/* Pause */}
          <button
            onClick={() => setIsLocalPaused(!isLocalPaused)}
            title={isLocalPaused ? 'Resume Camera' : 'Pause Camera'}
            className="p-1.5 rounded bg-industrial-800 text-slate-300 border border-industrial-700 hover:text-white"
          >
            {isLocalPaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
          </button>

          {/* Snapshot */}
          <button
            onClick={handleSnapshot}
            title="Save Picture"
            className="p-1.5 rounded bg-industrial-800 text-slate-300 border border-industrial-700 hover:text-white"
          >
            <Download className="w-3.5 h-3.5" />
          </button>

          {/* Fullscreen */}
          <button
            onClick={toggleFullscreen}
            title="Toggle Fullscreen"
            className="p-1.5 rounded bg-industrial-800 text-slate-300 border border-industrial-700 hover:text-white"
          >
            {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Optional C3 Stream URL Input */}
      {showUrlInput && (
        <div className="my-2 p-2.5 rounded bg-industrial-950 border border-industrial-800 flex items-center gap-2 font-mono text-xs">
          <span className="text-slate-400 text-[11px] shrink-0">C3 Stream URL:</span>
          <input
            type="text"
            placeholder="e.g. http://192.168.4.1/stream (leave empty for optical track pattern)"
            value={c3CamUrl}
            onChange={(e) => setC3CamUrl(e.target.value)}
            className="flex-1 bg-industrial-900 border border-industrial-700 rounded px-2 py-1 text-slate-200 text-xs"
          />
          <button
            onClick={() => setShowUrlInput(false)}
            className="px-2.5 py-1 rounded bg-cyan-600 text-slate-950 font-bold text-xs"
          >
            Apply
          </button>
        </div>
      )}

      {/* Viewport */}
      <div className="relative w-full aspect-video sm:h-64 my-2.5 bg-industrial-950 rounded-lg overflow-hidden border border-industrial-800 flex items-center justify-center">
        {feedLost ? (
          <div className="flex flex-col items-center justify-center p-6 text-center space-y-2 font-mono">
            <VideoOff className="w-8 h-8 text-red-400 animate-pulse" />
            <div className="text-sm font-bold text-red-400 uppercase">
              Camera Signal Lost
            </div>
            <button
              onClick={() => setFeedLost(false)}
              className="mt-2 flex items-center gap-1.5 px-3 py-1 rounded bg-red-900/60 text-red-200 border border-red-700 hover:bg-red-800 text-xs font-bold"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Retry Signal</span>
            </button>
          </div>
        ) : c3CamUrl ? (
          <img
            src={c3CamUrl}
            alt="ESP32-C3 Camera Stream"
            className="w-full h-full object-cover"
            onError={() => setFeedLost(true)}
          />
        ) : (
          <canvas
            ref={canvasRef}
            width={640}
            height={360}
            className="w-full h-full object-cover"
          />
        )}

        {/* Real-time Status Overlay Badge */}
        {!feedLost && (
          <div className="absolute top-3 left-3 z-10 pointer-events-none font-mono">
            <div
              className={`px-3 py-1.5 rounded bg-industrial-950/90 backdrop-blur-xs border text-xs font-bold flex items-center gap-2 shadow-lg ${
                isCritical
                  ? 'border-red-600 text-red-300 ring-2 ring-red-500/50 animate-pulse'
                  : isWarning
                  ? 'border-amber-600 text-amber-300'
                  : 'border-industrial-700 text-slate-100'
              }`}
            >
              <span>Rail Shift: <strong>{deviation.toFixed(2)} mm</strong></span>
              <span className="text-slate-500">|</span>
              <span>
                {isCritical
                  ? 'CRITICAL MISALIGNMENT'
                  : isWarning
                  ? 'CHECK RAIL ALIGNMENT'
                  : 'ALIGNMENT OK'}
              </span>
            </div>
          </div>
        )}

        {/* Tilt Angle Readout */}
        {!feedLost && (
          <div className="absolute bottom-3 right-3 z-10 pointer-events-none font-mono text-[11px] px-2 py-1 rounded bg-industrial-950/80 border border-industrial-800 text-slate-300">
            Tilt: {angle >= 0 ? '+' : ''}{angle.toFixed(1)}°
          </div>
        )}
      </div>

      {/* Footer info */}
      <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-2 border-t border-industrial-800/80 px-1">
        <span>Center Line (Dashed) = Track Target Datum</span>
        <span className={statusColor === '#ef4444' ? 'text-red-400 font-bold' : statusColor === '#f59e0b' ? 'text-amber-400' : 'text-emerald-400'}>
          {isCritical ? 'Deviation Exceeds 2.2 mm' : isWarning ? 'Approaching 1.5 mm Limit' : 'Within ±1.0 mm Nominal Limit'}
        </span>
      </div>
    </div>
  );
};
