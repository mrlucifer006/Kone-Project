import React from 'react';
import { LiveCameraFeed } from '../components/panels/LiveCameraFeed';
import { LiveElevatorPosition } from '../components/panels/LiveElevatorPosition';
import { LiveVibrationChart } from '../components/vibration/LiveVibrationChart';

export const StreamlinedDashboard: React.FC = () => {
  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto font-sans space-y-5">
      {/* 2-Column Responsive Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Left Column: C3 Camera Tracker & Hoistway Position */}
        <div className="space-y-5 flex flex-col justify-between">
          <LiveCameraFeed />
          <LiveElevatorPosition />
        </div>

        {/* Right Column: Live Vibration Sensor Graph */}
        <div className="flex flex-col justify-between">
          <LiveVibrationChart timeWindowSec={20} />
        </div>
      </div>
    </div>
  );
};
