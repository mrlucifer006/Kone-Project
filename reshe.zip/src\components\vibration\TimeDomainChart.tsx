import React, { useEffect, useRef, useState } from 'react';
import uPlot from 'uplot';
import { APP_CONFIG } from '../../config';
import { downsampleMinMax } from '../../lib/dsp';
import { useElevatorStore } from '../../store/useElevatorStore';
import { ChartCard } from '../ChartCard';
import { HelpPopover } from '../HelpPopover';
import { Maximize2, RotateCcw } from 'lucide-react';

export interface TimeDomainChartProps {
  selectedAxis: 'x' | 'y' | 'z' | 'all';
  compareBaseline: boolean;
  timeWindowSec: number; // e.g. 30, 300 (5m), 3600 (1h), 86400 (24h)
  highlightTimeRange?: [number, number] | null;
  onTimeRangeChange?: (range: [number, number]) => void;
}

export const TimeDomainChart: React.FC<TimeDomainChartProps> = ({
  selectedAxis,
  compareBaseline,
  timeWindowSec,
  highlightTimeRange,
  onTimeRangeChange,
}) => {
  const vibrationBatches = useElevatorStore((state) => state.vibrationBatches);
  const alerts = useElevatorStore((state) => state.alerts);
  const latestMotion = useElevatorStore((state) => state.latestMotion);
  const lastUpdate = useElevatorStore((state) => state.lastUpdate);

  const containerRef = useRef<HTMLDivElement>(null);
  const uplotRef = useRef<uPlot | null>(null);

  const [currentZoomRange, setCurrentZoomRange] = useState<[number, number] | null>(null);

  // Extract flat time arrays and 3-axis values from recent batches
  const rawTimestamps: number[] = [];
  const rawX: number[] = [];
  const rawY: number[] = [];
  const rawZ: number[] = [];

  for (const batch of vibrationBatches) {
    const dt = 1 / batch.sampleRateHz;
    const batchStartSec = batch.ts / 1000;
    const len = batch.x.length;
    for (let i = 0; i < len; i++) {
      rawTimestamps.push(batchStartSec + i * dt);
      rawX.push(batch.x[i]);
      rawY.push(batch.y[i]);
      rawZ.push(batch.z[i]);
    }
  }

  // Calculate peak and current RMS for dynamic caption
  const latestBatch = vibrationBatches[vibrationBatches.length - 1];
  const maxZ = rawZ.length ? Math.max(...rawZ.slice(-500)) : 0.05;
  const currentTripState = latestMotion?.tripState ?? 'cruising';

  // Build uPlot series configuration with strict axis colors
  useEffect(() => {
    if (!containerRef.current || rawTimestamps.length === 0) return;

    // Apply downsampling if total points exceed 4,000 to maintain smooth 60 FPS
    const targetPoints = 3600;
    let downTimes = rawTimestamps;
    let downX = rawX;
    let downY = rawY;
    let downZ = rawZ;

    if (rawTimestamps.length > targetPoints) {
      const dsZ = downsampleMinMax(rawTimestamps, rawZ, targetPoints);
      downTimes = dsZ.times;
      downZ = dsZ.values;
      downX = downsampleMinMax(rawTimestamps, rawX, targetPoints).values;
      downY = downsampleMinMax(rawTimestamps, rawY, targetPoints).values;
    }

    // uPlot data matrix: [timestamps, series1, series2, ...]
    const seriesList: uPlot.Series[] = [{ label: 'Time' }];
    const dataList: uPlot.AlignedData = [downTimes];

    if (selectedAxis === 'x' || selectedAxis === 'all') {
      seriesList.push({
        label: 'X (Lateral)',
        stroke: APP_CONFIG.COLORS.AXIS.X, // Blue
        width: 1.5,
        points: { show: false },
      });
      dataList.push(downX);
    }

    if (selectedAxis === 'y' || selectedAxis === 'all') {
      seriesList.push({
        label: 'Y (Fore-Aft)',
        stroke: APP_CONFIG.COLORS.AXIS.Y, // Orange
        width: 1.5,
        points: { show: false },
      });
      dataList.push(downY);
    }

    if (selectedAxis === 'z' || selectedAxis === 'all') {
      seriesList.push({
        label: 'Z (Vertical)',
        stroke: APP_CONFIG.COLORS.AXIS.Z, // Green
        width: 2,
        points: { show: false },
      });
      dataList.push(downZ);
    }

    // Baseline overlay if toggle is on
    if (compareBaseline) {
      const baselineZ = downTimes.map((t) => 0.05 + 0.015 * Math.sin(t * 12 * Math.PI));
      seriesList.push({
        label: 'Baseline Ref (Z)',
        stroke: 'rgba(148, 163, 184, 0.45)', // Faint slate
        dash: [4, 4],
        width: 1.5,
        points: { show: false },
      });
      dataList.push(baselineZ);
    }

    // Custom hook for background trip-state shading & threshold lines & shock markers
    const customDrawPlugin: uPlot.Plugin = {
      hooks: {
        draw: [
          (u) => {
            const ctx = u.ctx;
            const { left, top, width, height } = u.bbox;

            // 1. Shaded trip-state background bands
            ctx.save();
            if (currentTripState === 'accelerating') {
              ctx.fillStyle = 'rgba(6, 182, 212, 0.04)'; // Subtle cyan
              ctx.fillRect(left, top, width, height);
            } else if (currentTripState === 'cruising') {
              ctx.fillStyle = 'rgba(16, 185, 129, 0.03)'; // Subtle emerald
              ctx.fillRect(left, top, width, height);
            } else if (currentTripState === 'decelerating') {
              ctx.fillStyle = 'rgba(245, 158, 11, 0.04)'; // Subtle amber
              ctx.fillRect(left, top, width, height);
            }

            // 2. Threshold Horizontal Lines (Warning: ±0.15g, Critical: ±0.25g)
            const warnPos = u.valToPos(APP_CONFIG.THRESHOLDS.VIBRATION_RMS_G.WARNING, 'y', true);
            const warnNeg = u.valToPos(-APP_CONFIG.THRESHOLDS.VIBRATION_RMS_G.WARNING, 'y', true);
            const critPos = u.valToPos(APP_CONFIG.THRESHOLDS.VIBRATION_RMS_G.CRITICAL, 'y', true);
            const critNeg = u.valToPos(-APP_CONFIG.THRESHOLDS.VIBRATION_RMS_G.CRITICAL, 'y', true);

            // Warning threshold line
            ctx.strokeStyle = 'rgba(245, 158, 11, 0.5)';
            ctx.setLineDash([4, 4]);
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(left, warnPos);
            ctx.lineTo(left + width, warnPos);
            ctx.moveTo(left, warnNeg);
            ctx.lineTo(left + width, warnNeg);
            ctx.stroke();

            // Critical threshold line
            ctx.strokeStyle = 'rgba(239, 68, 68, 0.6)';
            ctx.setLineDash([6, 3]);
            ctx.lineWidth = 1.2;
            ctx.beginPath();
            ctx.moveTo(left, critPos);
            ctx.lineTo(left + width, critPos);
            ctx.moveTo(left, critNeg);
            ctx.lineTo(left + width, critNeg);
            ctx.stroke();

            // 3. Vertical markers for shock events (alerts with shock in message)
            const shockAlerts = alerts.filter(
              (a) => a.severity === 'critical' && a.component === 'rail_joints'
            );

            ctx.strokeStyle = '#ef4444';
            ctx.setLineDash([2, 2]);
            ctx.lineWidth = 1.5;

            for (const shock of shockAlerts) {
              const shockX = u.valToPos(shock.ts / 1000, 'x', true);
              if (shockX >= left && shockX <= left + width) {
                ctx.beginPath();
                ctx.moveTo(shockX, top);
                ctx.lineTo(shockX, top + height);
                ctx.stroke();

                // Shock flag marker at top
                ctx.fillStyle = '#ef4444';
                ctx.fillRect(shockX - 12, top + 4, 24, 14);
                ctx.font = '9px JetBrains Mono, monospace';
                ctx.fillStyle = '#ffffff';
                ctx.fillText('SHOCK', shockX - 10, top + 14);
              }
            }

            ctx.restore();
          },
        ],
      },
    };

    const opts: uPlot.Options = {
      width: containerRef.current.clientWidth || 600,
      height: 250,
      plugins: [customDrawPlugin],
      cursor: {
        drag: { x: true, y: true, setScale: true },
        sync: { key: 'vibrationSync' },
      },
      scales: {
        x: {
          time: true,
          min: highlightTimeRange ? highlightTimeRange[0] : undefined,
          max: highlightTimeRange ? highlightTimeRange[1] : undefined,
        },
        y: {
          auto: false,
          range: [-0.4, 0.4],
        },
      },
      axes: [
        {
          stroke: '#64748b',
          grid: { stroke: 'rgba(51, 65, 85, 0.4)', width: 1 },
          ticks: { stroke: '#475569', width: 1 },
          values: (_, ticks) => ticks.map((t) => new Date(t * 1000).toLocaleTimeString().slice(3, 8)),
          font: '10px JetBrains Mono, monospace',
        },
        {
          stroke: '#94a3b8',
          grid: { stroke: 'rgba(51, 65, 85, 0.4)', width: 1 },
          ticks: { stroke: '#475569', width: 1 },
          values: (_, vals) => vals.map((v) => `${v >= 0 ? '+' : ''}${v.toFixed(2)}g`),
          font: '10px JetBrains Mono, monospace',
        },
      ],
      series: seriesList,
    };

    if (!uplotRef.current) {
      uplotRef.current = new uPlot(opts, dataList, containerRef.current);
    } else {
      // Clean recreation on series shape change or data update
      uplotRef.current.destroy();
      uplotRef.current = new uPlot(opts, dataList, containerRef.current);
    }

    const handleResize = () => {
      if (containerRef.current && uplotRef.current) {
        uplotRef.current.setSize({
          width: containerRef.current.clientWidth || 600,
          height: 250,
        });
      }
    };

    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [
    rawTimestamps.length,
    selectedAxis,
    compareBaseline,
    currentTripState,
    highlightTimeRange,
  ]);

  const handleResetZoom = () => {
    if (uplotRef.current) {
      uplotRef.current.setData(uplotRef.current.data, true);
    }
  };

  return (
    <ChartCard
      title="1. Car Vibration Over Time (Tri-Axial Sensor)"
      units="[g force]"
      caption={`Live 3-axis motion vibrations (Car is currently ${currentTripState}); peak vertical bump at ${maxZ.toFixed(3)} g.`}
      lastUpdated={lastUpdate.vibration}
      hasData={rawTimestamps.length > 0}
      toolbar={
        <div className="flex items-center gap-2">
          {/* Reset Zoom Button */}
          <button
            onClick={handleResetZoom}
            title="Reset Zoom / Pan Range"
            className="flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-mono text-slate-300 hover:text-white bg-industrial-800 hover:bg-industrial-750 border border-industrial-700 transition-colors"
          >
            <RotateCcw className="w-3 h-3 text-cyan-400" />
            <span>Reset Zoom</span>
          </button>

          {/* Help Popover */}
          <HelpPopover
            title="Car Vibration Over Time"
            whatIsIt="Live vibration stream from the sensor on the elevator car. Measures side-to-side (X), front-to-back (Y), and up-and-down (Z) motion."
            nominalBaseline="Normal elevator travel stays smooth under ±0.08 g, with gentle curves during starting and stopping."
            anomalyIndications="Sudden spikes over ±0.25 g mean the car hit an uneven rail joint gap. Continuous rapid ripples mean roller guides are worn."
          />
        </div>
      }
    >
      <div className="w-full h-full flex flex-col justify-between">
        {/* uPlot Chart Canvas */}
        <div ref={containerRef} className="w-full flex justify-center overflow-hidden py-1" />

        {/* Legend & Threshold Legend */}
        <div className="flex flex-wrap items-center justify-between text-[11px] font-mono text-slate-400 pt-1 border-t border-industrial-800/60 mt-1 px-1">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1 text-axis-x">
              <span className="w-2.5 h-1 bg-axis-x" /> X (Side-to-Side)
            </span>
            <span className="flex items-center gap-1 text-axis-y">
              <span className="w-2.5 h-1 bg-axis-y" /> Y (Front-to-Back)
            </span>
            <span className="flex items-center gap-1 text-axis-z font-bold">
              <span className="w-2.5 h-1 bg-axis-z" /> Z (Up-and-Down)
            </span>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-amber-400 flex items-center gap-1">
              <span className="w-2 h-0.5 border-t border-dashed border-amber-400" /> Warning ±0.15g
            </span>
            <span className="text-red-400 flex items-center gap-1">
              <span className="w-2 h-0.5 border-t border-dashed border-red-400" /> Rough Spike ±0.25g
            </span>
          </div>
        </div>
      </div>
    </ChartCard>
  );
};
