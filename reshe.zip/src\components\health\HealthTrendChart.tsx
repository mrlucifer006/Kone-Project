import React, { useEffect, useMemo, useRef, useState } from 'react';
import uPlot from 'uplot';
import { APP_CONFIG } from '../../config';
import { useElevatorStore } from '../../store/useElevatorStore';
import type { ComponentId } from '../../types';
import { ChartCard } from '../ChartCard';
import { HelpPopover } from '../HelpPopover';

export interface HealthTrendChartProps {
  selectedComponentId: ComponentId;
  onSelectComponent: (id: ComponentId) => void;
}

export const HealthTrendChart: React.FC<HealthTrendChartProps> = ({
  selectedComponentId,
  onSelectComponent,
}) => {
  const healthMap = useElevatorStore((state) => state.healthMap);
  const containerRef = useRef<HTMLDivElement>(null);
  const uplotRef = useRef<uPlot | null>(null);

  const currentComp = healthMap[selectedComponentId];
  const currentScore = currentComp?.score ?? 96;

  // Synthesize 60-day degradation trajectory based on current health score and TTL
  const trendData = useMemo(() => {
    const days = 60;
    const now = Date.now();
    const oneDaySec = 86400;
    const times: number[] = [];
    const scores: number[] = [];
    const thresholdLine: number[] = [];

    // Historical 30 days + Projected 30 days
    const ttl = currentComp?.ttlDays ?? 210;
    const decayRatePerDay = (100 - currentScore) / 30;

    for (let d = -30; d <= 30; d++) {
      const t = Math.round(now / 1000 + d * oneDaySec);
      times.push(t);
      thresholdLine.push(APP_CONFIG.THRESHOLDS.HEALTH_SCORE.CRITICAL_MAX);

      if (d <= 0) {
        // Historical degradation leading up to today
        const histScore = Math.min(
          100,
          Math.max(10, currentScore - d * decayRatePerDay + (Math.sin(d * 0.5) * 1.5))
        );
        scores.push(Number(histScore.toFixed(1)));
      } else {
        // Future projection decaying towards failure
        const projScore = Math.max(
          5,
          currentScore - (d / ttl) * currentScore + (Math.sin(d * 0.4) * 1.0)
        );
        scores.push(Number(projScore.toFixed(1)));
      }
    }

    return { times, scores, thresholdLine };
  }, [currentScore, currentComp?.ttlDays]);

  useEffect(() => {
    if (!containerRef.current || trendData.times.length === 0) return;

    // Custom draw hook for today line and shaded failure region
    const customDrawPlugin: uPlot.Plugin = {
      hooks: {
        draw: [
          (u) => {
            const ctx = u.ctx;
            const { left, top, width, height } = u.bbox;

            ctx.save();
            // Shaded critical failure zone (score < 45)
            const failY = u.valToPos(APP_CONFIG.THRESHOLDS.HEALTH_SCORE.CRITICAL_MAX, 'y', true);
            ctx.fillStyle = 'rgba(239, 68, 68, 0.08)';
            ctx.fillRect(left, failY, width, top + height - failY);

            // "TODAY" vertical marker
            const todayX = u.valToPos(Date.now() / 1000, 'x', true);
            if (todayX >= left && todayX <= left + width) {
              ctx.strokeStyle = '#38bdf8';
              ctx.setLineDash([4, 4]);
              ctx.lineWidth = 1.5;
              ctx.beginPath();
              ctx.moveTo(todayX, top);
              ctx.lineTo(todayX, top + height);
              ctx.stroke();

              ctx.fillStyle = '#38bdf8';
              ctx.fillRect(todayX - 18, top + 4, 36, 14);
              ctx.font = '9px JetBrains Mono, monospace';
              ctx.fillStyle = '#0a0d14';
              ctx.fillText('TODAY', todayX - 14, top + 14);
            }
            ctx.restore();
          },
        ],
      },
    };

    const seriesList: uPlot.Series[] = [
      { label: 'Date' },
      {
        label: `${selectedComponentId.replace('_', ' ').toUpperCase()} Score`,
        stroke: currentScore >= 75 ? '#10b981' : currentScore >= 45 ? '#f59e0b' : '#ef4444',
        width: 2.5,
        points: { show: false },
      },
      {
        label: 'Failure Threshold',
        stroke: '#ef4444',
        dash: [6, 4],
        width: 1.5,
        points: { show: false },
      },
    ];

    const dataList: uPlot.AlignedData = [
      trendData.times,
      trendData.scores,
      trendData.thresholdLine,
    ];

    const opts: uPlot.Options = {
      width: containerRef.current.clientWidth || 600,
      height: 220,
      plugins: [customDrawPlugin],
      cursor: {
        drag: { x: true, y: false, setScale: true },
      },
      scales: {
        x: { time: true },
        y: { auto: false, range: [0, 105] },
      },
      axes: [
        {
          stroke: '#64748b',
          grid: { stroke: 'rgba(51, 65, 85, 0.3)', width: 1 },
          ticks: { stroke: '#475569', width: 1 },
          values: (_, ticks) =>
            ticks.map((t) => {
              const d = new Date(t * 1000);
              return `${d.getMonth() + 1}/${d.getDate()}`;
            }),
          font: '10px JetBrains Mono, monospace',
        },
        {
          stroke: '#94a3b8',
          grid: { stroke: 'rgba(51, 65, 85, 0.3)', width: 1 },
          ticks: { stroke: '#475569', width: 1 },
          values: (_, vals) => vals.map((v) => `${v.toFixed(0)}`),
          font: '10px JetBrains Mono, monospace',
        },
      ],
      series: seriesList,
    };

    if (!uplotRef.current) {
      uplotRef.current = new uPlot(opts, dataList, containerRef.current);
    } else {
      uplotRef.current.setData(dataList, false);
    }

    const handleResize = () => {
      if (containerRef.current && uplotRef.current) {
        uplotRef.current.setSize({
          width: containerRef.current.clientWidth || 600,
          height: 220,
        });
      }
    };

    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [trendData, selectedComponentId, currentScore]);

  return (
    <ChartCard
      title="1. Part Health & Wear History (60 Days)"
      units="[Health Score 0-100]"
      caption={`Tracks historical wear and projects future decline towards the failure line (${APP_CONFIG.THRESHOLDS.HEALTH_SCORE.CRITICAL_MAX} points).`}
      lastUpdated={Date.now()}
      toolbar={
        <div className="flex items-center gap-2">
          {/* Subsystem Switcher */}
          <div className="flex items-center gap-1 bg-industrial-950 p-0.5 rounded border border-industrial-800 font-mono text-[11px]">
            {[
              { id: 'guide_shoes', label: 'Shoes' },
              { id: 'guide_rails', label: 'Rails' },
              { id: 'rail_joints', label: 'Joints' },
              { id: 'car_frame', label: 'Frame' },
            ].map(({ id, label }) => (
              <button
                key={id}
                onClick={() => onSelectComponent(id as ComponentId)}
                className={`px-2 py-0.5 rounded transition-all uppercase ${
                  selectedComponentId === id
                    ? 'bg-industrial-800 text-cyan-300 font-bold border border-industrial-700'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <HelpPopover
            title="Part Health History"
            whatIsIt="Shows how component health has changed over the past 30 days and projects when it will reach the replacement limit."
            nominalBaseline="A healthy part stays above score 75 with minimal degradation over time."
            anomalyIndications="A score dropping under 45 turns the component red and requires replacement or adjustment during the next maintenance visit."
          />
        </div>
      }
    >
      <div className="w-full h-full flex flex-col justify-between">
        <div ref={containerRef} className="w-full flex justify-center py-1 overflow-hidden" />

        {/* Legend */}
        <div className="flex flex-wrap items-center justify-between text-[11px] font-mono text-slate-400 pt-1 border-t border-industrial-800/60 mt-1 px-1">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1 text-slate-200 font-bold">
              <span className="w-2.5 h-1 bg-cyan-400" /> Part Health Line
            </span>
            <span className="flex items-center gap-1 text-red-400">
              <span className="w-2.5 h-0.5 border-t border-dashed border-red-400" /> Service Limit (&lt; 45)
            </span>
          </div>
          <span className="text-[10px] text-slate-500">
            Shaded Red: Needs Immediate Replacement
          </span>
        </div>
      </div>
    </ChartCard>
  );
};
