// ============================================================================
// DIGITAL SIGNAL PROCESSING & TIME-SERIES HELPERS
// Radix-2 FFT, Hann Windowing, Peak Detection, Min-Max Downsampling, 30-Day Trend
// ============================================================================

export interface FftResult {
  frequencies: number[];
  magnitudes: number[];
  topPeaks: { freq: number; mag: number }[];
  baselineMagnitudes: number[];
  energyAt45HzRatio: number; // Ratio compared to healthy baseline
}

/**
 * Apply Hann window to input signal: w[n] = 0.5 * (1 - cos(2*pi*n / (N - 1)))
 */
export function applyHannWindow(samples: number[]): number[] {
  const N = samples.length;
  const windowed = new Array<number>(N);
  for (let n = 0; n < N; n++) {
    const w = 0.5 * (1 - Math.cos((2 * Math.PI * n) / (N - 1)));
    windowed[n] = samples[n] * w;
  }
  return windowed;
}

/**
 * In-place Cooley-Tukey Radix-2 Fast Fourier Transform
 * Requires length to be a power of 2.
 */
function radix2Fft(re: Float64Array, im: Float64Array) {
  const n = re.length;

  // Bit-reversal permutation
  let j = 0;
  for (let i = 0; i < n - 1; i++) {
    if (i < j) {
      const tempRe = re[i];
      re[i] = re[j];
      re[j] = tempRe;
      const tempIm = im[i];
      im[i] = im[j];
      im[j] = tempIm;
    }
    let k = n >> 1;
    while (k <= j) {
      j -= k;
      k >>= 1;
    }
    j += k;
  }

  // Butterfly computations
  for (let len = 2; len <= n; len <<= 1) {
    const halfLen = len >> 1;
    const angle = (-2 * Math.PI) / len;
    const wStepRe = Math.cos(angle);
    const wStepIm = Math.sin(angle);

    for (let i = 0; i < n; i += len) {
      let wRe = 1;
      let wIm = 0;
      for (let k = 0; k < halfLen; k++) {
        const pos1 = i + k;
        const pos2 = pos1 + halfLen;

        const uRe = re[pos1];
        const uIm = im[pos1];
        const vRe = re[pos2] * wRe - im[pos2] * wIm;
        const vIm = re[pos2] * wIm + im[pos2] * wRe;

        re[pos1] = uRe + vRe;
        im[pos1] = uIm + vIm;
        re[pos2] = uRe - vRe;
        im[pos2] = uIm - vIm;

        const nextWRe = wRe * wStepRe - wIm * wStepIm;
        wIm = wRe * wStepIm + wIm * wStepRe;
        wRe = nextWRe;
      }
    }
  }
}

/**
 * Compute single-sided amplitude spectrum from raw sample buffer
 * @param samples raw acceleration samples
 * @param sampleRate sample rate in Hz (e.g. 1000)
 * @param maxFreq display frequency cutoff in Hz (e.g. 100 or 120)
 */
export function computeFftSpectrum(
  samples: number[],
  sampleRate: number = 1000,
  maxFreq: number = 100
): FftResult {
  if (samples.length < 64) {
    return {
      frequencies: [],
      magnitudes: [],
      topPeaks: [],
      baselineMagnitudes: [],
      energyAt45HzRatio: 1.0,
    };
  }

  // Pick power of 2 matching available buffer length
  const N = samples.length >= 1024 ? 1024 : samples.length >= 512 ? 512 : 256;
  const slice = samples.slice(-N);

  const re = new Float64Array(N);
  const im = new Float64Array(N);

  // Apply Hann window (safe with zero padding for indices >= slice.length)
  for (let i = 0; i < N; i++) {
    const val = i < slice.length ? slice[i] : 0;
    const w = 0.5 * (1 - Math.cos((2 * Math.PI * i) / (N - 1)));
    re[i] = val * w;
    im[i] = 0;
  }

  radix2Fft(re, im);

  const halfN = N >> 1;
  const freqStep = sampleRate / N;

  const frequencies: number[] = [];
  const magnitudes: number[] = [];
  const baselineMagnitudes: number[] = [];

  for (let k = 0; k < halfN; k++) {
    const freq = k * freqStep;
    if (freq > maxFreq) break;

    // Single-sided amplitude with Hann coherent gain factor (4/N)
    const mag = (4 * Math.sqrt(re[k] * re[k] + im[k] * im[k])) / N;
    frequencies.push(Number(freq.toFixed(1)));
    magnitudes.push(Number(mag.toFixed(5)));

    // Synthetic healthy reference baseline model (0.012g at 45Hz, 0.018g at 12Hz)
    const base12 = 0.018 * Math.exp(-Math.pow((freq - 12.2) / 2.5, 2));
    const base45 = 0.012 * Math.exp(-Math.pow((freq - 44.8) / 3.0, 2));
    baselineMagnitudes.push(Number((0.002 + base12 + base45).toFixed(5)));
  }

  // Find local peaks
  const peaks: { freq: number; mag: number }[] = [];
  for (let i = 1; i < magnitudes.length - 1; i++) {
    if (
      magnitudes[i] > magnitudes[i - 1] &&
      magnitudes[i] > magnitudes[i + 1] &&
      magnitudes[i] > 0.008
    ) {
      peaks.push({ freq: frequencies[i], mag: magnitudes[i] });
    }
  }

  // Sort descending by magnitude and take top 3
  peaks.sort((a, b) => b.mag - a.mag);
  const topPeaks = peaks.slice(0, 3);

  // Compute peak ratio near 45 Hz (43 - 47 Hz resonance band)
  let maxActual45 = 0;
  let maxBaseline45 = 0.012; // Nominal 45 Hz baseline amplitude

  for (let i = 0; i < frequencies.length; i++) {
    const f = frequencies[i];
    if (f >= 43 && f <= 47) {
      if (magnitudes[i] > maxActual45) {
        maxActual45 = magnitudes[i];
      }
    }
  }

  const energyAt45HzRatio =
    maxBaseline45 > 0 ? Number((maxActual45 / maxBaseline45).toFixed(1)) : 1.0;

  return {
    frequencies,
    magnitudes,
    topPeaks,
    baselineMagnitudes,
    energyAt45HzRatio,
  };
}

/**
 * Min-Max Bucketing Downsampler
 * Guarantees never rendering more than maxTargetPoints while preserving shock peaks
 */
export function downsampleMinMax(
  times: number[],
  values: number[],
  maxTargetPoints: number = 2400
): { times: number[]; values: number[] } {
  const n = times.length;
  if (n <= maxTargetPoints) {
    return { times, values };
  }

  const bucketCount = Math.floor(maxTargetPoints / 2);
  const bucketSize = Math.floor(n / bucketCount);

  const outTimes: number[] = [];
  const outValues: number[] = [];

  for (let b = 0; b < bucketCount; b++) {
    const startIdx = b * bucketSize;
    const endIdx = b === bucketCount - 1 ? n : (b + 1) * bucketSize;

    let minVal = values[startIdx];
    let minTime = times[startIdx];
    let maxVal = values[startIdx];
    let maxTime = times[startIdx];
    let minIdx = startIdx;
    let maxIdx = startIdx;

    for (let i = startIdx + 1; i < endIdx; i++) {
      const v = values[i];
      const t = times[i];
      if (v < minVal) {
        minVal = v;
        minTime = t;
        minIdx = i;
      }
      if (v > maxVal) {
        maxVal = v;
        maxTime = t;
        maxIdx = i;
      }
    }

    // Preserve temporal order between min and max within bucket
    if (minIdx < maxIdx) {
      outTimes.push(minTime, maxTime);
      outValues.push(minVal, maxVal);
    } else {
      outTimes.push(maxTime, minTime);
      outValues.push(maxVal, minVal);
    }
  }

  return { times: outTimes, values: outValues };
}

// ============================================================================
// 30-DAY HISTORICAL TREND GENERATOR
// RMS, Peak, and Crest Factor per trip over 30 days
// ============================================================================

export interface TripTrendPoint {
  tripId: string;
  timestamp: number;
  dayLabel: string;
  floor: number;
  direction: 'up' | 'down';
  rmsG: number;
  peakG: number;
  crestFactor: number;
  healthScore: number;
}

export function generate30DayTripHistory(): TripTrendPoint[] {
  const history: TripTrendPoint[] = [];
  const now = Date.now();
  const oneDayMs = 86400000;
  const tripsPerDay = 8;
  const totalDays = 30;

  for (let day = totalDays - 1; day >= 0; day--) {
    const dayTimestamp = now - day * oneDayMs;
    const date = new Date(dayTimestamp);
    const dayLabel = `${date.getMonth() + 1}/${date.getDate()}`;

    // Slow progression over the 30 days
    const degradeProgression = (totalDays - 1 - day) / totalDays;

    for (let t = 0; t < tripsPerDay; t++) {
      const tripTime = dayTimestamp + t * (oneDayMs / tripsPerDay) + (Math.random() - 0.5) * 3600000;
      const tripNum = (totalDays - 1 - day) * tripsPerDay + (t + 1);

      // RMS climbs from 0.048 to ~0.182 over 30 days with some noise
      const baseRms = 0.048 + degradeProgression * 0.08 + (Math.random() - 0.5) * 0.015;
      // Peak is typically 3 - 5x RMS, with occasional shock spikes
      const isShockTrip = Math.random() < 0.12;
      const peakMultiplier = isShockTrip ? 4.8 + Math.random() * 2.2 : 2.8 + Math.random() * 0.8;
      const peakG = baseRms * peakMultiplier;
      const crestFactor = Number((peakG / baseRms).toFixed(2));
      const healthScore = Math.max(30, Math.round(98 - degradeProgression * 45 + (Math.random() - 0.5) * 4));

      history.push({
        tripId: `TRIP-${tripNum.toString().padStart(4, '0')}`,
        timestamp: Math.round(tripTime),
        dayLabel,
        floor: Math.floor(Math.random() * 19) + 2,
        direction: Math.random() > 0.5 ? 'up' : 'down',
        rmsG: Number(baseRms.toFixed(4)),
        peakG: Number(peakG.toFixed(4)),
        crestFactor,
        healthScore,
      });
    }
  }

  return history;
}

// ============================================================================
// EXPORT UTILITIES: CSV & PNG
// ============================================================================

export function exportCsv(filename: string, headers: string[], rows: (string | number)[][]) {
  const csvContent = [
    headers.join(','),
    ...rows.map((row) => row.map((cell) => `"${cell}"`).join(',')),
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `${filename}.csv`;
  link.click();
  URL.revokeObjectURL(link.href);
}
