import React, { useEffect, useState } from 'react';
import { AlertItem } from '../components/AlertItem';
import { ChartCard } from '../components/ChartCard';
import { KpiTile } from '../components/KpiTile';
import { StatusChip } from '../components/StatusChip';
import { APP_CONFIG } from '../config';
import { useElevatorStore } from '../store/useElevatorStore';
import type { Alert, AlertSeverity, SystemStatus, WidgetState } from '../types';
import {
  Activity,
  Layers,
  Pause,
  Play,
  RotateCcw,
  Sparkles,
  Zap,
} from 'lucide-react';

export const ComponentsPage: React.FC = () => {
  const isStreamPaused = useElevatorStore((state) => state.isStreamPaused);
  const togglePauseStream = useElevatorStore((state) => state.togglePauseStream);
  const latestVibrationRms = useElevatorStore((state) => state.latestVibrationRms);
  const latestVision = useElevatorStore((state) => state.latestVision);
  const lastUpdate = useElevatorStore((state) => state.lastUpdate);

  const [currentTime, setCurrentTime] = useState(Date.now());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(Date.now()), 250);
    return () => clearInterval(timer);
  }, []);

  const vibrationAge = lastUpdate.vibration
    ? Math.max(0, Number(((currentTime - lastUpdate.vibration) / 1000).toFixed(1)))
    : null;
  const isLiveVibrationStale = vibrationAge !== null && vibrationAge > APP_CONFIG.STALE_DATA_THRESHOLD_MS / 1000;

  // Mock static alerts for showcase
  const sampleCriticalAlert: Alert = {
    id: 'demo-crit-1',
    ts: Date.now() - 45000,
    severity: 'critical',
    component: 'rail_joints',
    message: 'Transient shock impulse 0.68 g detected at joint fishplate #14.',
    acknowledged: false,
  };

  const sampleWarningAlert: Alert = {
    id: 'demo-warn-1',
    ts: Date.now() - 120000,
    severity: 'warning',
    component: 'guide_rails',
    message: 'Lateral rail deviation (1.82 mm) approaching maximum operating threshold.',
    acknowledged: false,
  };

  const sampleInfoAlert: Alert = {
    id: 'demo-info-1',
    ts: Date.now() - 300000,
    severity: 'info',
    component: 'guide_shoes',
    message: 'Scheduled automatic lubrication cycle executed successfully.',
    acknowledged: true,
  };

  return (
    <div className="p-4 md:p-6 space-y-8 max-w-7xl mx-auto font-sans">
      {/* Title & Interactive Pause Trigger Banner */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-industrial-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>STAGE 2 // COMPONENT SYSTEM & WIDGET STATES</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight text-slate-100 flex items-center gap-2.5">
            <span>Component States Showcase</span>
            <span className="text-xs px-2 py-0.5 rounded font-mono font-semibold bg-industrial-800 text-cyan-300 border border-cyan-800">
              /components
            </span>
          </h2>
          <p className="text-sm text-slate-400 mt-0.5">
            Demonstrating all 4 mandatory states (Normal, Stale-Data &gt;5s, Loading, No-Data) across all reusable dashboard primitives.
          </p>
        </div>

        {/* Live Staleness Acceptance Tester */}
        <div className="bg-industrial-900 border border-industrial-800 p-3 rounded-lg flex items-center gap-3">
          <div className="text-right font-mono text-xs">
            <div className="text-slate-400 text-[10px] uppercase font-bold">Live Stream Status:</div>
            <div className={isStreamPaused ? 'text-amber-400 font-bold' : 'text-emerald-400 font-bold'}>
              {isStreamPaused ? `PAUSED (${vibrationAge}s ago)` : `STREAMING (${vibrationAge}s)`}
            </div>
          </div>
          <button
            onClick={togglePauseStream}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-mono font-bold transition-all ${
              isStreamPaused
                ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-900/50'
                : 'bg-amber-600 hover:bg-amber-500 text-slate-950 font-extrabold shadow-md shadow-amber-900/50'
            }`}
          >
            {isStreamPaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
            <span>{isStreamPaused ? 'RESUME STREAM' : 'PAUSE TO TEST STALE STATE'}</span>
          </button>
        </div>
      </div>

      {/* Staleness verification guide callout */}
      <div className="p-3 rounded-md bg-industrial-900/60 border border-cyan-800/50 flex items-start gap-3 text-xs font-mono text-slate-300">
        <Activity className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
        <div>
          <strong className="text-cyan-300">Stale State Acceptance Test:</strong> When stream is paused, the elapsed time since the last batch accumulates. Once it exceeds <strong>{APP_CONFIG.STALE_DATA_THRESHOLD_MS / 1000} seconds</strong>, all dynamic live widgets automatically switch to the <span className="text-amber-400 font-bold">STALE</span> state, dimming the widget body and rendering an amber badge.
        </div>
      </div>

      {/* =================================================================== */}
      {/* SECTION 1: LIVE INTERACTIVE WIDGETS (REACTS TO STREAM PAUSE) */}
      {/* =================================================================== */}
      <div className="space-y-3">
        <div className="flex items-center justify-between pb-1 border-b border-industrial-800">
          <h3 className="text-sm font-mono font-bold uppercase tracking-wider text-slate-200 flex items-center gap-2">
            <Zap className="w-4 h-4 text-cyan-400" />
            1. Live Reactive Widgets (Tied to Store Stream)
          </h3>
          <span className="text-xs font-mono text-slate-400">
            Current State:{' '}
            <strong className={isLiveVibrationStale ? 'text-amber-400' : 'text-emerald-400'}>
              {isLiveVibrationStale ? 'STALE (>5s)' : 'NORMAL'}
            </strong>
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <KpiTile
            title="Live Z-Axis RMS Vibration"
            subtitle="Broadband vertical acceleration energy"
            value={latestVibrationRms.z.toFixed(4)}
            unit="g RMS"
            status={latestVibrationRms.z > 0.15 ? 'warning' : 'healthy'}
            lastUpdated={lastUpdate.vibration}
            trend={{ direction: 'flat', value: '±0.002 g', isGood: true }}
          />

          <KpiTile
            title="Live Rail Deviation"
            subtitle="Camera optical edge alignment"
            value={latestVision?.deviationMm ?? 0.35}
            unit="mm"
            status={
              (latestVision?.deviationMm ?? 0) > 2.0
                ? 'critical'
                : (latestVision?.deviationMm ?? 0) > 1.2
                ? 'warning'
                : 'healthy'
            }
            lastUpdated={lastUpdate.vision}
            trend={{ direction: 'up', value: '+0.04 mm/s', isGood: false }}
          />

          <ChartCard
            title="Live Stream Heartbeat"
            caption="Visual verification that this card dims and shows STALE badge when stream is paused for >5s"
            units="[g]"
            lastUpdated={lastUpdate.vibration}
            minHeight="min-h-[100px]"
          >
            <div className="h-24 w-full flex items-center justify-center bg-industrial-950/60 rounded border border-industrial-800 font-mono text-xs text-slate-300">
              <div className="text-center space-y-1">
                <div>Instantaneous 3-Axis:</div>
                <div className="flex gap-4 font-bold">
                  <span className="text-axis-x">X: {latestVibrationRms.x.toFixed(3)} g</span>
                  <span className="text-axis-y">Y: {latestVibrationRms.y.toFixed(3)} g</span>
                  <span className="text-axis-z">Z: {latestVibrationRms.z.toFixed(3)} g</span>
                </div>
              </div>
            </div>
          </ChartCard>
        </div>
      </div>

      {/* =================================================================== */}
      {/* SECTION 2: STATUSCHIP (ALL STATES & SIZES) */}
      {/* =================================================================== */}
      <div className="space-y-3">
        <div className="flex items-center justify-between pb-1 border-b border-industrial-800">
          <h3 className="text-sm font-mono font-bold uppercase tracking-wider text-slate-200">
            2. StatusChip Primitives (Healthy / Warning / Critical / Stale / Loading / No-Data)
          </h3>
          <span className="text-xs font-mono text-slate-400">Strict accessibility compliance</span>
        </div>

        <div className="bg-industrial-900 border border-industrial-800 p-4 rounded-lg space-y-4">
          <div className="flex flex-wrap items-center gap-3">
            <StatusChip status="healthy" label="HEALTHY (GREEN)" />
            <StatusChip status="warning" label="WARNING (AMBER)" />
            <StatusChip status="critical" label="CRITICAL (RED)" />
            <StatusChip status="nodata" label="NO DATA (GREY)" />
            <StatusChip status="stale" label="STALE DATA" />
            <StatusChip status="loading" label="LOADING" />
          </div>

          <div className="pt-2 border-t border-industrial-800/80 flex flex-wrap items-center gap-3">
            <span className="text-xs font-mono text-slate-500 mr-2">Sizes:</span>
            <StatusChip status="healthy" label="Small (sm)" size="sm" />
            <StatusChip status="healthy" label="Medium (md)" size="md" />
            <StatusChip status="healthy" label="Large (lg)" size="lg" />
            <StatusChip status="critical" label="Pulsing Critical" size="md" showPulse />
          </div>
        </div>
      </div>

      {/* =================================================================== */}
      {/* SECTION 3: KPITILE (4 MANDATORY STATES) */}
      {/* =================================================================== */}
      <div className="space-y-3">
        <div className="flex items-center justify-between pb-1 border-b border-industrial-800">
          <h3 className="text-sm font-mono font-bold uppercase tracking-wider text-slate-200">
            3. KpiTile Across 4 Mandatory States
          </h3>
          <span className="text-xs font-mono text-slate-400">
            Normal (Healthy/Warning/Critical), Stale, Loading, No-Data
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Normal State - Healthy */}
          <KpiTile
            state="normal"
            title="Guide Rail Deviation"
            subtitle="Optical lateral displacement"
            value="0.38"
            unit="mm"
            status="healthy"
            lastUpdated={Date.now() - 800}
            trend={{ direction: 'down', value: '-0.02 mm', isGood: true }}
          />

          {/* Normal State - Warning */}
          <KpiTile
            state="normal"
            title="Vertical RMS Energy"
            subtitle="45 Hz resonance band"
            value="0.185"
            unit="g"
            status="warning"
            lastUpdated={Date.now() - 1200}
            trend={{ direction: 'up', value: '+0.04 g', isGood: false }}
          />

          {/* Stale State */}
          <KpiTile
            state="stale"
            title="Joint Gap Spacing"
            subtitle="Fishplate mechanical expansion"
            value="2.14"
            unit="mm"
            status="warning"
            lastUpdated={Date.now() - 7200}
            trend={{ direction: 'flat', value: '0.00 mm' }}
          />

          {/* Loading State */}
          <KpiTile
            state="loading"
            title="Ride Comfort Index"
            subtitle="ISO 18738 computation"
            isLoading
          />

          {/* No-Data State */}
          <KpiTile
            state="no-data"
            title="Frame Torsion Strain"
            subtitle="Structural strain gauge array"
            value={null}
          />
        </div>
      </div>

      {/* =================================================================== */}
      {/* SECTION 4: CHARTCARD (4 MANDATORY STATES) */}
      {/* =================================================================== */}
      <div className="space-y-3">
        <div className="flex items-center justify-between pb-1 border-b border-industrial-800">
          <h3 className="text-sm font-mono font-bold uppercase tracking-wider text-slate-200">
            4. ChartCard Across 4 Mandatory States
          </h3>
          <span className="text-xs font-mono text-slate-400">
            Title, plain-language caption, units, toolbar slot, state handlers
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* State 1: Normal */}
          <ChartCard
            state="normal"
            title="Vibration Waveform History"
            units="[g]"
            caption="High-frequency acceleration showing lateral and vertical car dynamics over the rolling 30-second window."
            lastUpdated={Date.now() - 400}
            toolbar={
              <div className="flex items-center gap-1.5 text-xs font-mono">
                <span className="flex items-center gap-1 text-axis-x">
                  <span className="w-2 h-2 rounded-full bg-axis-x" /> X (Lateral)
                </span>
                <span className="flex items-center gap-1 text-axis-y">
                  <span className="w-2 h-2 rounded-full bg-axis-y" /> Y (Fore-Aft)
                </span>
                <span className="flex items-center gap-1 text-axis-z">
                  <span className="w-2 h-2 rounded-full bg-axis-z" /> Z (Vertical)
                </span>
              </div>
            }
          >
            <div className="h-44 w-full bg-industrial-950/70 rounded border border-industrial-800/80 p-3 flex flex-col justify-center items-center font-mono text-xs text-slate-400">
              <div className="w-full flex items-center justify-between text-[11px] text-slate-500 mb-2">
                <span>+0.25 g</span>
                <span>Active 1000 Hz Buffer</span>
              </div>
              <div className="w-full h-20 flex items-center gap-0.5 justify-around px-2">
                {Array.from({ length: 48 }).map((_, i) => (
                  <div
                    key={i}
                    className="w-1 bg-cyan-500/60 rounded-xs"
                    style={{
                      height: `${Math.max(10, Math.sin(i * 0.3) * 35 + 40)}%`,
                    }}
                  />
                ))}
              </div>
              <div className="w-full flex items-center justify-between text-[11px] text-slate-500 mt-2">
                <span>-0.25 g</span>
                <span>t - 30.0s</span>
              </div>
            </div>
          </ChartCard>

          {/* State 2: Stale */}
          <ChartCard
            state="stale"
            title="Spectral Power Density"
            units="[g²/Hz]"
            caption="Fast Fourier Transform energy distribution across frequency bins (shows STALE badge and dimming)."
            lastUpdated={Date.now() - 8400}
          >
            <div className="h-44 w-full bg-industrial-950/70 rounded border border-industrial-800/80 p-3 flex items-center justify-center font-mono text-xs text-slate-500">
              <span>(Display dimmed due to stale telemetry connection)</span>
            </div>
          </ChartCard>

          {/* State 3: Loading */}
          <ChartCard
            state="loading"
            title="Joint Shock Waveform Spectrogram"
            units="[dB]"
            caption="Short-time Fourier transform (STFT) frequency-vs-time spectrogram."
            isLoading
          >
            <div className="h-44 w-full bg-industrial-950/50 rounded" />
          </ChartCard>

          {/* State 4: No-Data */}
          <ChartCard
            state="no-data"
            title="Shaft Alignment Profilometer"
            units="[mm]"
            caption="Full shaft height spatial profile deviation curve."
            hasData={false}
          >
            <div className="h-44 w-full bg-industrial-950/50 rounded" />
          </ChartCard>
        </div>
      </div>

      {/* =================================================================== */}
      {/* SECTION 5: ALERTITEM (ALL SEVERITIES & STATES) */}
      {/* =================================================================== */}
      <div className="space-y-3">
        <div className="flex items-center justify-between pb-1 border-b border-industrial-800">
          <h3 className="text-sm font-mono font-bold uppercase tracking-wider text-slate-200">
            5. AlertItem Primitives Across Severities & States
          </h3>
          <span className="text-xs font-mono text-slate-400">
            Critical, Warning, Info, Stale, Loading, No-Data
          </span>
        </div>

        <div className="space-y-2.5">
          {/* Critical */}
          <AlertItem
            alert={sampleCriticalAlert}
            onAcknowledge={(id) => alert(`Acknowledged alert: ${id}`)}
          />

          {/* Warning */}
          <AlertItem
            alert={sampleWarningAlert}
            onAcknowledge={(id) => alert(`Acknowledged alert: ${id}`)}
          />

          {/* Info (Acknowledged) */}
          <AlertItem alert={sampleInfoAlert} />

          {/* Stale Alert */}
          <AlertItem
            alert={{
              ...sampleCriticalAlert,
              id: 'demo-stale-1',
              message: 'Guide shoe lateral clearance exceeded safety envelope (Historical unrefreshed event).',
            }}
            state="stale"
          />

          {/* Loading Alert Item */}
          <AlertItem state="loading" />

          {/* No-Data Alert Item */}
          <AlertItem state="no-data" />
        </div>
      </div>
    </div>
  );
};
