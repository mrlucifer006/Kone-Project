import React, { useState } from 'react';
import { HelpCircle, Info, X } from 'lucide-react';

export interface HelpPopoverProps {
  title: string;
  whatIsIt: string;
  nominalBaseline: string;
  anomalyIndications: string;
}

export const HelpPopover: React.FC<HelpPopoverProps> = ({
  title,
  whatIsIt,
  nominalBaseline,
  anomalyIndications,
}) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="relative inline-block">
      <button
        onClick={() => setIsOpen((prev) => !prev)}
        title="What am I looking at? (Diagnostic Guide)"
        className="flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-mono font-medium text-slate-400 hover:text-cyan-300 hover:bg-industrial-800 border border-industrial-800 transition-colors"
      >
        <HelpCircle className="w-3 h-3 text-cyan-400" />
        <span className="hidden sm:inline">What am I looking at?</span>
      </button>

      {isOpen && (
        <div className="absolute right-0 top-full mt-2 w-80 sm:w-96 z-50 bg-industrial-900 border border-cyan-800/80 rounded-lg p-4 shadow-2xl font-mono text-xs space-y-3 animate-in fade-in zoom-in-95">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-industrial-800 pb-2">
            <div className="flex items-center gap-1.5 text-cyan-300 font-bold uppercase tracking-wider">
              <Info className="w-3.5 h-3.5 text-cyan-400" />
              <span>{title}</span>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-slate-400 hover:text-white p-0.5"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Body */}
          <div className="space-y-2.5 font-sans text-slate-300 text-xs leading-relaxed">
            <div>
              <strong className="font-mono text-cyan-400 text-[11px] block uppercase">
                What this chart shows:
              </strong>
              <p>{whatIsIt}</p>
            </div>

            <div>
              <strong className="font-mono text-emerald-400 text-[11px] block uppercase">
                Healthy Baseline Envelope:
              </strong>
              <p>{nominalBaseline}</p>
            </div>

            <div>
              <strong className="font-mono text-amber-400 text-[11px] block uppercase">
                Fault & Anomaly Indications:
              </strong>
              <p>{anomalyIndications}</p>
            </div>
          </div>

          {/* Footer */}
          <div className="pt-2 border-t border-industrial-800 text-[10px] text-slate-500 font-mono flex justify-between">
            <span>KONE FIELD DIAGNOSTICS MANUAL</span>
            <button
              onClick={() => setIsOpen(false)}
              className="text-cyan-400 hover:underline"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
