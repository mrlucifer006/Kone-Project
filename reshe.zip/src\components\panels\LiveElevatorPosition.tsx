import React from 'react';
import { APP_CONFIG } from '../../config';
import { useElevatorStore } from '../../store/useElevatorStore';
import {
  ArrowDown,
  ArrowUp,
  Building2,
  Gauge,
  MapPin,
  PauseCircle,
  Zap,
} from 'lucide-react';

export const LiveElevatorPosition: React.FC = () => {
  const latestMotion = useElevatorStore((state) => state.latestMotion);
  const latestVibrationRms = useElevatorStore((state) => state.latestVibrationRms);

  const floor = latestMotion?.floor ?? 1;
  const speed = latestMotion?.speedMs ?? 0.0;
  const positionM = latestMotion?.position_m ?? 0.0;
  const accel = latestMotion?.accelMs2 ?? 0.0;
  const tripState = latestMotion?.tripState ?? 'stopped';

  const totalHeightM = APP_CONFIG.ELEVATOR_PHYSICS.TOTAL_HEIGHT_M;
  const normalizedY = Math.max(0, Math.min(1, positionM / totalHeightM));

  // Ride smoothness
  const zRms = latestVibrationRms.z;
  const rideQuality =
    zRms < APP_CONFIG.THRESHOLDS.RIDE_COMFORT.COMFORTABLE_MAX_G
      ? { label: 'SMOOTH RIDE', color: 'bg-emerald-950 text-emerald-400 border-emerald-800' }
      : zRms < APP_CONFIG.THRESHOLDS.RIDE_COMFORT.ACCEPTABLE_MAX_G
      ? { label: 'NORMAL RIDE', color: 'bg-amber-950 text-amber-400 border-amber-800' }
      : { label: 'ROUGH / SHAKY', color: 'bg-red-950 text-red-400 border-red-800 animate-pulse' };

  const getTripDetails = () => {
    switch (tripState) {
      case 'accelerating':
        return {
          label: 'MOVING UP / STARTING',
          color: 'text-cyan-400',
          icon: <ArrowUp className="w-5 h-5 text-cyan-400 animate-bounce" />,
        };
      case 'cruising':
        return {
          label: 'CRUISING AT SPEED',
          color: 'text-emerald-400',
          icon: <ArrowUp className="w-5 h-5 text-emerald-400" />,
        };
      case 'decelerating':
        return {
          label: 'APPROACHING FLOOR',
          color: 'text-amber-400',
          icon: <ArrowDown className="w-5 h-5 text-amber-400 animate-bounce" />,
        };
      case 'stopped':
      default:
        return {
          label: 'STOPPED AT FLOOR',
          color: 'text-slate-400',
          icon: <PauseCircle className="w-5 h-5 text-slate-400" />,
        };
    }
  };

  const trip = getTripDetails();

  return (
    <div className="bg-industrial-900 border border-industrial-800 rounded-lg p-4 flex flex-col justify-between font-sans shadow-md">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-industrial-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 mb-0.5">
            <Building2 className="w-3.5 h-3.5" />
            <span>CAR POSITION & HOISTWAY KINEMATICS</span>
          </div>
          <h3 className="text-base font-bold text-slate-100">Elevator Position</h3>
        </div>

        {/* Ride Comfort Badge */}
        <span
          className={`px-2.5 py-1 rounded text-[11px] font-mono font-bold border ${rideQuality.color}`}
        >
          {rideQuality.label}
        </span>
      </div>

      {/* Main Grid: Floor & Travel info + Mini Vertical Shaft */}
      <div className="my-3 grid grid-cols-1 sm:grid-cols-3 gap-4 items-center">
        {/* Left: Huge Floor Readout */}
        <div className="bg-industrial-950/80 p-3.5 rounded-lg border border-industrial-800/80 flex flex-col justify-center items-center font-mono">
          <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">
            Current Floor
          </span>
          <div className="flex items-baseline gap-1 my-1">
            <span className="text-4xl sm:text-5xl font-black text-cyan-400">
              {floor}
            </span>
            <span className="text-slate-500 text-xs">/ 20</span>
          </div>
          <div className="flex items-center gap-1.5 mt-1">
            {trip.icon}
            <span className={`text-[11px] font-bold ${trip.color}`}>{trip.label}</span>
          </div>
        </div>

        {/* Center: Kinematics (Speed & Position & Acceleration) */}
        <div className="bg-industrial-950/80 p-3.5 rounded-lg border border-industrial-800/80 space-y-2.5 font-mono text-xs">
          {/* Speed */}
          <div className="flex items-center justify-between">
            <span className="text-slate-400 flex items-center gap-1">
              <Gauge className="w-3.5 h-3.5 text-cyan-400" /> Car Speed:
            </span>
            <strong className="text-slate-100 text-sm">{speed.toFixed(2)} m/s</strong>
          </div>

          {/* Height Position */}
          <div className="flex items-center justify-between">
            <span className="text-slate-400 flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-emerald-400" /> Shaft Height:
            </span>
            <strong className="text-slate-100 text-sm">{positionM.toFixed(1)} m</strong>
          </div>

          {/* Acceleration */}
          <div className="flex items-center justify-between">
            <span className="text-slate-400 flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-amber-400" /> Acceleration:
            </span>
            <strong className="text-slate-100 text-sm">
              {accel >= 0 ? '+' : ''}{accel.toFixed(2)} m/s²
            </strong>
          </div>
        </div>

        {/* Right: Sleek Visual Hoistway Column */}
        <div className="bg-industrial-950/80 p-3 rounded-lg border border-industrial-800/80 flex items-center justify-between font-mono">
          <div className="flex flex-col justify-between h-28 text-[9px] text-slate-500 pr-2">
            <span>FL 20</span>
            <span>FL 15</span>
            <span>FL 10</span>
            <span>FL 5</span>
            <span>FL 1</span>
          </div>

          {/* Hoistway Shaft Track */}
          <div className="relative flex-1 h-28 bg-industrial-900 rounded border border-industrial-800 flex justify-center">
            {/* Guide rail line */}
            <div className="absolute top-0 bottom-0 w-1 bg-industrial-700" />

            {/* Elevator Car Block moving vertically */}
            <div
              className="absolute w-7 h-5 rounded bg-cyan-600 border border-cyan-300 shadow-[0_0_10px_rgba(6,182,212,0.6)] flex items-center justify-center text-[9px] font-bold text-slate-950 transition-all duration-300 ease-out"
              style={{
                bottom: `${Math.max(2, Math.min(92, normalizedY * 100))}%`,
              }}
            >
              {floor}
            </div>
          </div>
        </div>
      </div>

      {/* Footer Info */}
      <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-2 border-t border-industrial-800/80 px-1">
        <span>Travel: Floor 1 to Floor 20 (60 m Total Travel)</span>
        <span className="text-slate-300">
          Z-Vibration Energy: <strong className="text-emerald-400">{zRms.toFixed(3)} g</strong>
        </span>
      </div>
    </div>
  );
};
