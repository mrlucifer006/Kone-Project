import React, { useEffect, useMemo, useRef, useState } from 'react';
import uPlot from 'uplot';
import { generate30DayTripHistory, TripTrendPoint } from '../../lib/dsp';
import { ChartCard } from '../ChartCard';
import { HelpPopover } from '../HelpPopover';

export const TrendChart: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const uplotRef = useRef<uPlot | null>(null);

  // Generate 30-day trip history (cached memo)
  const history = useMemo(() => generate30DayTripHistory(), []);

  const [activeMetrics, setActiveMetrics] = useState({
    rms: true,
    peak: true,
    crest: true,
  });

  const latestPoint = history[history.length - 1];

  useEffect(() => {
    if (!containerRef.current || history.length === 0) return;

    // Build data arrays: [timestampsSec, rms, peak, crestFactor]
    const times = history.map((p) => p.timestamp / 1000);
    const rms = history.map((p) => p.rmsG);
    const peak = history.map((p) => p.peakG);
    const crest = history.map((p) => p.crestFactor);

    const seriesList: uPlot.Series[] = [{ label: 'Date' }];
    const dataList: uPlot.AlignedData = [times];

    if (activeMetrics.rms) {
      seriesList.push({
        label: 'Trip RMS (g)',
        stroke: '#10b981', // Emerald
        width: 2,
        scale: 'g',
        points: { show: false },
      });
      dataList.push(rms);
    }

    if (activeMetrics.peak) {
      seriesList.push({
        label: 'Peak Accel (g)',
        stroke: '#f59e0b', // Amber
        width: 1.5,
        scale: 'g',
        points: { show: false },
      });
      dataList.push(peak);
    }

    if (activeMetrics.crest) {
      seriesList.push({
        label: 'Crest Factor (Peak/RMS)',
        stroke: '#38bdf8', // Cyan
        width: 1.5,
        scale: 'ratio',
        dash: [4, 4],
        points: { show: false },
      });
      dataList.push(crest);
    }

    const opts: uPlot.Options = {
      width: containerRef.current.clientWidth || 600,
      height: 230,
      cursor: {
        drag: { x: true, y: false, setScale: true },
      },
      scales: {
        x: {
          time: true,
        },
        g: {
          auto: true,
          range: [0, 0.4],
        },
        ratio: {
          auto: true,
          range: [1.5, 7.5],
        },
      },
      axes: [
        {
          stroke: '#64748b',
          grid: { stroke: 'rgba(51, 65, 85, 0.3)', width: 1 },
          ticks: { stroke: '#475569', width: 1 },
          values: (_, ticks) => ticks.map((t) => {
            const d = new Date(t * 1000);
            return `${d.getMonth() + 1}/${d.getDate()}`;
          }),
          font: '10px JetBrains Mono, monospace',
        },
        {
          scale: 'g',
          stroke: '#10b981',
          grid: { stroke: 'rgba(51, 65, 85, 0.3)', width: 1 },
          ticks: { stroke: '#475569', width: 1 },
          values: (_, vals) => vals.map((v) => `${v.toFixed(2)}g`),
          font: '10px JetBrains Mono, monospace',
        },
        {
          scale: 'ratio',
          side: 1, // Right axis
          stroke: '#38bdf8',
          grid: { show: false },
          ticks: { stroke: '#475569', width: 1 },
          values: (_, vals) => vals.map((v) => `${v.toFixed(1)}x`),
          font: '10px JetBrains Mono, monospace',
        },
      ],
      series: seriesList,
    };

    if (!uplotRef.current) {
      uplotRef.current = new uPlot(opts, dataList, containerRef.current);
    } else {
      uplotRef.current.destroy();
      uplotRef.current = new uPlot(opts, dataList, containerRef.current);
    }

    const handleResize = () => {
      if (containerRef.current && uplotRef.current) {
        uplotRef.current.setSize({
          width: containerRef.current.clientWidth || 600,
          height: 230,
        });
      }
    };

    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [history, activeMetrics]);

  const dynamicCaption = `30-day wear history: average shaking has shifted from ${history[0].rmsG.toFixed(3)} g to ${latestPoint.rmsG.toFixed(3)} g; shock ratio spikes indicate bumpier rail joint crossings.`;

  return (
    <ChartCard
      title="4. Daily Vibration History (Past 30 Days)"
      units="[Shaking Level & Shock Ratio]"
      caption={dynamicCaption}
      lastUpdated={Date.now()}
      hasData={history.length > 0}
      toolbar={
        <div className="flex items-center gap-2 font-mono text-xs">
          {/* Metric Toggles */}
          <button
            onClick={() => setActiveMetrics((m) => ({ ...m, rms: !m.rms }))}
            className={`px-1.5 py-0.5 rounded text-[10px] font-bold border transition-colors ${
              activeMetrics.rms
                ? 'bg-emerald-950 text-emerald-400 border-emerald-700'
                : 'text-slate-500 border-industrial-800'
            }`}
          >
            Average Shaking (RMS)
          </button>
          <button
            onClick={() => setActiveMetrics((m) => ({ ...m, peak: !m.peak }))}
            className={`px-1.5 py-0.5 rounded text-[10px] font-bold border transition-colors ${
              activeMetrics.peak
                ? 'bg-amber-950 text-amber-400 border-amber-700'
                : 'text-slate-500 border-industrial-800'
            }`}
          >
            Max Bump (Peak)
          </button>
          <button
            onClick={() => setActiveMetrics((m) => ({ ...m, crest: !m.crest }))}
            className={`px-1.5 py-0.5 rounded text-[10px] font-bold border transition-colors ${
              activeMetrics.crest
                ? 'bg-cyan-950 text-cyan-400 border-cyan-700'
                : 'text-slate-500 border-industrial-800'
            }`}
          >
            Shock Ratio
          </button>

          <HelpPopover
            title="30-Day Vibration History"
            whatIsIt="Tracks elevator shaking and bump intensity across runs over the last 30 days."
            nominalBaseline="A healthy elevator maintains a steady low vibration line under 0.07 g."
            anomalyIndications="A slow upward trend in average shaking indicates gradual mechanical wear. Spikes in the shock ratio mean the car is hitting misaligned rail joints."
          />
        </div>
      }
    >
      <div className="w-full h-full flex flex-col justify-between">
        <div ref={containerRef} className="w-full flex justify-center overflow-hidden py-1" />

        {/* Legend */}
        <div className="flex flex-wrap items-center justify-between text-[11px] font-mono text-slate-400 pt-1 border-t border-industrial-800/60 mt-1 px-1">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1 text-emerald-400">
              <span className="w-2.5 h-1 bg-emerald-400" /> Avg Shaking (RMS)
            </span>
            <span className="flex items-center gap-1 text-amber-400">
              <span className="w-2.5 h-1 bg-amber-400" /> Peak Bump
            </span>
            <span className="flex items-center gap-1 text-cyan-400">
              <span className="w-2.5 h-0.5 border-t border-dashed border-cyan-400" /> Shock Ratio
            </span>
          </div>

          <div className="text-slate-400 text-[10px]">
            Latest Run #{latestPoint.tripId}: Shaking {latestPoint.rmsG.toFixed(3)}g | Shock Ratio {latestPoint.crestFactor}x
          </div>
        </div>
      </div>
    </ChartCard>
  );
};
