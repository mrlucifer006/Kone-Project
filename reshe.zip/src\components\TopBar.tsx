import React from 'react';
import { NavLink } from 'react-router-dom';
import { useElevatorStore } from '../store/useElevatorStore';
import type { SimulationScenario } from '../types';
import { StatusChip } from './StatusChip';
import {
  Activity,
  Building2,
  Camera,
  Layers,
  Pause,
  Play,
  Radio,
  Wifi,
  Wrench,
} from 'lucide-react';

export const TopBar: React.FC = () => {
  const connectionStatus = useElevatorStore((state) => state.connectionStatus);
  const scenario = useElevatorStore((state) => state.scenario);
  const setScenario = useElevatorStore((state) => state.setScenario);
  const isStreamPaused = useElevatorStore((state) => state.isStreamPaused);
  const togglePauseStream = useElevatorStore((state) => state.togglePauseStream);
  const getOverallSystemStatus = useElevatorStore((state) => state.getOverallSystemStatus);

  const { status: systemStatus, worstComponent } = getOverallSystemStatus();

  const scenarios: { id: SimulationScenario; label: string }[] = [
    { id: 'healthy', label: 'Normal' },
    { id: 'degrading', label: 'Wear Drift' },
    { id: 'fault_spike', label: 'Rail Shock' },
  ];

  const getSimpleStatusLabel = () => {
    if (systemStatus === 'healthy') return 'ALL SYSTEMS GOOD';
    if (systemStatus === 'warning') return `CHECK ${worstComponent?.id.replace('_', ' ').toUpperCase() || 'SOON'}`;
    if (systemStatus === 'critical') return `SERVICE ${worstComponent?.id.replace('_', ' ').toUpperCase() || 'NOW'}`;
    return 'NO DATA';
  };

  return (
    <header className="border-b border-industrial-800 bg-industrial-900/95 sticky top-0 z-40 backdrop-blur px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 font-sans">
      {/* Left: Brand & Simulated Data Badge */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-6 bg-cyan-500 rounded-xs" />
          <div>
            <h1 className="text-sm font-bold tracking-wide uppercase text-slate-100 flex items-center gap-2">
              <span>Elevator Monitor</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-industrial-800 text-cyan-300 font-mono">
                Car #01
              </span>
            </h1>
            <p className="text-[10px] text-slate-400">
              C3 Cam &amp; Tri-Axial Vibration
            </p>
          </div>
        </div>

        {/* Simulated data badge */}
        <div>
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono font-bold tracking-wider uppercase bg-amber-500/10 text-amber-400 border border-amber-500/30">
            <Radio className="w-2.5 h-2.5 text-amber-400 animate-pulse" />
            <span>SIMULATED DATA</span>
          </span>
        </div>
      </div>

      {/* Center: Main Navigation Tabs */}
      <nav className="flex items-center gap-1 bg-industrial-950 p-1 rounded-lg border border-industrial-800 font-mono text-xs">
        <NavLink
          to="/"
          end
          className={({ isActive }) =>
            `flex items-center gap-1.5 px-3 py-1.5 rounded transition-colors ${
              isActive
                ? 'bg-industrial-800 text-cyan-300 font-bold shadow-xs border border-industrial-700'
                : 'text-slate-400 hover:text-slate-200'
            }`
          }
        >
          <Camera className="w-3.5 h-3.5 text-cyan-400" />
          <span>Overview &amp; Camera</span>
        </NavLink>

        <NavLink
          to="/vibration"
          className={({ isActive }) =>
            `flex items-center gap-1.5 px-3 py-1.5 rounded transition-colors ${
              isActive
                ? 'bg-industrial-800 text-cyan-300 font-bold shadow-xs border border-industrial-700'
                : 'text-slate-400 hover:text-slate-200'
            }`
          }
        >
          <Layers className="w-3.5 h-3.5 text-emerald-400" />
          <span>Vibration &amp; Insights</span>
        </NavLink>

        <NavLink
          to="/maintenance"
          className={({ isActive }) =>
            `flex items-center gap-1.5 px-3 py-1.5 rounded transition-colors ${
              isActive
                ? 'bg-industrial-800 text-cyan-300 font-bold shadow-xs border border-industrial-700'
                : 'text-slate-400 hover:text-slate-200'
            }`
          }
        >
          <Wrench className="w-3.5 h-3.5 text-amber-400" />
          <span>Maintenance &amp; Parts</span>
        </NavLink>
      </nav>

      {/* Right: Scenarios, Pause & Status */}
      <div className="flex items-center gap-2.5">
        {/* Scenario Switcher */}
        <div className="hidden md:flex items-center gap-1 bg-industrial-950 p-0.5 rounded border border-industrial-800 font-mono text-xs">
          <span className="text-[10px] text-slate-500 px-1 font-bold">SCENARIO:</span>
          {scenarios.map((sc) => {
            const isActive = scenario === sc.id;
            return (
              <button
                key={sc.id}
                onClick={() => setScenario(sc.id)}
                className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                  isActive
                    ? 'bg-industrial-800 text-slate-100 border border-industrial-700 font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {sc.label}
              </button>
            );
          })}
        </div>

        {/* Stream Pause / Play */}
        <button
          onClick={togglePauseStream}
          title={isStreamPaused ? 'Resume live stream' : 'Pause live stream'}
          className={`inline-flex items-center gap-1 px-2.5 py-1 rounded text-xs font-mono font-semibold border transition-colors ${
            isStreamPaused
              ? 'bg-amber-950 text-amber-300 border-amber-600 animate-pulse'
              : 'bg-industrial-800 text-slate-300 border-industrial-700 hover:bg-industrial-750'
          }`}
        >
          {isStreamPaused ? <Play className="w-3 h-3 text-amber-400" /> : <Pause className="w-3 h-3" />}
          <span>{isStreamPaused ? 'Resume' : 'Pause'}</span>
        </button>

        {/* Overall System Health Status */}
        <StatusChip
          status={systemStatus}
          label={getSimpleStatusLabel()}
          size="sm"
          showPulse={systemStatus === 'critical' || systemStatus === 'warning'}
        />
      </div>
    </header>
  );
};
