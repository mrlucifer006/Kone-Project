/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        industrial: {
          950: '#0a0d12',
          900: '#111620',
          850: '#151b27',
          800: '#1a2232',
          750: '#222c40',
          700: '#2a3750',
          600: '#3c4c6a',
          500: '#54668a',
          400: '#7e90b2',
          300: '#a7b6d1',
          200: '#cbd5e5',
          100: '#e2e8f0',
        },
        status: {
          healthy: '#10b981', // emerald-500
          warning: '#f59e0b', // amber-500
          critical: '#ef4444', // red-500
          nodata: '#64748b', // slate-500
        },
        axis: {
          x: '#3b82f6', // blue
          y: '#f97316', // orange
          z: '#22c55e', // green
        }
      },
      fontFamily: {
        mono: ['JetBrains Mono', 'Fira Code', 'Consolas', 'monospace'],
      }
    },
  },
  plugins: [],
}
