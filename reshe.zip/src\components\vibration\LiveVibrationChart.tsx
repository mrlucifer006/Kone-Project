import React, { useEffect, useRef, useState } from 'react';
import uPlot from 'uplot';
import 'uplot/dist/uPlot.min.css';
import { APP_CONFIG } from '../../config';
import { useElevatorStore } from '../../store/useElevatorStore';
import { Activity, Layers, RotateCcw } from 'lucide-react';

export interface LiveVibrationChartProps {
  timeWindowSec?: number; // e.g. 15 or 30 seconds
}

export const LiveVibrationChart: React.FC<LiveVibrationChartProps> = ({
  timeWindowSec = 20,
}) => {
  const vibrationBatches = useElevatorStore((state) => state.vibrationBatches);
  const isStreamPaused = useElevatorStore((state) => state.isStreamPaused);

  const containerRef = useRef<HTMLDivElement>(null);
  const uplotRef = useRef<uPlot | null>(null);
  const animFrameRef = useRef<number | null>(null);

  const [selectedAxis, setSelectedAxis] = useState<'all' | 'x' | 'y' | 'z'>('all');
  const [windowSec, setWindowSec] = useState<number>(timeWindowSec);

  // Peak tracking for display
  const latestBatch = vibrationBatches[vibrationBatches.length - 1];
  const currentMaxZ = latestBatch ? Math.max(...latestBatch.z) : 0.05;

  // 1. Initialize uPlot ONCE on mount
  useEffect(() => {
    if (!containerRef.current) return;

    // Series definitions
    const series: uPlot.Series[] = [
      { label: 'Time' },
      {
        label: 'X (Side)',
        stroke: APP_CONFIG.COLORS.AXIS.X, // Blue
        width: 1.5,
        points: { show: false },
        show: selectedAxis === 'all' || selectedAxis === 'x',
      },
      {
        label: 'Y (Front)',
        stroke: APP_CONFIG.COLORS.AXIS.Y, // Orange
        width: 1.5,
        points: { show: false },
        show: selectedAxis === 'all' || selectedAxis === 'y',
      },
      {
        label: 'Z (Vertical)',
        stroke: APP_CONFIG.COLORS.AXIS.Z, // Green
        width: 2,
        points: { show: false },
        show: selectedAxis === 'all' || selectedAxis === 'z',
      },
    ];

    const now = Date.now() / 1000;
    const initialData: uPlot.AlignedData = [
      [now - 1, now],
      [0, 0],
      [0, 0],
      [0, 0],
    ];

    const opts: uPlot.Options = {
      width: containerRef.current.clientWidth || 600,
      height: 500,
      cursor: { show: true },
      scales: {
        x: { time: true },
        y: {
          auto: false,
          range: [-0.35, 0.35],
        },
      },
      axes: [
        {
          stroke: '#64748b',
          grid: { stroke: 'rgba(51, 65, 85, 0.25)', width: 1 },
          ticks: { stroke: '#475569', width: 1 },
          values: (_, ticks) => ticks.map((t) => new Date(t * 1000).toLocaleTimeString().slice(3, 8)),
          font: '10px JetBrains Mono, monospace',
        },
        {
          stroke: '#94a3b8',
          grid: { stroke: 'rgba(51, 65, 85, 0.25)', width: 1 },
          ticks: { stroke: '#475569', width: 1 },
          values: (_, vals) => vals.map((v) => `${v >= 0 ? '+' : ''}${v.toFixed(2)}g`),
          font: '10px JetBrains Mono, monospace',
        },
      ],
      series,
      plugins: [
        {
          hooks: {
            draw: [
              (u) => {
                const ctx = u.ctx;
                const { left, width } = u.bbox;

                // Threshold lines: Warning ±0.15g (Amber)
                const yWarnPos = u.valToPos(0.15, 'y', true);
                const yWarnNeg = u.valToPos(-0.15, 'y', true);

                ctx.save();
                ctx.strokeStyle = 'rgba(245, 158, 11, 0.45)';
                ctx.setLineDash([4, 4]);
                ctx.lineWidth = 1;

                ctx.beginPath();
                ctx.moveTo(left, yWarnPos);
                ctx.lineTo(left + width, yWarnPos);
                ctx.moveTo(left, yWarnNeg);
                ctx.lineTo(left + width, yWarnNeg);
                ctx.stroke();

                // Threshold lines: Critical ±0.25g (Red)
                const yCritPos = u.valToPos(0.25, 'y', true);
                const yCritNeg = u.valToPos(-0.25, 'y', true);

                ctx.strokeStyle = 'rgba(239, 68, 68, 0.6)';
                ctx.beginPath();
                ctx.moveTo(left, yCritPos);
                ctx.lineTo(left + width, yCritPos);
                ctx.moveTo(left, yCritNeg);
                ctx.lineTo(left + width, yCritNeg);
                ctx.stroke();

                ctx.restore();
              },
            ],
          },
        },
      ],
    };

    const plot = new uPlot(opts, initialData, containerRef.current);
    uplotRef.current = plot;

    const handleResize = () => {
      if (containerRef.current && uplotRef.current) {
        uplotRef.current.setSize({
          width: containerRef.current.clientWidth || 600,
          height: 500,
        });
      }
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      plot.destroy();
      uplotRef.current = null;
    };
  }, []);

  // 2. Update series visibility cleanly without destroying uPlot
  useEffect(() => {
    const plot = uplotRef.current;
    if (!plot) return;

    plot.series.forEach((s, idx) => {
      if (idx === 0) return; // Time axis
      const isX = idx === 1;
      const isY = idx === 2;
      const isZ = idx === 3;

      let show = false;
      if (selectedAxis === 'all') show = true;
      else if (selectedAxis === 'x' && isX) show = true;
      else if (selectedAxis === 'y' && isY) show = true;
      else if (selectedAxis === 'z' && isZ) show = true;

      plot.setSeries(idx, { show });
    });
  }, [selectedAxis]);

  // 3. FLICKER-FREE Data Feed: Uses requestAnimationFrame + setData in-place (NEVER destroys uPlot)
  useEffect(() => {
    const plot = uplotRef.current;
    if (!plot || vibrationBatches.length === 0) return;

    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
    }

    animFrameRef.current = requestAnimationFrame(() => {
      // Gather samples from batches within windowSec
      const nowSec = Date.now() / 1000;
      const cutoffSec = nowSec - windowSec;

      const times: number[] = [];
      const xs: number[] = [];
      const ys: number[] = [];
      const zs: number[] = [];

      for (const batch of vibrationBatches) {
        const batchStartSec = batch.ts / 1000;
        const dt = 1 / batch.sampleRateHz;
        const count = batch.x.length;

        // Skip entire batch if older than cutoff
        if (batchStartSec + count * dt < cutoffSec) continue;

        // Sample every 4th point (250 Hz effective) to ensure perfectly silky 60fps rendering
        const step = 4;
        for (let i = 0; i < count; i += step) {
          const t = batchStartSec + i * dt;
          if (t >= cutoffSec) {
            times.push(t);
            xs.push(batch.x[i]);
            ys.push(batch.y[i]);
            zs.push(batch.z[i]);
          }
        }
      }

      if (times.length > 1) {
        // In-place update with auto-scale for x: NO canvas clearing or recreation!
        plot.setData([times, xs, ys, zs], false);
      }
    });

    return () => {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
    };
  }, [vibrationBatches, windowSec]);

  return (
    <div className="bg-industrial-900 border border-industrial-800 rounded-lg p-4 flex flex-col justify-between font-sans shadow-md">
      {/* Title & Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-industrial-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 mb-0.5">
            <Activity className="w-3.5 h-3.5" />
            <span>CAR-MOUNTED TRI-AXIAL SENSOR (1000 HZ)</span>
          </div>
          <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <span>Live Vibration Waveform</span>
          </h3>
          <p className="text-xs text-slate-400">
            Real-time mechanical shaking from the elevator car chassis.
          </p>
        </div>

        {/* Controls: Axis selector + Time window */}
        <div className="flex flex-wrap items-center gap-2 font-mono text-xs">
          {/* Axis Selector */}
          <div className="flex items-center bg-industrial-950 p-1 rounded border border-industrial-800">
            <span className="text-slate-500 text-[10px] px-1 font-bold">AXIS:</span>
            {[
              { id: 'all', label: 'All' },
              { id: 'x', label: 'X (Side)' },
              { id: 'y', label: 'Y (Front)' },
              { id: 'z', label: 'Z (Up)' },
            ].map(({ id, label }) => (
              <button
                key={id}
                onClick={() => setSelectedAxis(id as any)}
                className={`px-2 py-0.5 rounded text-[11px] font-bold transition-colors ${
                  selectedAxis === id
                    ? id === 'x'
                      ? 'bg-axis-x/20 text-axis-x border border-axis-x/50'
                      : id === 'y'
                      ? 'bg-axis-y/20 text-axis-y border border-axis-y/50'
                      : id === 'z'
                      ? 'bg-axis-z/20 text-axis-z border border-axis-z/50'
                      : 'bg-cyan-950 text-cyan-300 border border-cyan-700'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          {/* Time Window */}
          <div className="flex items-center bg-industrial-950 p-1 rounded border border-industrial-800">
            <span className="text-slate-500 text-[10px] px-1 font-bold">SPAN:</span>
            {[
              { sec: 10, label: '10s' },
              { sec: 20, label: '20s' },
              { sec: 30, label: '30s' },
            ].map(({ sec, label }) => (
              <button
                key={sec}
                onClick={() => setWindowSec(sec)}
                className={`px-2 py-0.5 rounded text-[11px] font-bold transition-colors ${
                  windowSec === sec
                    ? 'bg-industrial-800 text-slate-100 border border-industrial-700'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* uPlot Chart Canvas Container */}
      <div className="w-full my-2 flex justify-center overflow-hidden py-1">
        <div ref={containerRef} className="w-full flex justify-center" />
      </div>

      {/* Legend & Thresholds */}
      <div className="flex flex-wrap items-center justify-between text-[11px] font-mono text-slate-400 pt-2 border-t border-industrial-800/80 px-1">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1 text-axis-x">
            <span className="w-2.5 h-1 bg-axis-x" /> X (Side-to-Side)
          </span>
          <span className="flex items-center gap-1 text-axis-y">
            <span className="w-2.5 h-1 bg-axis-y" /> Y (Front-to-Back)
          </span>
          <span className="flex items-center gap-1 text-axis-z font-bold">
            <span className="w-2.5 h-1 bg-axis-z" /> Z (Up-and-Down)
          </span>
        </div>

        <div className="flex items-center gap-3 text-[10px]">
          <span className="text-amber-400 flex items-center gap-1">
            <span className="w-2 h-0.5 border-t border-dashed border-amber-400" /> Warning (±0.15g)
          </span>
          <span className="text-red-400 flex items-center gap-1">
            <span className="w-2 h-0.5 border-t border-dashed border-red-400" /> Rough Bump (±0.25g)
          </span>
        </div>
      </div>
    </div>
  );
};
