import React, { useEffect } from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { AppLayout } from './components/AppLayout';
import { LandingDashboardPage } from './pages/LandingDashboardPage';
import { VibrationAnalysisPage } from './pages/VibrationAnalysisPage';
import { HealthMaintenancePage } from './pages/HealthMaintenancePage';
import { DebugPage } from './pages/DebugPage';
import { useElevatorStore } from './store/useElevatorStore';

export const App: React.FC = () => {
  const initializeSocketListeners = useElevatorStore((state) => state.initializeSocketListeners);

  // Initialize socket client listeners on application startup
  useEffect(() => {
    const cleanup = initializeSocketListeners();
    return () => {
      cleanup();
    };
  }, [initializeSocketListeners]);

  return (
    <BrowserRouter>
      <Routes>
        <Route element={<AppLayout />}>
          {/* 1. Landing Page: Performance & Maintenance KPI Dashboard + C3 Camera Feed */}
          <Route path="/" element={<LandingDashboardPage />} />

          {/* 2. Separate Page: Vibration Analysis & Mechanical Insights */}
          <Route path="/vibration" element={<VibrationAnalysisPage />} />

          {/* 3. Maintenance Page: Subsystem Health, TTL Forecast, and Service Ledger */}
          <Route path="/maintenance" element={<HealthMaintenancePage />} />

          {/* Low-Level Stream Diagnostics */}
          <Route path="/debug" element={<DebugPage />} />

          {/* Catch-all redirect to Landing */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
};

export default App;
