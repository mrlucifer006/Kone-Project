// ============================================================================
// SYSTEM CONFIGURATION & THRESHOLDS (Simplified for Elevator Maintenance)
// Hardware Inputs: ESP32-C3 Camera Module & Tri-Axial Vibration Sensor
// ============================================================================

export const APP_CONFIG = {
  // Hardware Input Sources
  HARDWARE: {
    CAMERA_NAME: 'ESP32-C3 Cam Module',
    CAMERA_FEED_URL: '', // URL of C3 Cam (e.g. http://192.168.4.1/stream). Empty uses animated optical test pattern
    VIBRATION_SENSOR_NAME: 'Tri-Axial Vibration Sensor',
  },

  // Connection & Data Transport
  USE_MOCK_SOCKET: true, // Toggle false to connect to real backend WebSocket
  REAL_WEBSOCKET_URL: 'ws://localhost:8080/ws',
  
  // Reconnection backoff parameters
  RECONNECT: {
    INITIAL_DELAY_MS: 1000,
    MAX_DELAY_MS: 16000,
    BACKOFF_FACTOR: 2.0,
    MAX_ATTEMPTS: 8,
  },

  // Stream Frequencies
  VIBRATION: {
    SAMPLE_RATE_HZ: 1000, // 1000 samples per second from vibration sensor
    BATCH_INTERVAL_MS: 250, // 4 batches per second
    SAMPLES_PER_BATCH: 250, // 250 samples per batch
    BUFFER_SECONDS: 30, // 30s rolling view
    BUFFER_MAX_SAMPLES: 30000, // Max 30,000 points retained
  },

  TELEMETRY: {
    INTERVAL_MS: 600, // ~1.67 Hz update rate
    MOTION_BUFFER_MAX: 300,
    VISION_BUFFER_MAX: 300,
    ALERTS_BUFFER_MAX: 100,
  },

  // State Management & Health
  STALE_DATA_THRESHOLD_MS: 5000, // >5s without data update triggers STALE state

  // Camera Subsystem
  CAMERA: {
    FEED_URL: '', // ESP32-C3 MJPEG URL or empty for simulated optical camera
    FPS: 15,
  },

  // Simplified Alert & Maintenance Thresholds
  THRESHOLDS: {
    RAIL_DEVIATION_MM: {
      NORMAL: 0.8,
      WARNING: 1.5,
      CRITICAL: 2.2,
    },
    VIBRATION_RMS_G: {
      NORMAL: 0.08, // Smooth ride
      WARNING: 0.15, // Noticeable vibration
      CRITICAL: 0.25, // Heavy shaking / urgent
    },
    RIDE_COMFORT: {
      COMFORTABLE_MAX_G: 0.08, // Smooth
      ACCEPTABLE_MAX_G: 0.15, // Normal
    },
    HEALTH_SCORE: {
      HEALTHY_MIN: 75,
      WARNING_MIN: 45,
      CRITICAL_MAX: 44,
    },
    TTL_DAYS: {
      CRITICAL: 14,
      WARNING: 45,
    },
  },

  // Maintenance & Service Scheduling
  MAINTENANCE: {
    SAFETY_MARGIN_DAYS: 7, // Schedule service 7 days before part reaches wear limit
    DEFAULT_RESET_SCORE: 98,
    DEFAULT_RESET_TTL_DAYS: 250,
  },

  // Evaluator Demo Mode
  DEMO: {
    DURATION_SECONDS: 90,
  },

  // Standard Colors
  COLORS: {
    AXIS: {
      X: '#3b82f6', // blue (Side-to-Side / Lateral)
      Y: '#f97316', // orange (Front-to-Back)
      Z: '#22c55e', // green (Up-and-Down / Vertical)
    },
    STATUS: {
      HEALTHY: '#10b981', // green (Good)
      WARNING: '#f59e0b', // amber (Check Soon)
      CRITICAL: '#ef4444', // red (Needs Attention)
      NODATA: '#64748b', // grey (No Data)
    },
  },

  // Elevator Physical Specifications
  ELEVATOR_PHYSICS: {
    TOTAL_FLOORS: 20,
    FLOOR_HEIGHT_M: 4.0,
    TOTAL_HEIGHT_M: 80.0,
    MAX_SPEED_MS: 2.5,
    ACCEL_MS2: 0.8,
    DECEL_MS2: 0.8,
    FLOOR_DWELL_SECONDS: 3.5,
  },
} as const;
