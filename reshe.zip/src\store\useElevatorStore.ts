import { create } from 'zustand';
import { APP_CONFIG } from '../config';
import { socketClient } from '../data/socket';
import type {
  Alert,
  ComponentHealth,
  ComponentId,
  ConnectionStatus,
  MaintenanceEntry,
  MotionState,
  SimulationScenario,
  SystemStatus,
  VibrationBatch,
  VisionResult,
} from '../types';

export interface DataTimestampState {
  vibration: number | null;
  motion: number | null;
  vision: number | null;
  health: number | null;
  alert: number | null;
}

export interface RollingBufferStats {
  vibrationSampleCount: number;
  vibrationBatchCount: number;
  motionHistoryCount: number;
  visionHistoryCount: number;
  alertCount: number;
  maintenanceCount: number;
}

export interface DemoState {
  isRunning: boolean;
  elapsedSec: number;
  totalSec: number;
  speedMultiplier: number;
  phase: number; // 1 to 5
  caption: string;
}

export interface ElevatorState {
  // Connection and Simulation State
  connectionStatus: ConnectionStatus;
  scenario: SimulationScenario;
  isStreamPaused: boolean;
  demoMode: boolean;
  demo: DemoState;
  isHelpDrawerOpen: boolean;

  // Stale Detection Timestamps
  lastUpdate: DataTimestampState;

  // Latest Telemetry Snapshots
  latestVibration: VibrationBatch | null;
  latestVibrationRms: { x: number; y: number; z: number };
  latestMotion: MotionState | null;
  latestVision: VisionResult | null;
  healthMap: Record<ComponentId, ComponentHealth>;
  servicedComponents: ComponentId[];

  // Fixed-Size Rolling Buffers
  vibrationBatches: VibrationBatch[]; // Fixed max: 120 batches = 30 seconds
  motionHistory: MotionState[]; // Fixed max: 300 items
  visionHistory: VisionResult[]; // Fixed max: 300 items
  alerts: Alert[]; // Fixed max: 100 items
  maintenanceEntries: MaintenanceEntry[]; // Fixed max: 50 items

  // Actions
  setScenario: (scenario: SimulationScenario) => void;
  setConnectionStatus: (status: ConnectionStatus) => void;
  togglePauseStream: () => void;
  toggleDemoMode: () => void;
  startDemo: () => void;
  stopDemo: () => void;
  setDemoSpeed: (mult: number) => void;
  tickDemo: (deltaSec: number) => void;
  toggleHelpDrawer: () => void;
  getOverallSystemStatus: () => { status: SystemStatus; worstComponent: ComponentHealth | null };
  getLastDataTimestamp: () => number | null;
  getNextDueDate: (id?: ComponentId) => { dueDate: Date; daysRemaining: number; component: ComponentHealth };
  appendVibrationBatch: (batch: VibrationBatch) => void;
  appendMotionState: (motion: MotionState) => void;
  appendVisionResult: (vision: VisionResult) => void;
  updateComponentHealth: (healthList: ComponentHealth[]) => void;
  addAlert: (alert: Alert) => void;
  acknowledgeAlert: (alertId: string) => void;
  addMaintenanceEntry: (entry: MaintenanceEntry) => void;
  resetBuffers: () => void;
  initializeSocketListeners: () => () => void;
  getBufferStats: () => RollingBufferStats;
  isStale: (type: keyof DataTimestampState, currentTime?: number) => boolean;
}

// Initial default component health baseline
const INITIAL_HEALTH_MAP: Record<ComponentId, ComponentHealth> = {
  guide_shoes: {
    id: 'guide_shoes',
    score: 96,
    risk: 'low',
    ttlDays: 240,
    ttlLowDays: 210,
    ttlHighDays: 270,
    topFactors: [{ name: 'Bushing Wear', contribution: 12 }],
  },
  guide_rails: {
    id: 'guide_rails',
    score: 94,
    risk: 'low',
    ttlDays: 210,
    ttlLowDays: 185,
    ttlHighDays: 235,
    topFactors: [{ name: 'Profile Alignment Error', contribution: 10 }],
  },
  rail_joints: {
    id: 'rail_joints',
    score: 97,
    risk: 'low',
    ttlDays: 280,
    ttlLowDays: 250,
    ttlHighDays: 310,
    topFactors: [{ name: 'Fishplate Gap Tolerances', contribution: 11 }],
  },
  car_frame: {
    id: 'car_frame',
    score: 99,
    risk: 'low',
    ttlDays: 360,
    ttlLowDays: 330,
    ttlHighDays: 390,
    topFactors: [{ name: 'Structural Torsion', contribution: 6 }],
  },
};

// Seed initial maintenance log entries for technicians
const INITIAL_MAINTENANCE_ENTRIES: MaintenanceEntry[] = [
  {
    id: 'maint-101',
    ts: Date.now() - 86400000 * 12, // 12 days ago
    component: 'guide_shoes',
    action: 'Lubricant Refill & Guide Roller Inspection',
    technician: 'K. Lindqvist (Lead Tech)',
    notes: 'Roller clearance measured at 0.42 mm within standard factory tolerance.',
  },
  {
    id: 'maint-102',
    ts: Date.now() - 86400000 * 35, // 35 days ago
    component: 'rail_joints',
    action: 'Joint Fishplate Bolt Torque Check',
    technician: 'M. Chen',
    notes: 'All 8 fishplate bolts retorqued to 180 Nm specification on shaft B.',
  },
];

// Helper to compute RMS of an array
function calculateRms(values: number[]): number {
  if (!values.length) return 0;
  let sumSq = 0;
  for (let i = 0; i < values.length; i++) {
    sumSq += values[i] * values[i];
  }
  return Number(Math.sqrt(sumSq / values.length).toFixed(4));
}

const MAX_VIBRATION_BATCHES = Math.round(
  (APP_CONFIG.VIBRATION.BUFFER_SECONDS * 1000) / APP_CONFIG.VIBRATION.BATCH_INTERVAL_MS
); // 120 batches

export const useElevatorStore = create<ElevatorState>((set, get) => ({
  connectionStatus: socketClient.getStatus(),
  scenario: socketClient.getScenario(),
  isStreamPaused: false,
  demoMode: false,
  isHelpDrawerOpen: false,
  demo: {
    isRunning: false,
    elapsedSec: 0,
    totalSec: APP_CONFIG.DEMO.DURATION_SECONDS,
    speedMultiplier: 1.0,
    phase: 1,
    caption: 'Ready to start 90s evaluator demonstration sequence.',
  },

  lastUpdate: {
    vibration: null,
    motion: null,
    vision: null,
    health: null,
    alert: null,
  },

  latestVibration: null,
  latestVibrationRms: { x: 0, y: 0, z: 0 },
  latestMotion: null,
  latestVision: null,
  healthMap: INITIAL_HEALTH_MAP,
  servicedComponents: [],

  vibrationBatches: [],
  motionHistory: [],
  visionHistory: [],
  alerts: [],
  maintenanceEntries: INITIAL_MAINTENANCE_ENTRIES,

  setScenario: (scenario: SimulationScenario) => {
    socketClient.setScenario(scenario);
    set({ scenario, servicedComponents: [] });
  },

  setConnectionStatus: (connectionStatus: ConnectionStatus) => {
    set({ connectionStatus });
  },

  togglePauseStream: () => {
    const isPaused = get().isStreamPaused;
    if (isPaused) {
      socketClient.resumeStream();
      set({ isStreamPaused: false });
    } else {
      socketClient.pauseStream();
      set({ isStreamPaused: true });
    }
  },

  toggleDemoMode: () => {
    const next = !get().demoMode;
    set({ demoMode: next });
    if (next) {
      get().startDemo();
    } else {
      get().stopDemo();
    }
  },

  startDemo: () => {
    // Reset to healthy baseline and start timer
    socketClient.setScenario('healthy');
    set({
      demoMode: true,
      scenario: 'healthy',
      demo: {
        isRunning: true,
        elapsedSec: 0,
        totalSec: APP_CONFIG.DEMO.DURATION_SECONDS,
        speedMultiplier: 1.0,
        phase: 1,
        caption: 'Phase 1/5: Healthy baseline operations. Rail deviation < 0.4 mm, all components green.',
      },
    });
  },

  stopDemo: () => {
    set((state) => ({
      demoMode: false,
      demo: {
        ...state.demo,
        isRunning: false,
        caption: 'Demo Mode stopped.',
      },
    }));
  },

  setDemoSpeed: (speedMultiplier: number) => {
    set((state) => ({
      demo: { ...state.demo, speedMultiplier },
    }));
  },

  tickDemo: (deltaSec: number) => {
    const current = get().demo;
    if (!current.isRunning) return;

    const newElapsed = Math.min(current.totalSec, current.elapsedSec + deltaSec * current.speedMultiplier);

    // Phase evaluation
    // Phase 1 (0s - 15s): Healthy
    // Phase 2 (15s - 40s): Degrading wear
    // Phase 3 (40s - 65s): Fault spike, alert fires, TTL drops
    // Phase 4 (65s - 75s): Maintenance logged, autonomous dispatch
    // Phase 5 (75s - 90s): System recovered, healthy restored
    let phase = 1;
    let caption = current.caption;

    if (newElapsed < 15) {
      phase = 1;
      caption = 'Phase 1/5: Healthy baseline operations. Rail deviation < 0.4 mm, all components green.';
      if (get().scenario !== 'healthy') {
        get().setScenario('healthy');
      }
    } else if (newElapsed < 40) {
      phase = 2;
      caption = 'Phase 2/5: Mechanical fault seeded. Vibration RMS rising, deviation approaching warning threshold.';
      if (get().scenario !== 'degrading') {
        get().setScenario('degrading');
      }
    } else if (newElapsed < 65) {
      phase = 3;
      caption = 'Phase 3/5: Critical threshold violation! Shock alert fired, rail joint TTL drops to 9 days.';
      if (get().scenario !== 'fault_spike') {
        get().setScenario('fault_spike');
      }
    } else if (newElapsed < 75) {
      phase = 4;
      caption = 'Phase 4/5: Technician dispatched. Field maintenance action logged for rail joints.';
      // Automatically log maintenance if not already logged during this run
      if (get().healthMap.rail_joints.risk === 'high') {
        get().addMaintenanceEntry({
          id: `demo-auto-maint-${Date.now()}`,
          ts: Date.now(),
          component: 'rail_joints',
          action: 'Emergency Fishplate Torque Calibration & Gap Shimming',
          technician: 'Lead Tech J. Ramos (Field Ops)',
          notes: 'Fishplate bolts retorqued to 180 Nm; gap aligned within 0.25 mm. Baseline restored.',
        });
      }
    } else if (newElapsed < 90) {
      phase = 5;
      caption = 'Phase 5/5: Subsystem restored to nominal health (score 98). All parameters nominal.';
      if (get().scenario !== 'healthy') {
        get().setScenario('healthy');
      }
    } else {
      // Completed!
      phase = 5;
      caption = 'Demo sequence successfully completed! System operating normally.';
      set((state) => ({
        demo: {
          ...state.demo,
          isRunning: false,
          elapsedSec: current.totalSec,
          caption,
        },
      }));
      return;
    }

    set((state) => ({
      demo: {
        ...state.demo,
        elapsedSec: Number(newElapsed.toFixed(1)),
        phase,
        caption,
      },
    }));
  },

  toggleHelpDrawer: () => {
    set((state) => ({ isHelpDrawerOpen: !state.isHelpDrawerOpen }));
  },

  getNextDueDate: (targetId?: ComponentId) => {
    const healthMap = get().healthMap;
    const comps = Object.values(healthMap);
    let target = comps[0];

    if (targetId && healthMap[targetId]) {
      target = healthMap[targetId];
    } else {
      // Find component with lowest TTL (most urgent)
      const sorted = [...comps].sort((a, b) => a.ttlDays - b.ttlDays);
      target = sorted[0];
    }

    const margin = APP_CONFIG.MAINTENANCE.SAFETY_MARGIN_DAYS;
    // Next due date = today + (ttlDays - safetyMargin) days
    const daysRemaining = Math.max(1, target.ttlDays - margin);
    const dueDate = new Date(Date.now() + daysRemaining * 86400000);

    return {
      dueDate,
      daysRemaining,
      component: target,
    };
  },

  getOverallSystemStatus: () => {
    const healthMap = get().healthMap;
    const comps = Object.values(healthMap);
    if (!comps.length) {
      return { status: 'nodata', worstComponent: null };
    }

    // Sort to find component with lowest score (worst health)
    const sorted = [...comps].sort((a, b) => a.score - b.score);
    const worst = sorted[0];

    // Priority: critical > warning > healthy
    const hasHighRisk = comps.some((c) => c.risk === 'high');
    const hasMediumRisk = comps.some((c) => c.risk === 'medium');

    if (hasHighRisk) {
      return { status: 'critical', worstComponent: worst };
    }
    if (hasMediumRisk) {
      return { status: 'warning', worstComponent: worst };
    }
    return { status: 'healthy', worstComponent: worst };
  },

  getLastDataTimestamp: () => {
    const lu = get().lastUpdate;
    const times = [lu.vibration, lu.motion, lu.vision, lu.health].filter((t): t is number => t !== null);
    if (!times.length) return null;
    return Math.max(...times);
  },

  appendVibrationBatch: (batch: VibrationBatch) => {
    const rms = {
      x: calculateRms(batch.x),
      y: calculateRms(batch.y),
      z: calculateRms(batch.z),
    };

    set((state) => {
      // Maintain fixed-size rolling buffer of max 120 batches (30 seconds)
      const currentBatches = state.vibrationBatches;
      let nextBatches: VibrationBatch[];
      if (currentBatches.length >= MAX_VIBRATION_BATCHES) {
        nextBatches = [...currentBatches.slice(currentBatches.length - MAX_VIBRATION_BATCHES + 1), batch];
      } else {
        nextBatches = [...currentBatches, batch];
      }

      return {
        latestVibration: batch,
        latestVibrationRms: rms,
        vibrationBatches: nextBatches,
        lastUpdate: {
          ...state.lastUpdate,
          vibration: batch.ts,
        },
      };
    });
  },

  appendMotionState: (motion: MotionState) => {
    set((state) => {
      const max = APP_CONFIG.TELEMETRY.MOTION_BUFFER_MAX;
      const current = state.motionHistory;
      const nextHistory = current.length >= max
        ? [...current.slice(current.length - max + 1), motion]
        : [...current, motion];

      return {
        latestMotion: motion,
        motionHistory: nextHistory,
        lastUpdate: {
          ...state.lastUpdate,
          motion: motion.ts,
        },
      };
    });
  },

  appendVisionResult: (vision: VisionResult) => {
    set((state) => {
      const max = APP_CONFIG.TELEMETRY.VISION_BUFFER_MAX;
      const current = state.visionHistory;
      const nextHistory = current.length >= max
        ? [...current.slice(current.length - max + 1), vision]
        : [...current, vision];

      return {
        latestVision: vision,
        visionHistory: nextHistory,
        lastUpdate: {
          ...state.lastUpdate,
          vision: vision.ts,
        },
      };
    });
  },

  updateComponentHealth: (healthList: ComponentHealth[]) => {
    const now = Date.now();
    set((state) => {
      const newMap = { ...state.healthMap };
      for (const h of healthList) {
        // Do not overwrite component if it was manually serviced in this session
        if (!state.servicedComponents.includes(h.id)) {
          newMap[h.id] = h;
        }
      }
      return {
        healthMap: newMap,
        lastUpdate: {
          ...state.lastUpdate,
          health: now,
        },
      };
    });
  },

  addAlert: (alert: Alert) => {
    set((state) => {
      const max = APP_CONFIG.TELEMETRY.ALERTS_BUFFER_MAX;
      const nextAlerts = [alert, ...state.alerts.filter((a) => a.id !== alert.id)].slice(0, max);
      return {
        alerts: nextAlerts,
        lastUpdate: {
          ...state.lastUpdate,
          alert: alert.ts,
        },
      };
    });
  },

  acknowledgeAlert: (alertId: string) => {
    set((state) => ({
      alerts: state.alerts.map((a) => (a.id === alertId ? { ...a, acknowledged: true } : a)),
    }));
  },

  addMaintenanceEntry: (entry: MaintenanceEntry) => {
    const compId = entry.component as ComponentId;
    set((state) => {
      // 1. Reset health and TTL for the serviced component
      const currentHealth = state.healthMap[compId];
      const resetScore = APP_CONFIG.MAINTENANCE.DEFAULT_RESET_SCORE;
      const resetTTL = APP_CONFIG.MAINTENANCE.DEFAULT_RESET_TTL_DAYS;

      const updatedHealth: ComponentHealth = currentHealth
        ? {
            ...currentHealth,
            score: resetScore,
            risk: 'low',
            ttlDays: resetTTL,
            ttlLowDays: resetTTL - 30,
            ttlHighDays: resetTTL + 30,
            topFactors: [
              { name: 'Post-service clearance check', contribution: 6 },
              { name: 'Fresh lubricant boundary film', contribution: 4 },
            ],
          }
        : {
            id: compId,
            score: resetScore,
            risk: 'low',
            ttlDays: resetTTL,
            ttlLowDays: resetTTL - 30,
            ttlHighDays: resetTTL + 30,
            topFactors: [{ name: 'Post-service baseline', contribution: 5 }],
          };

      const updatedHealthMap = {
        ...state.healthMap,
        [compId]: updatedHealth,
      };

      // 2. Automatically acknowledge any active alerts for this component
      const updatedAlerts = state.alerts.map((a) =>
        a.component === compId ? { ...a, acknowledged: true } : a
      );

      return {
        healthMap: updatedHealthMap,
        alerts: updatedAlerts,
        servicedComponents: Array.from(new Set([...state.servicedComponents, compId])),
        maintenanceEntries: [entry, ...state.maintenanceEntries].slice(0, 50),
      };
    });
  },

  resetBuffers: () => {
    set({
      vibrationBatches: [],
      motionHistory: [],
      visionHistory: [],
      alerts: [],
    });
  },

  getBufferStats: () => {
    const s = get();
    const vibrationSampleCount = s.vibrationBatches.reduce((acc, b) => acc + b.x.length, 0);
    return {
      vibrationSampleCount,
      vibrationBatchCount: s.vibrationBatches.length,
      motionHistoryCount: s.motionHistory.length,
      visionHistoryCount: s.visionHistory.length,
      alertCount: s.alerts.length,
      maintenanceCount: s.maintenanceEntries.length,
    };
  },

  isStale: (type: keyof DataTimestampState, currentTime: number = Date.now()) => {
    const last = get().lastUpdate[type];
    if (last === null) return true;
    return (currentTime - last) > APP_CONFIG.STALE_DATA_THRESHOLD_MS;
  },

  initializeSocketListeners: () => {
    const unsubscribeStatus = socketClient.onStatusChange((status) => {
      get().setConnectionStatus(status);
    });

    const unsubscribeVibration = socketClient.subscribe('vibration', (batch) => {
      get().appendVibrationBatch(batch);
    });

    const unsubscribeMotion = socketClient.subscribe('motion', (state) => {
      get().appendMotionState(state);
    });

    const unsubscribeVision = socketClient.subscribe('vision', (result) => {
      get().appendVisionResult(result);
    });

    const unsubscribeHealth = socketClient.subscribe('health', (healthList) => {
      get().updateComponentHealth(healthList);
    });

    const unsubscribeAlert = socketClient.subscribe('alert', (alert) => {
      get().addAlert(alert);
    });

    const unsubscribeScenario = socketClient.subscribe('scenario_change', (payload) => {
      set({ scenario: payload.scenario });
    });

    // Start socket connection
    socketClient.connect();

    return () => {
      unsubscribeStatus();
      unsubscribeVibration();
      unsubscribeMotion();
      unsubscribeVision();
      unsubscribeHealth();
      unsubscribeAlert();
      unsubscribeScenario();
    };
  },
}));
