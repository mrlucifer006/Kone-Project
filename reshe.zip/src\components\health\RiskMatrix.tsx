import React from 'react';
import { useElevatorStore } from '../../store/useElevatorStore';
import type { ComponentHealth, ComponentId, RiskLevel } from '../../types';
import { StatusChip } from '../StatusChip';
import { AlertTriangle, Grid, HelpCircle, ShieldAlert } from 'lucide-react';

export interface RiskMatrixProps {
  selectedComponentId: ComponentId;
  onSelectComponent: (id: ComponentId) => void;
}

export const RiskMatrix: React.FC<RiskMatrixProps> = ({
  selectedComponentId,
  onSelectComponent,
}) => {
  const healthMap = useElevatorStore((state) => state.healthMap);

  // Map each component to its consequence and current likelihood
  // Guide Rails: Consequence = Severe (High)
  // Rail Joints: Consequence = Severe (High)
  // Car Frame: Consequence = Moderate/Severe (High)
  // Guide Shoes: Consequence = Moderate (Medium)
  const getCoordinates = (comp: ComponentHealth): { likelihood: 0 | 1 | 2; consequence: 0 | 1 | 2 } => {
    // Likelihood based on health risk
    let likelihood: 0 | 1 | 2 = 0; // 0 = Low, 1 = Medium, 2 = High
    if (comp.risk === 'high' || comp.score < 45) likelihood = 2;
    else if (comp.risk === 'medium' || comp.score < 75) likelihood = 1;
    else likelihood = 0;

    let consequence: 0 | 1 | 2 = 1; // 0 = Low, 1 = Med, 2 = High
    if (comp.id === 'guide_rails' || comp.id === 'rail_joints') consequence = 2;
    else if (comp.id === 'car_frame') consequence = 2;
    else consequence = 1; // guide_shoes = medium consequence

    return { likelihood, consequence };
  };

  const matrixCells: { [key: string]: ComponentHealth[] } = {
    '2-2': [], '2-1': [], '2-0': [],
    '1-2': [], '1-1': [], '1-0': [],
    '0-2': [], '0-1': [], '0-0': [],
  };

  Object.values(healthMap).forEach((comp) => {
    const { likelihood, consequence } = getCoordinates(comp);
    matrixCells[`${likelihood}-${consequence}`].push(comp);
  });

  const getCellColor = (likelihood: number, consequence: number) => {
    const score = likelihood + consequence;
    if (score >= 3) return 'bg-red-950/40 border-red-900/60 text-red-300';
    if (score >= 2) return 'bg-amber-950/30 border-amber-900/50 text-amber-300';
    return 'bg-emerald-950/20 border-emerald-900/40 text-emerald-300';
  };

  return (
    <div className="bg-industrial-900 border border-industrial-800 rounded-lg p-5 flex flex-col justify-between font-sans space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-industrial-800">
        <div>
          <span className="text-[10px] font-mono text-cyan-400 font-bold uppercase tracking-wider block">
            PARTS INSPECTION PRIORITY
          </span>
          <h3 className="text-base font-bold text-slate-100 uppercase tracking-wide flex items-center gap-2">
            <span>Risk Assessment Matrix</span>
          </h3>
        </div>

        <div className="flex items-center gap-3 font-mono text-[11px] text-slate-400">
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500" /> Normal
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-amber-500" /> Check Soon
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-red-500" /> Needs Inspection
          </span>
        </div>
      </div>

      {/* 3x3 Risk Matrix Grid */}
      <div className="relative w-full">
        <div className="grid grid-cols-4 gap-2 text-xs font-mono">
          {/* Top-left empty corner */}
          <div className="flex items-center justify-center text-[10px] text-slate-500 font-bold uppercase">
            WEAR LEVEL ↓
          </div>
          <div className="text-center text-[10px] text-slate-400 font-semibold uppercase pb-1">
            Low Impact
          </div>
          <div className="text-center text-[10px] text-slate-400 font-semibold uppercase pb-1">
            Medium Impact
          </div>
          <div className="text-center text-[10px] text-slate-400 font-semibold uppercase pb-1">
            High Impact
          </div>

          {/* Row 1: High Likelihood */}
          <div className="flex items-center font-bold text-red-400 text-[11px]">
            HIGH WEAR
          </div>
          {[0, 1, 2].map((consequence) => {
            const comps = matrixCells[`2-${consequence}`];
            return (
              <div
                key={`2-${consequence}`}
                className={`min-h-[64px] p-2 rounded-md border flex flex-col gap-1.5 justify-center items-center transition-all ${getCellColor(
                  2,
                  consequence
                )}`}
              >
                {comps.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => onSelectComponent(c.id)}
                    className={`px-2 py-1 rounded text-[10px] font-bold uppercase transition-all shadow-sm ${
                      selectedComponentId === c.id
                        ? 'ring-2 ring-white bg-slate-100 text-slate-950 font-black'
                        : 'bg-industrial-950/90 text-slate-200 border border-industrial-700 hover:border-slate-400'
                    }`}
                  >
                    {c.id.replace('_', ' ')}
                  </button>
                ))}
              </div>
            );
          })}

          {/* Row 2: Medium Wear */}
          <div className="flex items-center font-bold text-amber-400 text-[11px]">
            MEDIUM WEAR
          </div>
          {[0, 1, 2].map((consequence) => {
            const comps = matrixCells[`1-${consequence}`];
            return (
              <div
                key={`1-${consequence}`}
                className={`min-h-[64px] p-2 rounded-md border flex flex-col gap-1.5 justify-center items-center transition-all ${getCellColor(
                  1,
                  consequence
                )}`}
              >
                {comps.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => onSelectComponent(c.id)}
                    className={`px-2 py-1 rounded text-[10px] font-bold uppercase transition-all shadow-sm ${
                      selectedComponentId === c.id
                        ? 'ring-2 ring-white bg-slate-100 text-slate-950 font-black'
                        : 'bg-industrial-950/90 text-slate-200 border border-industrial-700 hover:border-slate-400'
                    }`}
                  >
                    {c.id.replace('_', ' ')}
                  </button>
                ))}
              </div>
            );
          })}

          {/* Row 3: Low Wear */}
          <div className="flex items-center font-bold text-emerald-400 text-[11px]">
            LOW WEAR
          </div>
          {[0, 1, 2].map((consequence) => {
            const comps = matrixCells[`0-${consequence}`];
            return (
              <div
                key={`0-${consequence}`}
                className={`min-h-[64px] p-2 rounded-md border flex flex-col gap-1.5 justify-center items-center transition-all ${getCellColor(
                  0,
                  consequence
                )}`}
              >
                {comps.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => onSelectComponent(c.id)}
                    className={`px-2 py-1 rounded text-[10px] font-bold uppercase transition-all shadow-sm ${
                      selectedComponentId === c.id
                        ? 'ring-2 ring-white bg-slate-100 text-slate-950 font-black'
                        : 'bg-industrial-950/90 text-slate-200 border border-industrial-700 hover:border-slate-400'
                    }`}
                  >
                    {c.id.replace('_', ' ')}
                  </button>
                ))}
              </div>
            );
          })}
        </div>
      </div>

      {/* Footer */}
      <div className="pt-2 border-t border-industrial-800/80 flex items-center justify-between text-[11px] font-mono text-slate-400">
        <span>Click any token above to inspect subsystem details.</span>
        <span>Active: <strong className="text-slate-100 uppercase">{selectedComponentId.replace('_', ' ')}</strong></span>
      </div>
    </div>
  );
};
