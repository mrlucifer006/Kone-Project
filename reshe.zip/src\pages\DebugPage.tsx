import React, { useEffect, useState } from 'react';
import { APP_CONFIG } from '../config';
import { socketClient } from '../data/socket';
import { useElevatorStore } from '../store/useElevatorStore';
import type { AlertSeverity, ComponentId, RiskLevel, SimulationScenario } from '../types';
import {
  Activity,
  AlertOctagon,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Cpu,
  Database,
  Flame,
  Gauge,
  HelpCircle,
  Layers,
  Power,
  RefreshCw,
  Sliders,
  Terminal,
  Zap,
} from 'lucide-react';

export const DebugPage: React.FC = () => {
  const {
    connectionStatus,
    scenario,
    setScenario,
    latestVibration,
    latestVibrationRms,
    latestMotion,
    latestVision,
    healthMap,
    alerts,
    acknowledgeAlert,
    maintenanceEntries,
    getBufferStats,
    lastUpdate,
  } = useElevatorStore();

  const [bufferStats, setBufferStats] = useState(getBufferStats());
  const [currentTime, setCurrentTime] = useState(Date.now());
  const [memoryHeap, setMemoryHeap] = useState<{ usedJSHeapSize?: number; totalJSHeapSize?: number }>({});

  // Poll for stats and current time every 250ms for smooth live updates
  useEffect(() => {
    const interval = window.setInterval(() => {
      const now = Date.now();
      setCurrentTime(now);
      setBufferStats(getBufferStats());

      // If Chrome performance.memory is exposed
      const perfMem = (performance as any).memory;
      if (perfMem) {
        setMemoryHeap({
          usedJSHeapSize: Math.round(perfMem.usedJSHeapSize / (1024 * 1024)),
          totalJSHeapSize: Math.round(perfMem.totalJSHeapSize / (1024 * 1024)),
        });
      }
    }, 250);

    return () => clearInterval(interval);
  }, [getBufferStats]);

  const calcAgeSec = (ts: number | null) => {
    if (ts === null) return null;
    return Number(((currentTime - ts) / 1000).toFixed(1));
  };

  const isStale = (ts: number | null) => {
    if (ts === null) return true;
    return currentTime - ts > APP_CONFIG.STALE_DATA_THRESHOLD_MS;
  };

  const getRiskBadge = (risk: RiskLevel) => {
    switch (risk) {
      case 'low':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold bg-emerald-950 text-emerald-400 border border-emerald-800">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            <span>HEALTHY</span>
          </span>
        );
      case 'medium':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold bg-amber-950 text-amber-400 border border-amber-800">
            <AlertTriangle className="w-3 h-3 text-amber-400" />
            <span>WARNING</span>
          </span>
        );
      case 'high':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold bg-red-950 text-red-400 border border-red-800">
            <AlertOctagon className="w-3 h-3 text-red-400" />
            <span>CRITICAL</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold bg-slate-900 text-slate-400 border border-slate-700">
            <HelpCircle className="w-3 h-3 text-slate-400" />
            <span>NO DATA</span>
          </span>
        );
    }
  };

  const getSeverityBadge = (sev: AlertSeverity) => {
    switch (sev) {
      case 'critical':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-mono font-bold bg-red-950 text-red-400 border border-red-800">
            <AlertOctagon className="w-3 h-3 text-red-400" />
            CRITICAL
          </span>
        );
      case 'warning':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-mono font-bold bg-amber-950 text-amber-400 border border-amber-800">
            <AlertTriangle className="w-3 h-3 text-amber-400" />
            WARNING
          </span>
        );
      case 'info':
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-mono font-bold bg-cyan-950 text-cyan-400 border border-cyan-800">
            <Zap className="w-3 h-3 text-cyan-400" />
            INFO
          </span>
        );
    }
  };

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-sans">
      {/* Page Title & Breadcrumb */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-2 border-b border-industrial-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 mb-1">
            <Terminal className="w-3.5 h-3.5" />
            <span>STAGE 1 // DATA ENGINE & TRANSPORT VERIFICATION</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight text-slate-100 flex items-center gap-3">
            <span>Diagnostics & Simulated Socket Inspector</span>
            <span className="text-xs px-2 py-0.5 rounded font-mono font-semibold bg-industrial-800 text-slate-300 border border-industrial-700">
              /debug
            </span>
          </h2>
          <p className="text-sm text-slate-400 mt-0.5">
            Real-time validation of WebSocket client, fixed-size rolling ring buffers, kinematic physics, and scenario transitions.
          </p>
        </div>

        {/* Socket Test Controls */}
        <div className="flex items-center gap-2">
          {connectionStatus === 'connected' ? (
            <button
              onClick={() => socketClient.disconnect()}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-mono font-medium text-red-400 bg-red-950/40 border border-red-800 hover:bg-red-900/60 transition-colors"
            >
              <Power className="w-3.5 h-3.5" />
              <span>Simulate Disconnect</span>
            </button>
          ) : (
            <button
              onClick={() => socketClient.connect()}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-mono font-medium text-emerald-400 bg-emerald-950/40 border border-emerald-800 hover:bg-emerald-900/60 transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reconnect Socket</span>
            </button>
          )}
        </div>
      </div>

      {/* TOP ROW: Scenario Controller & Memory Bounds */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Scenario Switcher Card */}
        <div className="lg:col-span-2 bg-industrial-900 rounded-lg border border-industrial-800 p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sliders className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-200">
                Active Simulation Scenario
              </h3>
            </div>
            <span className="text-xs font-mono text-slate-400">
              Current: <strong className="text-slate-200 uppercase">{scenario}</strong>
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            {/* Healthy */}
            <button
              onClick={() => setScenario('healthy')}
              className={`p-3 rounded-md border text-left transition-all ${
                scenario === 'healthy'
                  ? 'bg-industrial-800 border-emerald-500/80 shadow-md ring-1 ring-emerald-500/30'
                  : 'bg-industrial-950/60 border-industrial-800 hover:border-industrial-700'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-bold font-mono text-emerald-400 flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5" />
                  HEALTHY
                </span>
                {scenario === 'healthy' && (
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                )}
              </div>
              <p className="text-xs text-slate-300 leading-snug">
                Z-axis noise ~0.05 g, small 12 Hz & 45 Hz peaks. Low rail deviation (~0.35 mm). High health scores &gt;90.
              </p>
            </button>

            {/* Degrading */}
            <button
              onClick={() => setScenario('degrading')}
              className={`p-3 rounded-md border text-left transition-all ${
                scenario === 'degrading'
                  ? 'bg-industrial-800 border-amber-500/80 shadow-md ring-1 ring-amber-500/30'
                  : 'bg-industrial-950/60 border-industrial-800 hover:border-industrial-700'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-bold font-mono text-amber-400 flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5" />
                  DEGRADING
                </span>
                {scenario === 'degrading' && (
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                )}
              </div>
              <p className="text-xs text-slate-300 leading-snug">
                Over 5 min: 45 Hz energy & RMS climb. Rail deviation drifts from 0.3 to 2.5 mm. Health declines, TTL shrinks.
              </p>
            </button>

            {/* Fault Spike */}
            <button
              onClick={() => setScenario('fault_spike')}
              className={`p-3 rounded-md border text-left transition-all ${
                scenario === 'fault_spike'
                  ? 'bg-industrial-800 border-red-500/80 shadow-md ring-1 ring-red-500/30'
                  : 'bg-industrial-950/60 border-industrial-800 hover:border-industrial-700'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-bold font-mono text-red-400 flex items-center gap-1.5">
                  <Flame className="w-3.5 h-3.5" />
                  FAULT SPIKE
                </span>
                {scenario === 'fault_spike' && (
                  <span className="w-2 h-2 rounded-full bg-red-400 animate-ping" />
                )}
              </div>
              <p className="text-xs text-slate-300 leading-snug">
                Healthy baseline + periodic shock events every ~8 s. Severe transient shock wave & sudden deviation spike.
              </p>
            </button>
          </div>
        </div>

        {/* Memory & Fixed-Buffer Guarantees */}
        <div className="bg-industrial-900 rounded-lg border border-industrial-800 p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-200">
                Fixed Ring Buffer Metrics
              </h3>
            </div>
            <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950 px-1.5 py-0.5 rounded border border-emerald-900">
              O(1) BOUNDED
            </span>
          </div>

          <div className="space-y-2 font-mono text-xs">
            <div className="flex justify-between items-center bg-industrial-950/60 p-2 rounded border border-industrial-800/80">
              <span className="text-slate-400">Vibration Samples:</span>
              <span className="font-semibold text-slate-200">
                {bufferStats.vibrationSampleCount.toLocaleString()} / {APP_CONFIG.VIBRATION.BUFFER_MAX_SAMPLES.toLocaleString()} (30s)
              </span>
            </div>
            <div className="flex justify-between items-center bg-industrial-950/60 p-2 rounded border border-industrial-800/80">
              <span className="text-slate-400">Vibration Batches:</span>
              <span className="font-semibold text-slate-200">
                {bufferStats.vibrationBatchCount} / 120 batches (250ms ea)
              </span>
            </div>
            <div className="flex justify-between items-center bg-industrial-950/60 p-2 rounded border border-industrial-800/80">
              <span className="text-slate-400">Motion History:</span>
              <span className="font-semibold text-slate-200">
                {bufferStats.motionHistoryCount} / {APP_CONFIG.TELEMETRY.MOTION_BUFFER_MAX} entries
              </span>
            </div>
            <div className="flex justify-between items-center bg-industrial-950/60 p-2 rounded border border-industrial-800/80">
              <span className="text-slate-400">Vision History:</span>
              <span className="font-semibold text-slate-200">
                {bufferStats.visionHistoryCount} / {APP_CONFIG.TELEMETRY.VISION_BUFFER_MAX} entries
              </span>
            </div>
            {memoryHeap.usedJSHeapSize && (
              <div className="flex justify-between items-center bg-industrial-950/60 p-2 rounded border border-industrial-800/80">
                <span className="text-slate-400">JS Heap Usage:</span>
                <span className="font-semibold text-cyan-400">
                  {memoryHeap.usedJSHeapSize} MB / {memoryHeap.totalJSHeapSize} MB
                </span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* STREAM HEALTH & STALENESS MONITOR */}
      <div className="bg-industrial-900 rounded-lg border border-industrial-800 p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-200">
              Stale Data Detection (Threshold: &gt; {APP_CONFIG.STALE_DATA_THRESHOLD_MS / 1000}s)
            </h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            Every widget strictly flags stale data
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {(
            [
              { label: 'VIBRATION STREAM (4 Hz)', key: 'vibration', ts: lastUpdate.vibration },
              { label: 'MOTION TELEMETRY (~1.7 Hz)', key: 'motion', ts: lastUpdate.motion },
              { label: 'VISION AI STREAM (~1.7 Hz)', key: 'vision', ts: lastUpdate.vision },
              { label: 'COMPONENT HEALTH (~1.7 Hz)', key: 'health', ts: lastUpdate.health },
            ] as const
          ).map((item) => {
            const stale = isStale(item.ts);
            const age = calcAgeSec(item.ts);

            return (
              <div
                key={item.key}
                className={`p-3 rounded-md border transition-all ${
                  stale
                    ? 'bg-industrial-950/90 border-amber-900/60 opacity-70'
                    : 'bg-industrial-950/40 border-industrial-800'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[11px] font-mono text-slate-400">{item.label}</span>
                  {stale ? (
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-950 text-amber-400 border border-amber-800">
                      STALE
                    </span>
                  ) : (
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-900">
                      LIVE
                    </span>
                  )}
                </div>
                <div className="text-lg font-mono font-bold text-slate-200">
                  {age !== null ? `${age}s ago` : 'No Data'}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* LIVE RAW SNAPSHOTS: 4-COLUMN GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* 1. Vibration Batch */}
        <div
          className={`bg-industrial-900 rounded-lg border border-industrial-800 p-4 space-y-3 ${
            isStale(lastUpdate.vibration) ? 'opacity-60 ring-1 ring-amber-600/30' : ''
          }`}
        >
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-mono font-bold uppercase text-slate-300 flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
              Vibration Batch
            </h4>
            <span className="text-[10px] font-mono text-slate-400">1000 Hz</span>
          </div>

          <div className="space-y-2 text-xs font-mono">
            <div className="bg-industrial-950/60 p-2 rounded border border-industrial-800/80">
              <span className="text-slate-400 block text-[11px]">Calculated RMS (g):</span>
              <div className="grid grid-cols-3 gap-2 mt-1">
                <div>
                  <span className="text-axis-x font-bold">X:</span>{' '}
                  <span className="text-slate-200">{latestVibrationRms.x.toFixed(4)}</span>
                </div>
                <div>
                  <span className="text-axis-y font-bold">Y:</span>{' '}
                  <span className="text-slate-200">{latestVibrationRms.y.toFixed(4)}</span>
                </div>
                <div>
                  <span className="text-axis-z font-bold">Z:</span>{' '}
                  <span className="text-slate-200">{latestVibrationRms.z.toFixed(4)}</span>
                </div>
              </div>
            </div>

            <div className="bg-industrial-950/60 p-2 rounded border border-industrial-800/80 space-y-1">
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>Batch Size:</span>
                <span className="text-slate-200">{latestVibration ? latestVibration.x.length : 0} samples</span>
              </div>
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>Sample Rate:</span>
                <span className="text-slate-200">{latestVibration?.sampleRateHz ?? 1000} Hz</span>
              </div>
              <div className="text-[10px] text-slate-500 pt-1 border-t border-industrial-800 truncate">
                Z[0..3]: {latestVibration ? latestVibration.z.slice(0, 4).join(', ') : '---'}
              </div>
            </div>
          </div>
        </div>

        {/* 2. Motion Telemetry */}
        <div
          className={`bg-industrial-900 rounded-lg border border-industrial-800 p-4 space-y-3 ${
            isStale(lastUpdate.motion) ? 'opacity-60 ring-1 ring-amber-600/30' : ''
          }`}
        >
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-mono font-bold uppercase text-slate-300 flex items-center gap-1.5">
              <Gauge className="w-3.5 h-3.5 text-cyan-400" />
              Kinematic Motion
            </h4>
            <span className="text-[10px] font-mono text-cyan-400 uppercase">
              {latestMotion?.tripState ?? 'stopped'}
            </span>
          </div>

          <div className="space-y-2 text-xs font-mono">
            <div className="bg-industrial-950/60 p-2 rounded border border-industrial-800/80 grid grid-cols-2 gap-2">
              <div>
                <span className="text-slate-400 text-[11px] block">Floor:</span>
                <span className="text-lg font-bold text-slate-100">{latestMotion?.floor ?? 1}</span>
              </div>
              <div>
                <span className="text-slate-400 text-[11px] block">Position:</span>
                <span className="text-lg font-bold text-slate-100">{latestMotion?.position_m ?? 0.0} m</span>
              </div>
            </div>

            <div className="bg-industrial-950/60 p-2 rounded border border-industrial-800/80 space-y-1">
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>Speed:</span>
                <span className="text-slate-200 font-semibold">{latestMotion?.speedMs ?? 0.0} m/s</span>
              </div>
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>Acceleration:</span>
                <span className="text-slate-200 font-semibold">{latestMotion?.accelMs2 ?? 0.0} m/s²</span>
              </div>
            </div>
          </div>
        </div>

        {/* 3. Vision Analysis */}
        <div
          className={`bg-industrial-900 rounded-lg border border-industrial-800 p-4 space-y-3 ${
            isStale(lastUpdate.vision) ? 'opacity-60 ring-1 ring-amber-600/30' : ''
          }`}
        >
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-mono font-bold uppercase text-slate-300 flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-cyan-400" />
              Vision AI Tracking
            </h4>
            <span className="text-[10px] font-mono text-slate-400">
              Frame #{latestVision?.frameId ?? 0}
            </span>
          </div>

          <div className="space-y-2 text-xs font-mono">
            <div className="bg-industrial-950/60 p-2 rounded border border-industrial-800/80">
              <span className="text-slate-400 text-[11px] block">Rail Lateral Deviation:</span>
              <div className="flex items-baseline justify-between mt-0.5">
                <span
                  className={`text-xl font-bold ${
                    (latestVision?.deviationMm ?? 0) >= APP_CONFIG.THRESHOLDS.RAIL_DEVIATION_MM.CRITICAL
                      ? 'text-red-400'
                      : (latestVision?.deviationMm ?? 0) >= APP_CONFIG.THRESHOLDS.RAIL_DEVIATION_MM.WARNING
                      ? 'text-amber-400'
                      : 'text-emerald-400'
                  }`}
                >
                  {latestVision?.deviationMm ?? 0.0} mm
                </span>
                <span className="text-[10px] text-slate-400">
                  Lim: {APP_CONFIG.THRESHOLDS.RAIL_DEVIATION_MM.CRITICAL} mm
                </span>
              </div>
            </div>

            <div className="bg-industrial-950/60 p-2 rounded border border-industrial-800/80 space-y-1">
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>Angular Tilt:</span>
                <span className="text-slate-200">{latestVision?.angleDeg ?? 0.0}°</span>
              </div>
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>Confidence:</span>
                <span className="text-slate-200 font-semibold">
                  {latestVision ? (latestVision.confidence * 100).toFixed(1) : 0}%
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* 4. Active Alerts Count */}
        <div className="bg-industrial-900 rounded-lg border border-industrial-800 p-4 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-mono font-bold uppercase text-slate-300 flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
              Alerts Buffer
            </h4>
            <span className="text-[10px] font-mono text-slate-400">
              {alerts.filter((a) => !a.acknowledged).length} active
            </span>
          </div>

          <div className="space-y-2 text-xs font-mono">
            <div className="bg-industrial-950/60 p-2 rounded border border-industrial-800/80">
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>Total Received:</span>
                <span className="text-slate-200 font-bold">{alerts.length}</span>
              </div>
              <div className="flex justify-between text-slate-400 text-[11px] mt-1">
                <span>Critical Severity:</span>
                <span className="text-red-400 font-bold">
                  {alerts.filter((a) => a.severity === 'critical').length}
                </span>
              </div>
              <div className="flex justify-between text-slate-400 text-[11px] mt-1">
                <span>Warning Severity:</span>
                <span className="text-amber-400 font-bold">
                  {alerts.filter((a) => a.severity === 'warning').length}
                </span>
              </div>
            </div>

            <div className="bg-industrial-950/60 p-2 rounded border border-industrial-800/80 text-[11px] text-slate-400">
              Latest alert:{' '}
              <span className="text-slate-200 block truncate font-medium">
                {alerts[0]?.message ?? 'No active alerts'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* COMPONENT HEALTH DRILL-DOWN TABLE */}
      <div className="bg-industrial-900 rounded-lg border border-industrial-800 p-4 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-industrial-800">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-200 flex items-center gap-2">
            <Activity className="w-4 h-4 text-emerald-400" />
            Component Health Matrix & Prognostics (TTL)
          </h3>
          <span className="text-xs font-mono text-slate-400">
            Updated via health stream
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="border-b border-industrial-800 text-slate-400">
                <th className="py-2.5 px-3">COMPONENT ID</th>
                <th className="py-2.5 px-3">HEALTH SCORE</th>
                <th className="py-2.5 px-3">RISK TIER</th>
                <th className="py-2.5 px-3">TTL (EST. DAYS)</th>
                <th className="py-2.5 px-3">TOP CONTRIBUTING FACTORS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-industrial-800/60">
              {(['guide_shoes', 'guide_rails', 'rail_joints', 'car_frame'] as ComponentId[]).map((id) => {
                const comp = healthMap[id];
                if (!comp) return null;

                return (
                  <tr key={id} className="hover:bg-industrial-850/50 transition-colors">
                    <td className="py-2.5 px-3 font-bold text-slate-200 uppercase tracking-wide">
                      {comp.id.replace('_', ' ')}
                    </td>
                    <td className="py-2.5 px-3">
                      <div className="flex items-center gap-2">
                        <div className="w-20 bg-industrial-950 rounded-full h-2 overflow-hidden border border-industrial-800">
                          <div
                            className={`h-full ${
                              comp.score >= 75
                                ? 'bg-emerald-500'
                                : comp.score >= 45
                                ? 'bg-amber-500'
                                : 'bg-red-500'
                            }`}
                            style={{ width: `${comp.score}%` }}
                          />
                        </div>
                        <span className="font-bold text-slate-100">{comp.score}/100</span>
                      </div>
                    </td>
                    <td className="py-2.5 px-3">{getRiskBadge(comp.risk)}</td>
                    <td className="py-2.5 px-3">
                      <span className="font-bold text-slate-100">{comp.ttlDays} days</span>{' '}
                      <span className="text-slate-500 text-[11px]">
                        [{comp.ttlLowDays} - {comp.ttlHighDays}]
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">
                      <div className="flex flex-wrap gap-1.5">
                        {comp.topFactors.map((f, idx) => (
                          <span
                            key={idx}
                            className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[11px] bg-industrial-950 border border-industrial-800 text-slate-300"
                          >
                            <span>{f.name}:</span>
                            <span className="font-bold text-cyan-400">{f.contribution}%</span>
                          </span>
                        ))}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* RECENT ALERTS BUFFER INSPECTOR */}
      <div className="bg-industrial-900 rounded-lg border border-industrial-800 p-4 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-industrial-800">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-200 flex items-center gap-2">
            <Terminal className="w-4 h-4 text-amber-400" />
            Alerts Rolling Stream (Last {alerts.length} events)
          </h3>
          <span className="text-xs font-mono text-slate-400">
            Threshold automated triggers
          </span>
        </div>

        {alerts.length === 0 ? (
          <div className="p-6 text-center text-xs font-mono text-slate-500 bg-industrial-950/40 rounded border border-industrial-800">
            No threshold violation alerts triggered yet. System operating within nominal envelope.
          </div>
        ) : (
          <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
            {alerts.map((alt) => (
              <div
                key={alt.id}
                className={`p-2.5 rounded border flex flex-wrap items-center justify-between gap-3 text-xs font-mono transition-colors ${
                  alt.severity === 'critical'
                    ? 'bg-red-950/20 border-red-900/60'
                    : alt.severity === 'warning'
                    ? 'bg-amber-950/20 border-amber-900/60'
                    : 'bg-industrial-950 border-industrial-800'
                }`}
              >
                <div className="flex items-center gap-2.5 flex-1 min-w-[280px]">
                  {getSeverityBadge(alt.severity)}
                  <span className="text-slate-400 text-[11px]">
                    {new Date(alt.ts).toLocaleTimeString()}
                  </span>
                  <span className="px-1.5 py-0.5 rounded bg-industrial-800 text-slate-300 font-bold uppercase text-[10px]">
                    {alt.component}
                  </span>
                  <span className="text-slate-200 font-medium">{alt.message}</span>
                </div>

                <div className="flex items-center gap-2">
                  {alt.acknowledged ? (
                    <span className="text-[11px] text-slate-500 font-semibold uppercase">
                      ACKNOWLEDGED
                    </span>
                  ) : (
                    <button
                      onClick={() => acknowledgeAlert(alt.id)}
                      className="px-2 py-1 rounded text-[11px] font-semibold bg-industrial-800 text-slate-300 hover:bg-industrial-700 hover:text-white border border-industrial-700 transition-colors"
                    >
                      Acknowledge
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* SEEDED MAINTENANCE LOG */}
      <div className="bg-industrial-900 rounded-lg border border-industrial-800 p-4 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-industrial-800">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-200 flex items-center gap-2">
            <Terminal className="w-4 h-4 text-cyan-400" />
            Maintenance Log Entries
          </h3>
          <span className="text-xs font-mono text-slate-400">
            Technician field history
          </span>
        </div>

        <div className="space-y-2">
          {maintenanceEntries.map((m) => (
            <div
              key={m.id}
              className="p-2.5 rounded bg-industrial-950/60 border border-industrial-800 text-xs font-mono flex flex-wrap items-center justify-between gap-2"
            >
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-200">{m.action}</span>
                  <span className="px-1.5 py-0.5 rounded bg-industrial-800 text-slate-400 text-[10px] uppercase">
                    {m.component}
                  </span>
                  <span className="text-slate-500 text-[11px]">
                    {new Date(m.ts).toLocaleDateString()}
                  </span>
                </div>
                <div className="text-slate-400 text-[11px]">{m.notes}</div>
              </div>
              <div className="text-slate-400 text-[11px]">
                Tech: <strong className="text-slate-300">{m.technician}</strong>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
