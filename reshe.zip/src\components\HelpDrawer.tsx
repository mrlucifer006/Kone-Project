import React from 'react';
import { useElevatorStore } from '../store/useElevatorStore';
import {
  Activity,
  AlertTriangle,
  Camera,
  CheckCircle2,
  Clock,
  HelpCircle,
  Layers,
  Power,
  ShieldCheck,
  VideoOff,
  Wrench,
  X,
  Zap,
} from 'lucide-react';

export const HelpDrawer: React.FC = () => {
  const isHelpDrawerOpen = useElevatorStore((state) => state.isHelpDrawerOpen);
  const toggleHelpDrawer = useElevatorStore((state) => state.toggleHelpDrawer);
  const isStreamPaused = useElevatorStore((state) => state.isStreamPaused);
  const togglePauseStream = useElevatorStore((state) => state.togglePauseStream);

  if (!isHelpDrawerOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end bg-black/60 backdrop-blur-xs font-sans animate-in fade-in">
      <div className="w-full max-w-xl h-full bg-industrial-900 border-l border-industrial-700 p-6 shadow-2xl flex flex-col justify-between overflow-y-auto space-y-6 animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-industrial-800">
          <div className="flex items-center gap-2.5">
            <HelpCircle className="w-5 h-5 text-cyan-400" />
            <div>
              <h2 className="text-base font-bold uppercase tracking-wider text-slate-100 font-mono">
                Operator System Manual
              </h2>
              <p className="text-xs text-slate-400">
                Plain-language guide to dashboard telemetry, condition monitoring, and failure testing
              </p>
            </div>
          </div>
          <button
            onClick={toggleHelpDrawer}
            className="p-1 rounded bg-industrial-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sections */}
        <div className="space-y-6 text-xs text-slate-300 leading-relaxed font-sans">
          {/* Section 1: Live Overview */}
          <div className="bg-industrial-950 p-4 rounded-lg border border-industrial-800 space-y-2">
            <div className="flex items-center gap-2 font-mono font-bold text-cyan-300 text-sm">
              <Activity className="w-4 h-4 text-cyan-400" />
              <span>1. Live Car & Camera Feed</span>
            </div>
            <ul className="list-disc list-inside space-y-1 text-slate-300 text-xs">
              <li>
                <strong>C3 Cam Alignment Feed:</strong> Camera tracking mounted over the guide rail. Measures physical rail shift (&lt; 1.5 mm normal, &gt; 2.2 mm warning) and blade tilt angle.
              </li>
              <li>
                <strong>Car Vital Signs & Motion:</strong> Real-time acceleration gauge, current speed, floor position, and ride smoothness (Smooth, Normal, Rough).
              </li>
              <li>
                <strong>Shaft Schematic:</strong> Visual 20-floor shaft showing car movement in real-time. Click any hotspot (Guide Rollers, Rails, Joint Brackets, Chassis) to inspect wear and estimated life.
              </li>
              <li>
                <strong>Warnings & Alerts:</strong> Live notification feed with one-click acknowledgment.
              </li>
            </ul>
          </div>

          {/* Section 2: Vibration Analysis */}
          <div className="bg-industrial-950 p-4 rounded-lg border border-industrial-800 space-y-2">
            <div className="flex items-center gap-2 font-mono font-bold text-cyan-300 text-sm">
              <Layers className="w-4 h-4 text-cyan-400" />
              <span>2. Vibration Monitor (Tri-Axial Sensor)</span>
            </div>
            <ul className="list-disc list-inside space-y-1 text-slate-300 text-xs">
              <li>
                <strong>Car Vibration over Time:</strong> 1000 Hz 3-axis waveform from the car sensor. Measures Side-to-Side (X), Front-to-Back (Y), and Up-and-Down (Z) motion.
              </li>
              <li>
                <strong>Vibration Frequency Breakdown:</strong> Isolates shaking frequencies (0-100 Hz). The 45 Hz peak tracks guide roller wear; 12 Hz reflects natural car sway.
              </li>
              <li>
                <strong>Vibration Heatmap:</strong> Visual heat map of shaking over time. <em>Click any cell on the map to zoom into that moment in the waveform!</em>
              </li>
              <li>
                <strong>30-Day Vibration History:</strong> Daily average shaking (RMS) and shock ratio to track long-term rail wear.
              </li>
            </ul>
          </div>

          {/* Section 3: Health & Maintenance */}
          <div className="bg-industrial-950 p-4 rounded-lg border border-industrial-800 space-y-2">
            <div className="flex items-center gap-2 font-mono font-bold text-cyan-300 text-sm">
              <Wrench className="w-4 h-4 text-cyan-400" />
              <span>3. Parts & Service Scheduling</span>
            </div>
            <ul className="list-disc list-inside space-y-1 text-slate-300 text-xs">
              <li>
                <strong>Estimated Days Before Replacement:</strong> Expected remaining life shown as <code>N days (range LOW to HIGH)</code>.
              </li>
              <li>
                <strong>Risk Assessment Matrix:</strong> Visual 3x3 grid showing which parts need urgent inspection vs normal wear.
              </li>
              <li>
                <strong>Next Service Date & Log:</strong> Recommended maintenance date derived from part life minus a safety buffer. Logging a maintenance action resets that part's health score to 98.
              </li>
              <li>
                <strong>What is Causing Wear:</strong> Simple breakdown showing the main factors contributing to part wear.
              </li>
            </ul>
          </div>

          {/* Section 4: Failure Testing Guide */}
          <div className="bg-industrial-950 p-4 rounded-lg border border-industrial-800 space-y-2">
            <div className="flex items-center gap-2 font-mono font-bold text-amber-300 text-sm">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span>4. Interactive Failure State Testing Guide</span>
            </div>
            <p className="text-slate-300 text-xs">
              Every widget strictly enforces 4 states: <code>Normal</code>, <code>Stale-Data (&gt;5s)</code>, <code>Loading</code>, and <code>No-Data</code>. Test failure modes live without page refresh:
            </p>
            <div className="space-y-2 pt-1 font-mono text-[11px]">
              <div className="flex items-center justify-between p-2 rounded bg-industrial-900 border border-industrial-800">
                <span>1. Test Stale Data (&gt;5s):</span>
                <button
                  onClick={togglePauseStream}
                  className={`px-2 py-1 rounded font-bold ${
                    isStreamPaused
                      ? 'bg-emerald-600 text-white'
                      : 'bg-amber-600 text-slate-950'
                  }`}
                >
                  {isStreamPaused ? 'Resume Stream' : 'Pause Stream (5s)'}
                </button>
              </div>
              <div className="p-2 rounded bg-industrial-900 border border-industrial-800 text-slate-400">
                2. <strong>Camera Loss:</strong> Click "TEST LOSS" on the camera panel to verify feed-loss overlay and "Retry" recovery.
              </div>
              <div className="p-2 rounded bg-industrial-900 border border-industrial-800 text-slate-400">
                3. <strong>Network Disconnect:</strong> Click "Simulate Disconnect" on <code>/debug</code> to verify reconnect exponential backoff.
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-industrial-800 flex justify-between items-center text-xs font-mono">
          <span className="text-slate-500">KONE RAIL SENTINEL v0.1.0</span>
          <button
            onClick={toggleHelpDrawer}
            className="px-4 py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold transition-colors"
          >
            Close Manual
          </button>
        </div>
      </div>
    </div>
  );
};
