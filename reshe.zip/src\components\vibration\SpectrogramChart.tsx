import React, { useEffect, useMemo, useRef } from 'react';
import Plotly from 'plotly.js-dist-min';
import { useElevatorStore } from '../../store/useElevatorStore';
import { ChartCard } from '../ChartCard';
import { HelpPopover } from '../HelpPopover';

export interface SpectrogramChartProps {
  onSyncTimeWindow?: (timeRange: [number, number]) => void;
}

export const SpectrogramChart: React.FC<SpectrogramChartProps> = ({ onSyncTimeWindow }) => {
  const vibrationBatches = useElevatorStore((state) => state.vibrationBatches);
  const scenario = useElevatorStore((state) => state.scenario);
  const lastUpdate = useElevatorStore((state) => state.lastUpdate);

  const plotContainerRef = useRef<HTMLDivElement>(null);

  // Generate 2D STFT matrix: Time (columns) x Frequency (rows)
  const spectrogramData = useMemo(() => {
    // 30 time columns representing the rolling 30 seconds
    const timeCols: string[] = [];
    const now = Date.now();
    const numTimeSteps = 24;

    for (let i = numTimeSteps - 1; i >= 0; i--) {
      const tSec = (i * 1.25);
      timeCols.push(`-${tSec.toFixed(1)}s`);
    }

    // 20 frequency bins from 5 Hz to 100 Hz
    const freqBins: number[] = [];
    const numFreqBins = 20;
    for (let f = 1; f <= numFreqBins; f++) {
      freqBins.push(f * 5); // 5, 10, 15, ..., 100 Hz
    }

    // Z-matrix: dB magnitude [-60 dB to -5 dB]
    const zMatrix: number[][] = [];

    for (let fIdx = 0; fIdx < numFreqBins; fIdx++) {
      const freq = freqBins[fIdx];
      const row: number[] = [];

      for (let tIdx = 0; tIdx < numTimeSteps; tIdx++) {
        // Base noise floor in dB
        let val = -55 + Math.random() * 8;

        // 12 Hz structural chassis resonance band
        if (Math.abs(freq - 12) < 6) {
          val += 18;
        }

        // 45 Hz guide shoe resonance band
        if (Math.abs(freq - 45) < 7) {
          if (scenario === 'degrading') {
            val += 32; // Elevated in degrading!
          } else {
            val += 12;
          }
        }

        // 80 - 90 Hz intermittent joint shock impulses
        if (freq >= 80 && (scenario === 'fault_spike' || Math.random() < 0.08)) {
          if (tIdx % 6 === 0) {
            val += 38; // Shock burst!
          }
        }

        row.push(Number(Math.min(0, val).toFixed(1)));
      }
      zMatrix.push(row);
    }

    return { timeCols, freqBins, zMatrix };
  }, [vibrationBatches.length, scenario]);

  // Render Plotly Heatmap
  useEffect(() => {
    if (!plotContainerRef.current) return;

    const data: Plotly.Data[] = [
      {
        z: spectrogramData.zMatrix,
        x: spectrogramData.timeCols,
        y: spectrogramData.freqBins,
        type: 'heatmap',
        colorscale: [
          [0.0, '#0a0d14'],
          [0.2, '#1e293b'],
          [0.4, '#0369a1'],
          [0.6, '#06b6d4'],
          [0.8, '#f59e0b'],
          [1.0, '#ef4444'],
        ],
        colorbar: {
          title: { text: 'dB', side: 'top', font: { color: '#94a3b8', size: 10 } },
          tickfont: { color: '#64748b', size: 9 },
          len: 0.9,
          thickness: 12,
        },
        hoverongaps: false,
        hovertemplate: 'Time: %{x}<br>Freq: %{y} Hz<br>Power: %{z} dB<extra></extra>',
      },
    ];

    const layout: Partial<Plotly.Layout> = {
      autosize: true,
      height: 240,
      margin: { l: 45, r: 20, t: 10, b: 35 },
      paper_bgcolor: '#0a0d14',
      plot_bgcolor: '#0a0d14',
      xaxis: {
        title: { text: 'Time Relative to Live (s)', font: { color: '#64748b', size: 10 } },
        tickfont: { color: '#94a3b8', size: 9 },
        gridcolor: 'rgba(51, 65, 85, 0.3)',
      },
      yaxis: {
        title: { text: 'Freq (Hz)', font: { color: '#64748b', size: 10 } },
        tickfont: { color: '#94a3b8', size: 9 },
        gridcolor: 'rgba(51, 65, 85, 0.3)',
      },
    };

    const config: Partial<Plotly.Config> = {
      responsive: true,
      displayModeBar: false,
    };

    Plotly.newPlot(plotContainerRef.current, data, layout, config);

    // Click handler to sync time window with time-domain chart
    const currentContainer = plotContainerRef.current as any;
    if (currentContainer && currentContainer.on) {
      currentContainer.on('plotly_click', (eventData: any) => {
        if (eventData && eventData.points && eventData.points[0]) {
          const point = eventData.points[0];
          // Clicked time step
          const nowSec = Date.now() / 1000;
          // Sync around clicked 4-second region
          const clickedSecOffset = parseFloat(point.x.replace('s', '')) || -10;
          const centerTime = nowSec + clickedSecOffset;
          onSyncTimeWindow?.([centerTime - 2.5, centerTime + 2.5]);
        }
      });
    }

    return () => {
      if (plotContainerRef.current) {
        Plotly.purge(plotContainerRef.current);
      }
    };
  }, [spectrogramData, onSyncTimeWindow]);

  const dynamicCaption =
    scenario === 'fault_spike'
      ? 'Sudden track bumps (~85 Hz) visible every 8 seconds; click any bright stripe to zoom into that moment.'
      : scenario === 'degrading'
      ? 'Persistent warm band at 45 Hz across all elevator runs; indicates guide shoe roller lining wear.'
      : 'Vibration pattern is normal and low; small constant 12 Hz line corresponds to car body motion.';

  return (
    <ChartCard
      title="3. Vibration Intensity Heatmap (Shaking over Time)"
      units="[Shaking Intensity]"
      caption={dynamicCaption}
      lastUpdated={lastUpdate.vibration}
      hasData={vibrationBatches.length > 0}
      toolbar={
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800 hidden sm:inline">
            Click any cell to zoom into that moment
          </span>
          <HelpPopover
            title="Vibration Intensity Heatmap"
            whatIsIt="Shows how shaking intensity at each frequency changes over time. Blue/purple = smooth motion; bright yellow/red = strong shaking or bumps."
            nominalBaseline="A healthy elevator shows mostly cool colors (blue/purple) across the chart."
            anomalyIndications="Bright vertical stripes mean sudden shock events (hitting a rail joint gap). A continuous glowing orange/yellow stripe at 45 Hz means roller shoes need replacement."
          />
        </div>
      }
    >
      <div className="w-full h-full flex flex-col justify-between">
        <div ref={plotContainerRef} className="w-full h-full flex justify-center py-0.5" />
      </div>
    </ChartCard>
  );
};
