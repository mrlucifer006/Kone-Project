import React from 'react';
import { Link } from 'react-router-dom';
import { APP_CONFIG } from '../config';
import { useElevatorStore } from '../store/useElevatorStore';
import { LiveCameraFeed } from '../components/panels/LiveCameraFeed';
import { LiveElevatorPosition } from '../components/panels/LiveElevatorPosition';
import {
  Activity,
  ArrowRight,
  Building2,
  Calendar,
  Camera,
  CheckCircle2,
  Clock,
  Gauge,
  Layers,
  ShieldCheck,
  Waves,
  Wrench,
  Zap,
} from 'lucide-react';

export const LandingDashboardPage: React.FC = () => {
  const latestMotion = useElevatorStore((state) => state.latestMotion);
  const latestVision = useElevatorStore((state) => state.latestVision);
  const latestVibrationRms = useElevatorStore((state) => state.latestVibrationRms);
  const healthMap = useElevatorStore((state) => state.healthMap);
  const getNextDueDate = useElevatorStore((state) => state.getNextDueDate);
  const getOverallSystemStatus = useElevatorStore((state) => state.getOverallSystemStatus);

  const floor = latestMotion?.floor ?? 1;
  const speed = latestMotion?.speedMs ?? 0.0;
  const tripState = latestMotion?.tripState ?? 'stopped';

  const deviation = latestVision?.deviationMm ?? 0.35;
  const angle = latestVision?.angleDeg ?? 0.02;

  const zRms = latestVibrationRms.z;
  const { status: overallStatus, worstComponent } = getOverallSystemStatus();
  const { dueDate, daysRemaining, component: nextDueComp } = getNextDueDate();

  // Status checks
  const isShiftCritical = deviation >= APP_CONFIG.THRESHOLDS.RAIL_DEVIATION_MM.CRITICAL;
  const isShiftWarning = deviation >= APP_CONFIG.THRESHOLDS.RAIL_DEVIATION_MM.WARNING;

  const isVibeRough = zRms >= APP_CONFIG.THRESHOLDS.RIDE_COMFORT.ACCEPTABLE_MAX_G;
  const isVibeModerate = zRms >= APP_CONFIG.THRESHOLDS.RIDE_COMFORT.COMFORTABLE_MAX_G;

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto font-sans space-y-6">
      {/* 1. TOP PERFORMANCE & MAINTENANCE KPI CARDS DASHBOARD */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3.5 font-mono">
        {/* KPI 1: Car Floor & Movement */}
        <div className="bg-industrial-900 border border-industrial-800 rounded-lg p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-[11px]">
            <span className="flex items-center gap-1 font-bold">
              <Building2 className="w-3.5 h-3.5 text-cyan-400" /> CAR POSITION
            </span>
            <span className="text-[10px] text-cyan-400 uppercase">{tripState}</span>
          </div>
          <div className="my-1.5 flex items-baseline gap-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-100">
              Floor {floor}
            </span>
            <span className="text-xs text-slate-500">/ 20</span>
          </div>
          <div className="text-[11px] text-slate-400">
            Speed: <strong className="text-slate-200">{speed.toFixed(2)} m/s</strong>
          </div>
        </div>

        {/* KPI 2: Ride Smoothness */}
        <div className="bg-industrial-900 border border-industrial-800 rounded-lg p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-[11px]">
            <span className="flex items-center gap-1 font-bold">
              <Waves className="w-3.5 h-3.5 text-emerald-400" /> RIDE COMFORT
            </span>
            <span
              className={`w-2 h-2 rounded-full ${
                isVibeRough ? 'bg-red-500 animate-ping' : isVibeModerate ? 'bg-amber-500' : 'bg-emerald-500'
              }`}
            />
          </div>
          <div className="my-1.5">
            <span
              className={`text-base sm:text-lg font-extrabold ${
                isVibeRough ? 'text-red-400' : isVibeModerate ? 'text-amber-400' : 'text-emerald-400'
              }`}
            >
              {isVibeRough ? 'ROUGH / SHAKY' : isVibeModerate ? 'NORMAL RIDE' : 'SMOOTH RIDE'}
            </span>
          </div>
          <div className="text-[11px] text-slate-400">
            Vertical: <strong className="text-slate-200">{zRms.toFixed(3)} g RMS</strong>
          </div>
        </div>

        {/* KPI 3: Rail Optical Alignment */}
        <div className="bg-industrial-900 border border-industrial-800 rounded-lg p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-[11px]">
            <span className="flex items-center gap-1 font-bold">
              <Camera className="w-3.5 h-3.5 text-cyan-400" /> C3 RAIL SHIFT
            </span>
            <span
              className={`text-[10px] font-bold ${
                isShiftCritical ? 'text-red-400' : isShiftWarning ? 'text-amber-400' : 'text-emerald-400'
              }`}
            >
              {isShiftCritical ? 'MISALIGNED' : isShiftWarning ? 'CHECK' : 'ALIGNED'}
            </span>
          </div>
          <div className="my-1.5 flex items-baseline gap-1">
            <span
              className={`text-2xl sm:text-3xl font-extrabold ${
                isShiftCritical ? 'text-red-400' : isShiftWarning ? 'text-amber-400' : 'text-slate-100'
              }`}
            >
              {deviation.toFixed(2)}
            </span>
            <span className="text-xs text-slate-500">mm</span>
          </div>
          <div className="text-[11px] text-slate-400">
            Blade Tilt: <strong className="text-slate-200">{angle >= 0 ? '+' : ''}{angle.toFixed(1)}°</strong>
          </div>
        </div>

        {/* KPI 4: Overall Subsystem Health */}
        <div className="bg-industrial-900 border border-industrial-800 rounded-lg p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-[11px]">
            <span className="flex items-center gap-1 font-bold">
              <ShieldCheck className="w-3.5 h-3.5 text-purple-400" /> PARTS HEALTH
            </span>
            <span className="text-[10px] text-purple-400 uppercase">4 TRACKED</span>
          </div>
          <div className="my-1.5 flex items-baseline gap-1">
            <span
              className={`text-2xl sm:text-3xl font-extrabold ${
                overallStatus === 'healthy'
                  ? 'text-emerald-400'
                  : overallStatus === 'warning'
                  ? 'text-amber-400'
                  : 'text-red-400'
              }`}
            >
              {worstComponent ? worstComponent.score : 96}
            </span>
            <span className="text-xs text-slate-500">/ 100</span>
          </div>
          <div className="text-[11px] text-slate-400 truncate">
            Lowest: <strong className="text-slate-200">{worstComponent?.id.replace('_', ' ') || 'None'}</strong>
          </div>
        </div>

        {/* KPI 5: Next Service Date */}
        <div className="bg-industrial-900 border border-industrial-800 rounded-lg p-3.5 flex flex-col justify-between col-span-2 md:col-span-1">
          <div className="flex items-center justify-between text-slate-400 text-[11px]">
            <span className="flex items-center gap-1 font-bold">
              <Calendar className="w-3.5 h-3.5 text-amber-400" /> NEXT SERVICE
            </span>
            <span className="text-[10px] text-slate-500 font-bold">7D BUFFER</span>
          </div>
          <div className="my-1.5 flex items-baseline gap-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-amber-400">
              in {daysRemaining}
            </span>
            <span className="text-xs text-slate-500">days</span>
          </div>
          <div className="text-[11px] text-slate-400 truncate">
            Target: <strong className="text-slate-200">{nextDueComp.id.replace('_', ' ')}</strong>
          </div>
        </div>
      </div>

      {/* 2. MAIN 2-COLUMN VIEWPORT: CAMERA FEED + POSITION & KINEMATICS */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 items-start">
        {/* Left: C3 Cam Live Stream View */}
        <div className="space-y-4">
          <LiveCameraFeed />
        </div>

        {/* Right: Elevator Position & Hoistway Kinematics */}
        <div className="space-y-4">
          <LiveElevatorPosition />

          {/* Quick Jump Action Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 font-mono text-xs">
            {/* Link to Vibration Analysis */}
            <Link
              to="/vibration"
              className="p-3.5 rounded-lg bg-industrial-900 hover:bg-industrial-850 border border-industrial-800 hover:border-cyan-700 transition-all flex flex-col justify-between group"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="flex items-center gap-1.5 text-cyan-400 font-bold text-[11px]">
                  <Layers className="w-4 h-4" /> VIBRATION ANALYSIS
                </span>
                <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-cyan-400 group-hover:translate-x-0.5 transition-all" />
              </div>
              <p className="text-slate-400 text-[11px]">
                Inspect live 1000 Hz 3-axis waveforms, isolate roller wear at 45 Hz, and view 30-day history.
              </p>
              <div className="mt-2 pt-2 border-t border-industrial-800/80 flex justify-between text-[10px] text-slate-400">
                <span>Tri-Axial Sensor</span>
                <span className="text-cyan-400 font-bold">Open Deep Dive &rarr;</span>
              </div>
            </Link>

            {/* Link to Maintenance & Parts */}
            <Link
              to="/maintenance"
              className="p-3.5 rounded-lg bg-industrial-900 hover:bg-industrial-850 border border-industrial-800 hover:border-amber-700 transition-all flex flex-col justify-between group"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="flex items-center gap-1.5 text-amber-400 font-bold text-[11px]">
                  <Wrench className="w-4 h-4" /> MAINTENANCE &amp; PARTS
                </span>
                <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-amber-400 group-hover:translate-x-0.5 transition-all" />
              </div>
              <p className="text-slate-400 text-[11px]">
                Track remaining days before replacement (TTL), root-cause wear drivers, and log service records.
              </p>
              <div className="mt-2 pt-2 border-t border-industrial-800/80 flex justify-between text-[10px] text-slate-400">
                <span>4 Subsystems</span>
                <span className="text-amber-400 font-bold">View Parts Ledger &rarr;</span>
              </div>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};
