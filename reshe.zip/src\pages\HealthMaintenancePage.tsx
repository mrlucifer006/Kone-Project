import React, { useState } from 'react';
import { ExplainabilityPanel } from '../components/health/ExplainabilityPanel';
import { HealthTrendChart } from '../components/health/HealthTrendChart';
import { MaintenanceLogSection } from '../components/health/MaintenanceLogSection';
import { NextMaintenanceCard } from '../components/health/NextMaintenanceCard';
import { RiskMatrix } from '../components/health/RiskMatrix';
import { TtlConfidenceBand } from '../components/health/TtlConfidenceBand';
import { useElevatorStore } from '../store/useElevatorStore';
import type { ComponentId } from '../types';
import { ShieldCheck, Wrench } from 'lucide-react';

export const HealthMaintenancePage: React.FC = () => {
  const healthMap = useElevatorStore((state) => state.healthMap);

  const [selectedComponentId, setSelectedComponentId] = useState<ComponentId>('rail_joints');
  const [isLogModalOpen, setIsLogModalOpen] = useState(false);
  const [modalTargetComponent, setModalTargetComponent] = useState<ComponentId>('rail_joints');

  const selectedComponent = healthMap[selectedComponentId] || healthMap.rail_joints;

  const handleOpenModal = (preselected?: ComponentId) => {
    if (preselected) {
      setModalTargetComponent(preselected);
    } else {
      setModalTargetComponent(selectedComponentId);
    }
    setIsLogModalOpen(true);
  };

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto font-sans">
      {/* Page Title */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-2 border-b border-industrial-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 mb-1">
            <Wrench className="w-3.5 h-3.5" />
            <span>PARTS CONDITION & SERVICE SCHEDULING</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight text-slate-100 flex items-center gap-3">
            <span>Parts & Service Scheduling</span>
            <span className="text-xs px-2 py-0.5 rounded font-mono font-bold bg-industrial-800 text-slate-300 border border-industrial-700">
              Live Diagnostics
            </span>
          </h2>
          <p className="text-sm text-slate-400 mt-0.5">
            Monitor wear on guide shoes, rails, and car frame. Check estimated days before replacement, inspect wear causes, and log service records.
          </p>
        </div>
      </div>

      {/* ROW 1: HEALTH TRAJECTORY CHART & TTL CONFIDENCE BAND */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <HealthTrendChart
          selectedComponentId={selectedComponentId}
          onSelectComponent={(id) => setSelectedComponentId(id)}
        />

        <TtlConfidenceBand component={selectedComponent} />
      </div>

      {/* ROW 2: RISK MATRIX & NEXT MAINTENANCE CARD */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <RiskMatrix
          selectedComponentId={selectedComponentId}
          onSelectComponent={(id) => setSelectedComponentId(id)}
        />

        <NextMaintenanceCard onOpenLogModal={handleOpenModal} />
      </div>

      {/* ROW 3: EXPLAINABILITY PANEL */}
      <ExplainabilityPanel component={selectedComponent} />

      {/* ROW 4: MAINTENANCE LOG TABLE & ADD ENTRY FORM */}
      <MaintenanceLogSection
        isModalOpen={isLogModalOpen}
        preselectedComponent={modalTargetComponent}
        onCloseModal={() => setIsLogModalOpen(false)}
        onOpenModal={() => handleOpenModal()}
      />
    </div>
  );
};
