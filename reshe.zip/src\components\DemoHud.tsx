import React, { useEffect } from 'react';
import { useElevatorStore } from '../store/useElevatorStore';
import {
  FastForward,
  Play,
  Presentation,
  Square,
  Sparkles,
  Timer,
} from 'lucide-react';

export const DemoHud: React.FC = () => {
  const demo = useElevatorStore((state) => state.demo);
  const stopDemo = useElevatorStore((state) => state.stopDemo);
  const setDemoSpeed = useElevatorStore((state) => state.setDemoSpeed);
  const tickDemo = useElevatorStore((state) => state.tickDemo);

  // Ticker for demo script (updates every 250ms)
  useEffect(() => {
    if (!demo.isRunning) return;

    const interval = setInterval(() => {
      tickDemo(0.25);
    }, 250);

    return () => clearInterval(interval);
  }, [demo.isRunning, tickDemo]);

  if (!demo.isRunning) return null;

  const progressPercent = Math.min(100, (demo.elapsedSec / demo.totalSec) * 100);

  return (
    <div className="fixed bottom-4 left-4 right-4 md:left-72 md:right-8 z-50 animate-in slide-in-from-bottom duration-300">
      <div className="bg-industrial-900/95 backdrop-blur-md border-2 border-purple-500 rounded-xl p-4 shadow-2xl font-mono text-xs space-y-3">
        {/* Top Status Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <span className="p-1.5 rounded-lg bg-purple-950 text-purple-300 border border-purple-700 shadow-md">
              <Presentation className="w-4 h-4 text-purple-400 animate-pulse" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold uppercase tracking-wider text-purple-300 text-sm">
                  Evaluator Demo Mode Active
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-900/80 text-purple-200 border border-purple-600">
                  Phase {demo.phase}/5
                </span>
              </div>
              <p className="text-[11px] font-sans text-slate-300">
                Scripted 90-second autonomous predictive maintenance walkthrough
              </p>
            </div>
          </div>

          {/* Controls: Speed Multiplier & Stop */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setDemoSpeed(demo.speedMultiplier === 1 ? 3 : 1)}
              className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs font-bold border transition-colors ${
                demo.speedMultiplier > 1
                  ? 'bg-amber-950 text-amber-300 border-amber-600'
                  : 'bg-industrial-800 text-slate-300 border-industrial-700 hover:text-white'
              }`}
            >
              <FastForward className="w-3.5 h-3.5" />
              <span>{demo.speedMultiplier}x Speed</span>
            </button>

            <button
              onClick={stopDemo}
              className="flex items-center gap-1.5 px-3 py-1 rounded bg-red-900/80 hover:bg-red-800 text-red-100 font-bold border border-red-700 transition-colors shadow-sm"
            >
              <Square className="w-3 h-3 fill-current" />
              <span>Exit Demo</span>
            </button>
          </div>
        </div>

        {/* Dynamic Plain-Language Step Caption */}
        <div className="p-2.5 rounded-lg bg-industrial-950 border border-purple-900/60 flex items-center justify-between gap-3 text-slate-100 font-sans text-xs">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-purple-400 shrink-0" />
            <span className="font-semibold text-sm leading-snug">{demo.caption}</span>
          </div>

          <div className="font-mono text-xs font-bold text-purple-300 shrink-0 flex items-center gap-1.5">
            <Timer className="w-3.5 h-3.5 text-purple-400" />
            <span>
              {demo.elapsedSec.toFixed(0)}s / {demo.totalSec}s
            </span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-industrial-950 rounded-full h-2 overflow-hidden border border-purple-900/40 p-0.5">
          <div
            className="h-full bg-linear-to-r from-purple-500 via-pink-500 to-emerald-400 rounded-full transition-all duration-300 shadow-[0_0_10px_rgba(168,85,247,0.5)]"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>
    </div>
  );
};
